import cv2
import numpy as np
from mss import mss
import time
import pygetwindow as gw

class DofusVision:
    def __init__(self):
        # On initialise mss une seule fois quand on crée l'objet
        self.sct = mss()
        # Par défaut, on prend tout l'écran, mais ça sera écrasé par update_window_target
        self.monitor = {"top": 0, "left": 0, "width": 1920, "height": 1080}
        self.last_time = time.time()
        self.target_window_title = None

    def get_available_windows(self):
        """Retourne la liste des titres de toutes les fenêtres ouvertes."""
        windows = gw.getAllTitles()
        # Filtrer les fenêtres vides
        return [w for w in windows if w.strip() != ""]

    def set_target_window(self, window_title):
        """Définit la fenêtre cible à capturer."""
        self.target_window_title = window_title
        self.update_window_coordinates()

    def update_window_coordinates(self):
        """Met à jour les coordonnées de la zone cliente en pixels physiques."""
        if not self.target_window_title or self.target_window_title == "Écran Complet":
            self.monitor = {"top": 0, "left": 0, "width": 1920, "height": 1080}
            return

        try:
            import win32gui
            # Recherche de la fenêtre
            hwnd = win32gui.FindWindow(None, self.target_window_title)
            if hwnd:
                left, top, right, bot = win32gui.GetWindowRect(hwnd)
                # Récupérer l'origine absolue de la zone cliente de rendu de Dofus
                client_left, client_top = win32gui.ClientToScreen(hwnd, (0, 0))
                # Récupérer les dimensions exactes de la zone cliente de rendu
                _, _, client_w, client_h = win32gui.GetClientRect(hwnd)
                
                if client_w > 10 and client_h > 10:
                    self.monitor = {
                        "top": client_top, 
                        "left": client_left, 
                        "width": client_w, 
                        "height": client_h,
                        "win_top": top,
                        "win_left": left,
                        "win_width": right - left,
                        "win_height": bot - top
                    }
                    return
        except Exception as e:
            print(f"Erreur win32 GetClientRect: {e}")

        # Repli pygetwindow si win32 échoue
        try:
            win = gw.getWindowsWithTitle(self.target_window_title)[0]
            self.monitor = {"top": win.top, "left": win.left, "width": max(10, win.width), "height": max(10, win.height)}
        except IndexError:
            self.monitor = {"top": 0, "left": 0, "width": 1920, "height": 1080}
        
    def capture_background(self):
        """Capture la zone cliente de la fenêtre en arrière-plan de manière robuste via GDI PrintWindow."""
        if not self.target_window_title or self.target_window_title == "Écran Complet":
            return None
            
        import win32gui
        import win32ui
        import win32con
        import ctypes
        
        try:
            hwnd = win32gui.FindWindow(None, self.target_window_title)
            if not hwnd:
                return None
                
            # Récupérer la taille complète de la fenêtre (avec bordures)
            left, top, right, bot = win32gui.GetWindowRect(hwnd)
            win_w = right - left
            win_h = bot - top
            
            # Récupérer la position et taille de la zone cliente
            client_left, client_top = win32gui.ClientToScreen(hwnd, (0, 0))
            _, _, client_w, client_h = win32gui.GetClientRect(hwnd)
            
            if win_w <= 0 or win_h <= 0 or client_w <= 0 or client_h <= 0:
                return None
                
            hwndDC = win32gui.GetWindowDC(hwnd)
            mfcDC  = win32ui.CreateDCFromHandle(hwndDC)
            saveDC = mfcDC.CreateCompatibleDC()
            
            saveBitMap = win32ui.CreateBitmap()
            saveBitMap.CreateCompatibleBitmap(mfcDC, win_w, win_h)
            
            saveDC.SelectObject(saveBitMap)
            
            # PW_RENDERFULLCONTENT = 2 -> Capture de toute la fenêtre y compris DirectX
            result = ctypes.windll.user32.PrintWindow(hwnd, saveDC.GetSafeHdc(), 2)
            
            bmpinfo = saveBitMap.GetInfo()
            bmpstr = saveBitMap.GetBitmapBits(True)
            
            # Libérer les ressources GDI
            win32gui.DeleteObject(saveBitMap.GetHandle())
            saveDC.DeleteDC()
            mfcDC.DeleteDC()
            win32gui.ReleaseDC(hwnd, hwndDC)
            
            if result == 1:
                im = np.frombuffer(bmpstr, dtype='uint8')
                im.shape = (win_h, win_w, 4)
                img = cv2.cvtColor(im, cv2.COLOR_BGRA2BGR)
                
                # Calculer le décalage de la zone cliente par rapport au coin supérieur gauche de la fenêtre
                dx = client_left - left
                dy = client_top - top
                
                # Découpage pixel-perfect de la zone cliente
                x1 = max(0, dx)
                y1 = max(0, dy)
                x2 = min(win_w, x1 + client_w)
                y2 = min(win_h, y1 + client_h)
                
                return img[y1:y2, x1:x2]
                
        except Exception as e:
            print(f"Erreur capture arrière-plan: {e}")
            
        return None

    def get_latest_frame(self, background_mode=False):
        """Capture la zone cliente du jeu et retourne l'image."""
        if background_mode and self.target_window_title and self.target_window_title not in ["Écran Complet", "Zone Personnalisée"]:
            img = self.capture_background()
            if img is not None:
                return img
                
        # Capture directe et pixel-perfect via MSS à partir des coordonnées écran
        if self.target_window_title and self.target_window_title not in ["Écran Complet", "Zone Personnalisée"]:
            self.update_window_coordinates()
            
        screenshot = self.sct.grab(self.monitor)
        img = np.array(screenshot)
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
        return img
