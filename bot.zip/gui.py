import ctypes
# --- Rendre le processus DPI Aware pour éviter les décalages de capture sous Windows ---
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2) # Per-Monitor DPI Aware
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware() # System DPI Aware
    except Exception:
        pass

import sys, os

# --- Sorties "crash-proof" : empeche definitivement un print() de planter le bot ---
# Indispensable si le bot tourne sans console (ex: pythonw.exe), cas ou
# sys.stdout / sys.stderr valent None. Sans ca, le 1er print() leve une exception
# qui tue silencieusement le thread de combat -> "rien ne se passe a mon tour".
def _install_safe_output():
    try:
        if getattr(sys, "frozen", False):
            _base = os.path.dirname(sys.executable)
        else:
            _base = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        _base = os.getcwd()
    try:
        _logf = open(os.path.join(_base, "bot.log"), "a", encoding="utf-8", buffering=1)
    except Exception:
        _logf = None

    class _SafeStream:
        def __init__(self, real, logf):
            self._real, self._logf = real, logf
        def write(self, data):
            try:
                if self._real is not None:
                    self._real.write(data)
            except Exception:
                pass
            try:
                if self._logf is not None:
                    self._logf.write(data)
            except Exception:
                pass
            return len(data) if data else 0
        def flush(self):
            for s in (self._real, self._logf):
                try:
                    if s is not None:
                        s.flush()
                except Exception:
                    pass
        def isatty(self):
            try:
                return bool(self._real) and self._real.isatty()
            except Exception:
                return False

    sys.stdout = _SafeStream(sys.stdout, _logf)
    sys.stderr = _SafeStream(sys.stderr, _logf)

try:
    _install_safe_output()
except Exception:
    pass

import customtkinter as ctk
import tkinter as tk
from PIL import Image, ImageTk
import cv2
import os
import time
import numpy as np
import win32gui
import win32api
import win32con
import win32process
import keyboard

import datetime
import threading

from capture import DofusVision

# --- Structures CTYPES pour le clic et clavier Hardware ---
PUL = ctypes.POINTER(ctypes.c_ulong)
class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort),
                ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong),
                ("wParamL", ctypes.c_ushort),
                ("wParamH", ctypes.c_ushort)]

class Input_I(ctypes.Union):
    _fields_ = [("mi", MouseInput),
                ("ki", KeyBdInput),
                ("hi", HardwareInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]

# Flags Clavier
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008

def hardware_key(vk_code):
    extra = ctypes.c_ulong(0)
    scancode = ctypes.windll.user32.MapVirtualKeyW(vk_code, 0)
    
    # Appui (Scancode)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(0, scancode, KEYEVENTF_SCANCODE, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_) # 1 = INPUT_KEYBOARD
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
    
    time.sleep(0.015)
    
    # Relâchement (Scancode)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(0, scancode, KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def get_vk_code(key_str):
    key_str = key_str.lower().strip()
    if len(key_str) == 1:
        if 'a' <= key_str <= 'z':
            return ord(key_str.upper())
        if '0' <= key_str <= '9':
            return ord(key_str)
    
    if key_str.startswith('f') and len(key_str) > 1:
        try:
            num = int(key_str[1:])
            if 1 <= num <= 12:
                return 0x6F + num # F1 = 0x70, F2 = 0x71, ...
        except ValueError:
            pass
            
    common = {
        'enter': 0x0D,
        'space': 0x20,
        'escape': 0x1B,
        'tab': 0x09,
        'shift': 0x10,
        'ctrl': 0x11,
        'alt': 0x12,
        'capslock': 0x14,
    }
    return common.get(key_str, None)

class ToolTip:
    _active = None  # infobulle actuellement affichée (une seule à la fois)

    def __init__(self, widget, text, delay=400):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tip_window = None
        self.id = None
        self._watch_id = None
        
        # Liaison récursive sur le widget et tous ses enfants (pour survoler les textes, les cases, etc.)
        self.bind_widget_recursively(self.widget)

    def bind_widget_recursively(self, w):
        try:
            # add="+" permet de ne pas écraser les événements de CustomTkinter
            w.bind("<Enter>", self.start_timer, add="+")
            w.bind("<Leave>", self.hide_tip, add="+")
            w.bind("<ButtonPress>", self.hide_tip, add="+")
        except Exception:
            pass
            
        try:
            for child in w.winfo_children():
                self.bind_widget_recursively(child)
        except Exception:
            pass

    def start_timer(self, event=None):
        self.cancel_timer()
        self.id = self.widget.after(self.delay, self.show_tip)

    def cancel_timer(self):
        if self.id:
            self.widget.after_cancel(self.id)
            self.id = None

    def show_tip(self):
        self.cancel_timer()
        if self.tip_window or not self.text:
            return

        # Détruire toute autre infobulle encore affichée (une seule à la fois)
        other = ToolTip._active
        if other is not None and other is not self:
            try:
                other._destroy_tip()
            except Exception:
                pass

        x = self.widget.winfo_pointerx() + 12
        y = self.widget.winfo_pointery() + 12
        
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tw.attributes("-topmost", True)
        
        label = tk.Label(tw, text=self.text, justify='left',
                         background="#F0E3C0", fg="#3F2D16",
                         relief='flat', borderwidth=0,
                         font=("Helvetica", 9),
                         padx=8, pady=6)
        label.pack()
        tw.configure(background="#DB8A2E")

        ToolTip._active = self
        # Watchdog : surveille en continu si la souris a quitté le widget,
        # même si l'événement <Leave> ne se déclenche pas (souris rapide,
        # changement d'onglet, widget masqué...). Garantit la disparition.
        self._start_watchdog()

    def _start_watchdog(self):
        if self._watch_id:
            try:
                self.widget.after_cancel(self._watch_id)
            except Exception:
                pass
            self._watch_id = None
        if not self.tip_window:
            return
        try:
            px = self.widget.winfo_pointerx()
            py = self.widget.winfo_pointery()
            wx = self.widget.winfo_rootx()
            wy = self.widget.winfo_rooty()
            ww = self.widget.winfo_width()
            wh = self.widget.winfo_height()
            inside = (wx <= px <= wx + ww and wy <= py <= wy + wh)
        except Exception:
            inside = False
        if not inside:
            self._destroy_tip()
            return
        try:
            self._watch_id = self.widget.after(120, self._start_watchdog)
        except Exception:
            self._destroy_tip()

    def _destroy_tip(self):
        if self._watch_id:
            try:
                self.widget.after_cancel(self._watch_id)
            except Exception:
                pass
            self._watch_id = None
        tw = self.tip_window
        self.tip_window = None
        if tw:
            try:
                tw.destroy()
            except Exception:
                pass
        if ToolTip._active is self:
            ToolTip._active = None

    def hide_tip(self, event=None):
        self.cancel_timer()
        self._destroy_tip()

def get_game_rendering_hwnd(parent_hwnd):
    child_hwnds = []
    def enum_cb(hwnd, extra):
        child_hwnds.append(hwnd)
        return True
    try:
        import win32gui
        win32gui.EnumChildWindows(parent_hwnd, enum_cb, None)
    except Exception:
        pass
    if child_hwnds:
        for chwd in child_hwnds:
            try:
                class_name = win32gui.GetClassName(chwd)
                if "unity" in class_name.lower():
                    return chwd
            except Exception:
                pass
        return child_hwnds[0]
    return parent_hwnd

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Palette Retrozia — style Dofus Retro (parchemin / bois / orange)
BG_COLOR      = "#C9A874"   # bois-tan (fond fenêtre / cadre)
SIDEBAR_COLOR = "#E1CD98"   # parchemin (panneau gauche)
CARD_COLOR    = "#F0E3C0"   # parchemin clair (cartes / sections)
CARD2_COLOR   = "#E4D2A6"   # parchemin moyen (champs / sous-panneaux)
TEXT_COLOR    = "#3F2D16"   # brun foncé (texte)
TEXT_DIM      = "#7A5E3A"   # brun atténué
ACCENT_COLOR  = "#DB8A2E"   # orange Dofus (boutons)
ACCENT_HOVER  = "#EF9F3F"   # orange survol
ACCENT_LIGHT  = "#F5BC6B"   # orange clair (accents)
GREEN_COLOR   = "#6F9A4D"   # vert atténué (états actifs)
GREEN_HOVER   = "#5E8740"
RED_COLOR     = "#C85A30"   # rouge-brique (arrêt)
RED_HOVER     = "#AE4A24"
BORDER_COLOR  = "#9C7248"   # brun bois (bordures)


# Profils de vitesse : "Rapide" = valeurs actuelles (config rapide).
# "Normal"/"Lent" montent les délais pour machines/connexions plus lentes.
SPEED_PROFILES = {
    "Rapide": {
        "cap_combat_bg": 0.040, "cap_combat_fg": 0.018,
        "cap_map_bg": 0.012,    "cap_map_fg": 0.005,
        "poll_combat": 0.010,   "poll_map": 0.006,
        "key_bg": 0.015,        "key_fg": 0.005,
        "post_combat": 0.10,    "victory": 0.0,
    },
    "Normal": {
        "cap_combat_bg": 0.060, "cap_combat_fg": 0.030,
        "cap_map_bg": 0.030,    "cap_map_fg": 0.012,
        "poll_combat": 0.020,   "poll_map": 0.015,
        "key_bg": 0.060,        "key_fg": 0.050,
        "post_combat": 0.40,    "victory": 0.30,
    },
    "Lent": {
        "cap_combat_bg": 0.090, "cap_combat_fg": 0.050,
        "cap_map_bg": 0.050,    "cap_map_fg": 0.030,
        "poll_combat": 0.030,   "poll_map": 0.025,
        "key_bg": 0.130,        "key_fg": 0.110,
        "post_combat": 0.80,    "victory": 0.60,
    },
}


import random


class BotGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Retrozia Bot")
        self.geometry("1150x760")
        self.configure(fg_color=BG_COLOR)
        
        self.vision = DofusVision()
        self.is_capturing = False
        self.is_bot_active = False
        self.last_click_time = 0
        self.last_combat_button_loc = None
        self.last_victory_button_loc = None
        
        self.bot_state = "MAP" # MAP, COMBAT, VICTORY
        self.my_turn = False
        self.combat_zone = None
        self.is_defining_zone = False
        self.click_zone_mode = "Ligne"
        self.victory_time = 0
        self.last_victory_time = 0
        self.current_victory_delay = 0.0
        self.var_speed_profile = tk.StringVar(value="Rapide")
        self.current_map_delay = 3.0
        self.last_combat_time = 0
        self.combat_launching = False
        self.combat_launch_time = 0
        self.combat_button_seen = False
        self.combat_click_pos = None
        self._enu_chest_placed = False
        self.enu_zone = None
        self.enu_click_pos = None
        self.is_defining_enu_zone = False
        self._last_monster_click_time = 0
        self._last_monster_click_pos = None
        self._victory_confirm_count = 0
        self._failed_click_pos = None
        self._failed_click_time = 0
        self._failed_clicks = []  # liste de (x, y, timestamp) des groupes pris à éviter
        self.MONSTER_CLICK_MIN_COOLDOWN = 0.3
        self._bot_thread = None
        self._bot_stop_event = __import__('threading').Event()
        self.combat_count = 0
        
        # Configuration des dossiers de templates
        import sys
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
        self.config_file = os.path.join(base_dir, "config.json")
        self.templates_dir = os.path.join(base_dir, "templates")
        self.templates_monstres = os.path.join(self.templates_dir, "monstres")
        self.templates_combat = os.path.join(self.templates_dir, "combat")
        self.templates_victoire = os.path.join(self.templates_dir, "victoire")
        self.templates_modo = os.path.join(self.templates_dir, "modo")
        self.templates_menu = os.path.join(self.templates_dir, "menu")
        
        os.makedirs(self.templates_monstres, exist_ok=True)
        os.makedirs(self.templates_combat, exist_ok=True)
        os.makedirs(self.templates_victoire, exist_ok=True)
        os.makedirs(self.templates_modo, exist_ok=True)
        os.makedirs(self.templates_menu, exist_ok=True)
        
        # Cache mémoire pour éviter les lectures disque de templates à chaque frame
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: []
        }
        
        self.is_defining_modo_chat = False
        self.modo_chat_x = None
        self.modo_chat_y = None
        self.modo_crop_x = None
        self.modo_crop_y = None
        self.modo_crop_w = None
        self.modo_crop_h = None
        
        self.templates_pods = os.path.join(self.templates_dir, "pods")
        os.makedirs(self.templates_pods, exist_ok=True)
        self.templates_pods_bank = os.path.join(self.templates_dir, "pods_bank")
        os.makedirs(self.templates_pods_bank, exist_ok=True)
        self.templates_pods_transfers = os.path.join(self.templates_dir, "pods_transfers")
        os.makedirs(self.templates_pods_transfers, exist_ok=True)
        self.templates_pods_transfer_all = os.path.join(self.templates_dir, "pods_transfer_all")
        os.makedirs(self.templates_pods_transfer_all, exist_ok=True)
        
        # Cache mémoire pour éviter les lectures disque de templates à chaque frame
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: [],
            self.templates_pods: [],
            self.templates_pods_bank: [],
            self.templates_pods_transfers: [],
            self.templates_pods_transfer_all: []
        }
        self.var_pods_capture_type = tk.StringVar(value="Alerte")
        self.farm_commands_sent = False
        
        self.is_defining_pods_bank = False
        self.is_defining_pods_transfers = False
        self.is_defining_pods_transfer_all = False
        
        self.pods_bank_x = None
        self.pods_bank_y = None
        self.pods_transfers_x = None
        self.pods_transfers_y = None
        self.pods_transfer_all_x = None
        self.pods_transfer_all_y = None
        
        self.ctk_image = None
        self.current_cv_img = None
        self.scale_ratio = 1.0
        self.x_offset = 0
        self.y_offset = 0
        
                # ══════════════════════════════════════
        # SIDEBAR RETROZIA
        # ══════════════════════════════════════
        self.sidebar_frame = ctk.CTkFrame(self, width=345, corner_radius=0, fg_color=SIDEBAR_COLOR)
        self.sidebar_frame.pack(side="left", fill="y")
        self.sidebar_frame.pack_propagate(False)

        # ── HEADER ────────────────────────────────────
        header_bg = ctk.CTkFrame(self.sidebar_frame, fg_color="#D8BE86", corner_radius=0, height=70)
        header_bg.pack(fill="x")
        header_bg.pack_propagate(False)

        # Logo RETRO (blanc) + ZIA (violet)
        lf = ctk.CTkFrame(header_bg, fg_color="transparent")
        lf.place(x=12, y=10)
        ctk.CTkLabel(lf, text="RETRO", font=ctk.CTkFont(family="Arial Black", size=20, weight="bold"),
            text_color="#3F2D16").pack(side="left")
        ctk.CTkLabel(lf, text="ZIA", font=ctk.CTkFont(family="Arial Black", size=20, weight="bold"),
            text_color=ACCENT_HOVER).pack(side="left")
        self.logo_label = ctk.CTkLabel(lf, text="", text_color=TEXT_COLOR)  # compatibilité
        ctk.CTkLabel(header_bg, text="Bot de combat automatique • Dofus 2.64",
            font=ctk.CTkFont(size=9), text_color=TEXT_DIM).place(x=14, y=44)

        # Boutons action (droite du header)
        self.btn_capture = ctk.CTkButton(header_bg, text="👁 Aperçu", command=self.toggle_capture,
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
            font=ctk.CTkFont(weight="bold", size=11), width=88, height=26, corner_radius=5)
        self.btn_capture.place(x=170, y=10)
        self.btn_open_folder = ctk.CTkButton(header_bg, text="📂", command=self.open_templates_folder,
            fg_color=CARD_COLOR, hover_color=CARD2_COLOR, text_color=TEXT_COLOR,
            width=26, height=26, corner_radius=5)
        self.btn_open_folder.place(x=264, y=10)
        self.btn_show_last_match = ctk.CTkButton(header_bg, text="🔍", command=self.open_last_match,
            fg_color=CARD_COLOR, hover_color=CARD2_COLOR, text_color=TEXT_COLOR,
            width=26, height=26, corner_radius=5)
        self.btn_show_last_match.place(x=296, y=10)

        # Ligne violette sous le header
        ctk.CTkFrame(self.sidebar_frame, height=2, fg_color=ACCENT_COLOR).pack(fill="x")

        # ── SCROLLABLE SETTINGS ───────────────────────
        self.scroll_frame = ctk.CTkScrollableFrame(self.sidebar_frame, fg_color="transparent",
            corner_radius=0, scrollbar_button_color=ACCENT_COLOR,
            scrollbar_button_hover_color=ACCENT_HOVER)
        self.scroll_frame.pack(fill="both", expand=True)

        def _mk_card(parent, title):
            """Crée une carte avec bandeau titre."""
            c = ctk.CTkFrame(parent, fg_color=CARD_COLOR, corner_radius=10,
                border_width=1, border_color=BORDER_COLOR)
            c.pack(pady=(8, 0), padx=10, fill="x")
            band = ctk.CTkFrame(c, fg_color="#D8C28C", corner_radius=8, height=26)
            band.pack(fill="x", padx=1, pady=(1, 0))
            band.pack_propagate(False)
            ctk.CTkLabel(band, text=title, font=ctk.CTkFont(weight="bold", size=11),
                text_color=TEXT_COLOR).pack(side="left", padx=10, pady=4)
            return c

        def _mk_row(parent, label_text, pady=3):
            """Ligne label + widget à droite."""
            f = ctk.CTkFrame(parent, fg_color="transparent")
            f.pack(fill="x", padx=10, pady=pady)
            ctk.CTkLabel(f, text=label_text, font=ctk.CTkFont(size=11),
                text_color=TEXT_COLOR, anchor="w").pack(side="left")
            return f

        def _mk_entry(parent, default, width=48):
            e = ctk.CTkEntry(parent, width=width, height=22, font=ctk.CTkFont(size=11),
                justify="center", fg_color="#F6ECD4",
                border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
            e.insert(0, default)
            e.pack(side="right")
            return e

        def _mk_checkbox(parent, text, var, pady=4, padx=10):
            cb = ctk.CTkCheckBox(parent, text=text, variable=var,
                font=ctk.CTkFont(size=11), text_color=TEXT_COLOR,
                fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
                checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
            cb.pack(pady=pady, padx=padx, anchor="w")
            return cb

        def _mk_slider(parent, from_, to, default, command, pady=(2,6)):
            s = ctk.CTkSlider(parent, from_=from_, to=to, command=command,
                height=14, button_color=ACCENT_HOVER, button_hover_color=ACCENT_LIGHT,
                progress_color=ACCENT_COLOR, fg_color=CARD2_COLOR)
            s.set(default)
            s.pack(padx=10, pady=pady, fill="x")
            return s

        # ── CARTE FENÊTRE & CAPTURE ───────────────────
        self.win_card = _mk_card(self.scroll_frame, "🖥  FENÊTRE & CAPTURE")

        row_win = ctk.CTkFrame(self.win_card, fg_color="transparent")
        row_win.pack(fill="x", padx=10, pady=(6, 2))
        self.window_label = ctk.CTkLabel(row_win, text="Fenêtre :", font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM, width=58, anchor="w")
        self.window_label.pack(side="left")
        self.window_selector = ctk.CTkOptionMenu(row_win, values=["Écran Complet"],
            command=self.on_window_selected,
            fg_color=CARD2_COLOR, button_color=ACCENT_COLOR, button_hover_color=ACCENT_HOVER,
            text_color=TEXT_COLOR, dropdown_fg_color=CARD_COLOR, dropdown_text_color=TEXT_COLOR,
            dropdown_hover_color=ACCENT_COLOR, height=24)
        self.window_selector.pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.btn_refresh = ctk.CTkButton(row_win, text="🔄", command=self.refresh_window_list,
            fg_color="transparent", border_width=1, border_color=ACCENT_COLOR,
            text_color=ACCENT_COLOR, width=26, height=24, corner_radius=5)
        self.btn_refresh.pack(side="left", padx=(4, 0))

        self.opts_card = ctk.CTkFrame(self.win_card, fg_color="transparent")
        self.opts_card.pack(fill="x", padx=0, pady=0)
        self.opts_header = ctk.CTkLabel(self.opts_card, text="")  # dummy ref

        row_chk = ctk.CTkFrame(self.win_card, fg_color="transparent")
        row_chk.pack(fill="x", padx=10, pady=(4, 2))
        self.var_background_mode = tk.BooleanVar(value=False)
        self.chk_background_mode = ctk.CTkCheckBox(row_chk, text="Fantôme",
            variable=self.var_background_mode, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_background_mode.pack(side="left", padx=(0, 8))

        self.var_hidden_capture = tk.BooleanVar(value=False)
        self.hidden_capture_active = False
        def update_hidden_capture(*args):
            self.hidden_capture_active = self.var_hidden_capture.get()
        self.var_hidden_capture.trace_add("write", update_hidden_capture)
        self.chk_hidden_capture = ctk.CTkCheckBox(row_chk, text="Masquée",
            variable=self.var_hidden_capture, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_hidden_capture.pack(side="left", padx=(0, 8))

        self.var_dpi_scaling = tk.BooleanVar(value=False)
        self.chk_dpi_scaling = ctk.CTkCheckBox(row_chk, text="Fix DPI",
            variable=self.var_dpi_scaling, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_dpi_scaling.pack(side="left")

        # Précision IA
        self.sens_frame = ctk.CTkFrame(self.win_card, fg_color="transparent")
        self.sens_frame.pack(fill="x", padx=10, pady=(4, 2))
        self.sens_label = ctk.CTkLabel(self.sens_frame, text="🎯 Précision IA :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.sens_label.pack(side="left")
        self.sens_pct = ctk.CTkLabel(self.sens_frame, text="%",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.sens_pct.pack(side="right", padx=(0, 2))
        self.sens_entry = ctk.CTkEntry(self.sens_frame, width=38, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.sens_entry.insert(0, "60")
        self.sens_entry.pack(side="right")
        self.sens_entry.bind("<Return>", self._on_sens_entry)
        self.sens_entry.bind("<FocusOut>", self._on_sens_entry)
        self.sens_entry.bind("<KeyRelease>", self._on_sens_keyrelease)
        self.slider = _mk_slider(self.win_card, 0.3, 0.95, 0.60, self.update_sens, pady=(0, 8))


        # ── TABVIEW ────────────────────────────────────
        self.tabview = ctk.CTkTabview(self.scroll_frame, fg_color=CARD_COLOR,
            segmented_button_selected_color=ACCENT_COLOR,
            segmented_button_selected_hover_color=ACCENT_HOVER,
            segmented_button_unselected_color=CARD2_COLOR,
            segmented_button_unselected_hover_color="#E4D2A6",
            text_color=TEXT_COLOR, text_color_disabled=TEXT_DIM,
            border_width=1, border_color=BORDER_COLOR)
        self.tabview._segmented_button.configure(font=ctk.CTkFont(size=10, weight="bold"))
        self.tabview.pack(pady=8, padx=10, fill="both", expand=True)

        self.tabview.add("🗺️ Carte")
        self.tabview.add("⚔️ Combat")
        self.tabview.add("🏆 Victoire")
        self.tabview.add("🛡️ Modo")
        self.tabview.add("🎒 Pods")

        # ─── TAB CARTE ────────────────────────────────
        tab_carte = self.tabview.tab("🗺️ Carte")
        ctk.CTkLabel(tab_carte, text="Clic droit sur la vidéo pour capturer un monstre.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8, 4))

        # ─── Vitesse globale (cadence de capture/scan + délais) — adapte à la machine ───
        speed_frame = ctk.CTkFrame(tab_carte, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        speed_frame.pack(pady=(2, 8), padx=10, fill="x")
        speed_top = ctk.CTkFrame(speed_frame, fg_color="transparent")
        speed_top.pack(fill="x", padx=10, pady=(6, 0))
        ctk.CTkLabel(speed_top, text="⚡ Vitesse globale", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11, weight="bold")).pack(side="left")
        self.lbl_speed = ctk.CTkLabel(speed_top, text="Rapide", text_color=ACCENT_COLOR,
            font=ctk.CTkFont(size=10, weight="bold"))
        self.lbl_speed.pack(side="right")
        self.slider_speed = ctk.CTkSlider(speed_frame, from_=1, to=10, number_of_steps=18,
            fg_color=CARD_COLOR, progress_color=ACCENT_COLOR, button_color=ACCENT_HOVER,
            button_hover_color=ACCENT_LIGHT, command=self._on_speed_change)
        self.slider_speed.set(10)
        self.slider_speed.pack(fill="x", padx=10, pady=(2, 2))
        sl_lbls = ctk.CTkFrame(speed_frame, fg_color="transparent")
        sl_lbls.pack(fill="x", padx=10, pady=(0, 4))
        ctk.CTkLabel(sl_lbls, text="🐢 Lent", text_color=TEXT_DIM, font=ctk.CTkFont(size=9)).pack(side="left")
        ctk.CTkLabel(sl_lbls, text="Rapide 🐇", text_color=TEXT_DIM, font=ctk.CTkFont(size=9)).pack(side="right")
        ctk.CTkLabel(speed_frame, text="↳ Baisse-la si le bot bug/rame sur une machine moins puissante.",
            font=ctk.CTkFont(size=9), text_color=TEXT_DIM).pack(anchor="w", padx=12, pady=(0, 6))

        self.map_delay_frame = _mk_row(tab_carte, "Délai carte (s) :")
        self.lbl_map_delay = self.map_delay_frame.winfo_children()[0]
        self.entry_map_delay = _mk_entry(self.map_delay_frame, "0.0")
        self.entry_map_delay.bind("<Return>", self._on_map_delay_entry)
        self.entry_map_delay.bind("<FocusOut>", self._on_map_delay_entry)

        self.launch_timeout_frame = _mk_row(tab_carte, "Attente lancement (s) :")
        self.lbl_launch_timeout = self.launch_timeout_frame.winfo_children()[0]
        self.entry_launch_timeout = _mk_entry(self.launch_timeout_frame, "8.0")
        self.entry_launch_timeout.bind("<Return>", self._on_launch_timeout_entry)
        self.entry_launch_timeout.bind("<FocusOut>", self._on_launch_timeout_entry)

        self.cooldown_frame = _mk_row(tab_carte, "⏱ Cooldown monstre (s) :")
        self.entry_monster_cooldown = _mk_entry(self.cooldown_frame, "0.0")
        self.entry_monster_cooldown.bind("<Return>", self._on_monster_cooldown_entry)
        self.entry_monster_cooldown.bind("<FocusOut>", self._on_monster_cooldown_entry)

        self.var_close_menu = tk.BooleanVar(value=True)
        self.chk_close_menu = _mk_checkbox(tab_carte, "❌ Fermer Menu Principal", self.var_close_menu)

        self.var_spell_right_click = tk.BooleanVar(value=False)
        self.var_infinite_click = tk.BooleanVar(value=False)
        self.var_enu_mode = tk.BooleanVar(value=False)
        self.var_enu_chest_once = tk.BooleanVar(value=True)
        self.var_roi_enabled = tk.BooleanVar(value=True)
        self.var_fast_detect = tk.BooleanVar(value=True)
        self.var_adaptive_capture = tk.BooleanVar(value=True)
        self.var_spell_right_clicks_min = tk.StringVar(value="1")
        self.var_spell_right_clicks_max = tk.StringVar(value="3")

        self.chk_roi = _mk_checkbox(tab_carte, "⚡ Zones optimisées (perf)", self.var_roi_enabled)
        self.chk_roi.configure(command=self.save_config)
        self.chk_fast_detect = _mk_checkbox(tab_carte, "⚡ Détection rapide 2 temps (perf)", self.var_fast_detect)
        self.chk_fast_detect.configure(command=self.save_config)
        self.chk_adaptive = _mk_checkbox(tab_carte, "⚡ Cadence adaptative (CPU/fluidité)", self.var_adaptive_capture)
        self.chk_adaptive.configure(command=self.save_config)

        self.var_carte_capture_type = tk.StringVar(value="Monstres")
        self.carte_capture_selector = ctk.CTkSegmentedButton(tab_carte,
            values=["Monstres", "Menu Principal"], variable=self.var_carte_capture_type,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, unselected_hover_color="#E4D2A6",
            text_color=TEXT_COLOR, height=24)
        self.carte_capture_selector.pack(pady=4, padx=10, fill="x")

        self.clear_buttons_frame = ctk.CTkFrame(tab_carte, fg_color="transparent")
        self.clear_buttons_frame.pack(pady=4, padx=10, fill="x")
        self.btn_clear = ctk.CTkButton(self.clear_buttons_frame, text="🗑 Monstres",
            command=self.clear_monstres, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(size=11, weight="bold"), height=26, corner_radius=6)
        self.btn_clear.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_clear_menu = ctk.CTkButton(self.clear_buttons_frame, text="🗑 Menu",
            command=self.clear_menu, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(size=11, weight="bold"), height=26, corner_radius=6)
        self.btn_clear_menu.pack(side="right", fill="x", expand=True)

        # ─── TAB COMBAT ───────────────────────────────
        tab_combat = self.tabview.tab("⚔️ Combat")

        self.btn_define_zone = ctk.CTkButton(tab_combat,
            text="🎯  Dessiner Zone de Clic  (Clic Droit)",
            command=self.toggle_define_zone, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold", size=11), height=30, corner_radius=6)
        self.btn_define_zone.pack(pady=(8, 4), padx=10, fill="x")

        self.zone_mode_var = tk.StringVar(value="Ligne")
        self.zone_mode_selector = ctk.CTkSegmentedButton(tab_combat,
            values=["Ligne", "Rectangle"], variable=self.zone_mode_var,
            command=self.on_zone_mode_changed,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=24)
        self.zone_mode_selector.pack(pady=2, padx=10, fill="x")

        self.zone_coords_frame = ctk.CTkFrame(tab_combat, fg_color="transparent")
        self.zone_coords_frame.pack(pady=2, padx=10, fill="x")
        _eopt = dict(width=34, height=20, font=ctk.CTkFont(size=10),
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_zone_x = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_x.grid(row=0, column=0, padx=2, pady=1)
        self.entry_zone_y = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_y.grid(row=0, column=1, padx=2, pady=1)
        self.entry_zone_w = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_w.grid(row=1, column=0, padx=2, pady=1)
        self.entry_zone_h = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_h.grid(row=1, column=1, padx=2, pady=1)
        self.btn_apply_zone = ctk.CTkButton(self.zone_coords_frame, text="✅",
            width=30, height=42, font=ctk.CTkFont(size=14), command=self.apply_manual_zone,
            fg_color=GREEN_COLOR, hover_color=GREEN_HOVER, text_color="#0B1A10", corner_radius=6)
        self.btn_apply_zone.grid(row=0, column=2, rowspan=2, padx=4, pady=1)

        gf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        gf.pack(pady=4, padx=10, fill="x")
        self.grid_frame = gf

        # Row 1: Touche Sort + Clic droit checkbox
        row1 = ctk.CTkFrame(gf, fg_color="transparent")
        row1.pack(fill="x", padx=10, pady=4)
        ctk.CTkLabel(row1, text="Touche Sort :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=80, anchor="w").pack(side="left", padx=(0,4))
        self.entry_spell_key = ctk.CTkEntry(row1, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_spell_key.insert(0, "1")
        self.entry_spell_key.pack(side="left", padx=2)
        self.chk_spell_right_click = ctk.CTkCheckBox(row1, text="Clic droit (sort)",
            variable=self.var_spell_right_click, font=ctk.CTkFont(size=10),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16,
            command=self.save_config)
        self.chk_spell_right_click.pack(side="left", padx=(20,0))

        # Row 2: Min clics
        row2 = ctk.CTkFrame(gf, fg_color="transparent")
        row2.pack(fill="x", padx=10, pady=2)
        ctk.CTkLabel(row2, text="Min clics :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=80, anchor="w").pack(side="left", padx=(0,4))
        self.entry_right_clicks_min = ctk.CTkEntry(row2, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_right_clicks_min.insert(0, "1")
        self.entry_right_clicks_min.pack(side="left", padx=2)

        # Row 3: Max clics
        row3 = ctk.CTkFrame(gf, fg_color="transparent")
        row3.pack(fill="x", padx=10, pady=2)
        ctk.CTkLabel(row3, text="Max clics :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=80, anchor="w").pack(side="left", padx=(0,4))
        self.entry_right_clicks_max = ctk.CTkEntry(row3, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_right_clicks_max.insert(0, "3")
        self.entry_right_clicks_max.pack(side="left", padx=2)

        # Row 4: Nb Lancers
        row4 = ctk.CTkFrame(gf, fg_color="transparent")
        row4.pack(fill="x", padx=10, pady=4)
        ctk.CTkLabel(row4, text="Nb Lancers :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=80, anchor="w").pack(side="left", padx=(0,4))
        self.entry_chain_count = ctk.CTkEntry(row4, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_chain_count.insert(0, "2")
        self.entry_chain_count.pack(side="left", padx=2)
        self.entry_chain_count.bind("<Return>", self._on_chain_count_entry)
        self.entry_chain_count.bind("<FocusOut>", self._on_chain_count_entry)

        self.delay_frame = ctk.CTkFrame(gf, fg_color="transparent")
        self.delay_frame.pack(fill="x", padx=10, pady=(4,0))
        self.lbl_delay = ctk.CTkLabel(self.delay_frame, text="Délai (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_delay.pack(side="left", padx=4)
        self.entry_delay = ctk.CTkEntry(self.delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_delay.insert(0, "0.08")
        self.entry_delay.pack(side="right", padx=4)
        self.entry_delay.bind("<Return>", self._on_delay_entry)
        self.entry_delay.bind("<FocusOut>", self._on_delay_entry)
        self.entry_delay.bind("<KeyRelease>", self._on_delay_keyrelease)
        self.slider_delay = ctk.CTkSlider(gf, from_=0.01, to=1.0, number_of_steps=99,
            command=self.update_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_delay.set(0.08)
        self.slider_delay.pack(fill="x", padx=10, pady=(2,8))

        # ─── Mode Enutrof (poser le coffre + lancer Chance dessus) ───
        enf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        enf.pack(pady=4, padx=10, fill="x")
        self.chk_enu_mode = ctk.CTkCheckBox(enf, text="🪙 Mode Enutrof (coffre + Chance + sort)",
            variable=self.var_enu_mode, font=ctk.CTkFont(size=11, weight="bold"),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16,
            command=self._on_enu_mode_toggle)
        self.chk_enu_mode.pack(anchor="w", padx=10, pady=(8,2))

        enu_row = ctk.CTkFrame(enf, fg_color="transparent")
        enu_row.pack(fill="x", padx=10, pady=2)
        ctk.CTkLabel(enu_row, text="Touche Coffre :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=110, anchor="w").pack(side="left", padx=(0,4))
        self.entry_enu_chest_key = ctk.CTkEntry(enu_row, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_enu_chest_key.insert(0, "5")
        self.entry_enu_chest_key.pack(side="left", padx=2)

        enu_row2 = ctk.CTkFrame(enf, fg_color="transparent")
        enu_row2.pack(fill="x", padx=10, pady=2)
        ctk.CTkLabel(enu_row2, text="Touche Chance :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11), width=110, anchor="w").pack(side="left", padx=(0,4))
        self.entry_enu_chance_key = ctk.CTkEntry(enu_row2, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_enu_chance_key.insert(0, "6")
        self.entry_enu_chance_key.pack(side="left", padx=2)

        self.chk_enu_chest_once = ctk.CTkCheckBox(enf, text="Poser le coffre au 1er tour seulement",
            variable=self.var_enu_chest_once, font=ctk.CTkFont(size=10),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16,
            command=self.save_config)
        self.chk_enu_chest_once.pack(anchor="w", padx=10, pady=(2,4))

        self.btn_define_enu_zone = ctk.CTkButton(enf, text="🎯 Dessiner Zone Coffre (Clic Droit)",
            command=self.toggle_define_enu_zone, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(size=11, weight="bold"), height=26)
        self.btn_define_enu_zone.pack(fill="x", padx=10, pady=(2,2))
        self.lbl_enu_zone = ctk.CTkLabel(enf, text="Zone coffre : non définie",
            font=ctk.CTkFont(size=9), text_color=TEXT_DIM)
        self.lbl_enu_zone.pack(anchor="w", padx=12, pady=(0,2))
        ctk.CTkLabel(enf, text="↳ Combo : coffre + Chance (Zone Coffre), puis sort « Touche Sort » (Zone de Clic).",
            font=ctk.CTkFont(size=9), text_color=TEXT_DIM).pack(anchor="w", padx=12, pady=(0,8))

        # ─── Clic infini (spam la case du sort en parallèle) ───
        icf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        icf.pack(pady=4, padx=10, fill="x")
        icf_row = ctk.CTkFrame(icf, fg_color="transparent")
        icf_row.pack(fill="x", padx=10, pady=6)
        self.chk_infinite_click = ctk.CTkCheckBox(icf_row, text="Clic infini sur la case",
            variable=self.var_infinite_click, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16,
            command=self.save_config)
        self.chk_infinite_click.pack(side="left", padx=(0,4))
        ctk.CTkLabel(icf_row, text="Délai :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=10)).pack(side="left", padx=(14,4))
        self.entry_infinite_delay = ctk.CTkEntry(icf_row, width=55, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_infinite_delay.insert(0, "0.05")
        self.entry_infinite_delay.pack(side="left", padx=2)
        self.entry_infinite_delay.bind("<Return>", self._on_infinite_delay_entry)
        self.entry_infinite_delay.bind("<FocusOut>", self._on_infinite_delay_entry)

        pf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        pf.pack(pady=4, padx=10, fill="x")
        self.pass_frame = pf
        self.var_pass_turn = tk.BooleanVar(value=True)
        self.chk_pass_turn = ctk.CTkCheckBox(pf, text="Passer le Tour :",
            variable=self.var_pass_turn, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_pass_turn.grid(row=0, column=0, padx=(10,4), pady=6, sticky="w")
        self.entry_pass_key = ctk.CTkEntry(pf, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_pass_key.insert(0, "f1")
        self.entry_pass_key.grid(row=0, column=1, padx=4, pady=6)

        self.start_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.start_delay_frame.grid(row=1, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_start_delay = ctk.CTkLabel(self.start_delay_frame, text="Attente début (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_start_delay.pack(side="left", padx=4)
        self.entry_start_delay = ctk.CTkEntry(self.start_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_start_delay.insert(0, "0.30")
        self.entry_start_delay.pack(side="right", padx=4)
        self.entry_start_delay.bind("<Return>", self._on_start_delay_entry)
        self.entry_start_delay.bind("<FocusOut>", self._on_start_delay_entry)
        self.entry_start_delay.bind("<KeyRelease>", self._on_start_delay_keyrelease)
        self.slider_start_delay = ctk.CTkSlider(pf, from_=0.001, to=2.0, number_of_steps=1999,
            command=self.update_start_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_start_delay.set(0.30)
        self.slider_start_delay.grid(row=2, column=0, columnspan=2, padx=10, pady=(0,4), sticky="ew")

        self.end_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.end_delay_frame.grid(row=3, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_end_delay = ctk.CTkLabel(self.end_delay_frame, text="Délai fin tour (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_end_delay.pack(side="left", padx=4)
        self.entry_end_delay = ctk.CTkEntry(self.end_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_end_delay.insert(0, "0.15")
        self.entry_end_delay.pack(side="right", padx=4)
        self.entry_end_delay.bind("<Return>", self._on_end_delay_entry)
        self.entry_end_delay.bind("<FocusOut>", self._on_end_delay_entry)
        self.entry_end_delay.bind("<KeyRelease>", self._on_end_delay_keyrelease)
        self.slider_end_delay = ctk.CTkSlider(pf, from_=0.001, to=2.0, number_of_steps=1999,
            command=self.update_end_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_end_delay.set(0.15)
        self.slider_end_delay.grid(row=4, column=0, columnspan=2, padx=10, pady=(0,8), sticky="ew")

        self.ready_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.ready_delay_frame.grid(row=5, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_ready_delay = ctk.CTkLabel(self.ready_delay_frame, text="Attente après Prêt (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_ready_delay.pack(side="left", padx=4)
        self.entry_ready_delay = ctk.CTkEntry(self.ready_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_ready_delay.insert(0, "0.50")
        self.entry_ready_delay.pack(side="right", padx=4)
        self.entry_ready_delay.bind("<Return>", self._on_ready_delay_entry)
        self.entry_ready_delay.bind("<FocusOut>", self._on_ready_delay_entry)
        self.entry_ready_delay.bind("<KeyRelease>", self._on_ready_delay_keyrelease)
        self.slider_ready_delay = ctk.CTkSlider(pf, from_=0.001, to=2.0, number_of_steps=1999,
            command=self.update_ready_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_ready_delay.set(0.50)
        self.slider_ready_delay.grid(row=6, column=0, columnspan=2, padx=10, pady=(0,8), sticky="ew")

        self.btn_clear_combat = ctk.CTkButton(tab_combat, text="🗑  Effacer modèles 'Prêt'",
            command=self.clear_combat, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_combat.pack(pady=6, padx=10, fill="x")

        # ─── TAB VICTOIRE ─────────────────────────────
        tab_victoire = self.tabview.tab("🏆 Victoire")
        ctk.CTkLabel(tab_victoire, text="Clic droit pour capturer le bouton 'Fermer'.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8,4))
        self.var_victory_esc = tk.BooleanVar(value=True)
        self.chk_victory_esc = _mk_checkbox(tab_victoire, "⌨️ Fermer par touche Echap", self.var_victory_esc)

        self.victory_delay_frame = ctk.CTkFrame(tab_victoire, fg_color="transparent")
        self.victory_delay_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_victory_title = ctk.CTkLabel(self.victory_delay_frame,
            text="Retour carte (s)  Min", font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_victory_title.pack(side="left")
        _e = dict(width=34, height=22, font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_victory_delay_min = ctk.CTkEntry(self.victory_delay_frame, **_e)
        self.entry_victory_delay_min.insert(0, "0.0")
        self.entry_victory_delay_min.pack(side="left", padx=2)
        self.entry_victory_delay_min.bind("<Return>", self._on_victory_delay_min_entry)
        self.entry_victory_delay_min.bind("<FocusOut>", self._on_victory_delay_min_entry)
        self.lbl_to = ctk.CTkLabel(self.victory_delay_frame, text="Max",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_to.pack(side="left", padx=(6,2))
        self.entry_victory_delay_max = ctk.CTkEntry(self.victory_delay_frame, **_e)
        self.entry_victory_delay_max.insert(0, "0.0")
        self.entry_victory_delay_max.pack(side="left", padx=2)
        self.entry_victory_delay_max.bind("<Return>", self._on_victory_delay_max_entry)
        self.entry_victory_delay_max.bind("<FocusOut>", self._on_victory_delay_max_entry)

        self.victory_cooldown_frame = ctk.CTkFrame(tab_victoire, fg_color="transparent")
        self.victory_cooldown_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_victory_cooldown = ctk.CTkLabel(self.victory_cooldown_frame,
            text="Cooldown (s) :", font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_victory_cooldown.pack(side="left")
        self.entry_victory_cooldown = ctk.CTkEntry(self.victory_cooldown_frame, **_e)
        self.entry_victory_cooldown.insert(0, "0.0")
        self.entry_victory_cooldown.pack(side="right")
        self.entry_victory_cooldown.bind("<Return>", self._on_victory_cooldown_entry)
        self.entry_victory_cooldown.bind("<FocusOut>", self._on_victory_cooldown_entry)

        self.btn_clear_victoire = ctk.CTkButton(tab_victoire, text="🗑  Effacer modèles Victoire",
            command=self.clear_victoire, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_victoire.pack(pady=6, padx=10, fill="x")

        # ─── TAB MODO ─────────────────────────────────
        tab_modo = self.tabview.tab("🛡️ Modo")
        self.modo_inner_frame = ctk.CTkFrame(tab_modo, fg_color="transparent")
        self.modo_inner_frame.pack(fill="both", expand=True)
        self.var_modo_enabled = tk.BooleanVar(value=False)
        self.chk_modo_enabled = _mk_checkbox(self.modo_inner_frame, "🛡️ Activer Anti-Modo", self.var_modo_enabled, pady=8)

        self.modo_mode_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.modo_mode_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_modo_mode = ctk.CTkLabel(self.modo_mode_frame, text="Mode :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_modo_mode.pack(side="left", padx=4)
        self.var_modo_trigger_mode = tk.StringVar(value="Présence")
        self.modo_mode_selector = ctk.CTkSegmentedButton(self.modo_mode_frame,
            values=["Présence","Changement"], variable=self.var_modo_trigger_mode,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=22)
        self.modo_mode_selector.pack(side="right", fill="x", expand=True, padx=4)

        self.modo_text_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.modo_text_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_modo_text = ctk.CTkLabel(self.modo_text_frame, text="Message :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_modo_text.pack(side="left", padx=4)
        self.entry_modo_text = ctk.CTkEntry(self.modo_text_frame, height=22,
            font=ctk.CTkFont(size=11), fg_color=CARD2_COLOR,
            border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_modo_text.insert(0, "oui ?")
        self.entry_modo_text.pack(side="right", fill="x", expand=True, padx=4)
        self.entry_modo_text.bind("<Return>", lambda e: self.save_config())
        self.entry_modo_text.bind("<FocusOut>", lambda e: self.save_config())

        self.sens_modo_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.sens_modo_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_sens_modo_title = ctk.CTkLabel(self.sens_modo_frame, text="Précision :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_sens_modo_title.pack(side="left", padx=4)
        self.entry_modo_sens = ctk.CTkEntry(self.sens_modo_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_modo_sens.insert(0, "80")
        self.entry_modo_sens.pack(side="right", padx=4)
        self.entry_modo_sens.bind("<Return>", self._on_modo_sens_entry)
        self.entry_modo_sens.bind("<FocusOut>", self._on_modo_sens_entry)
        self.entry_modo_sens.bind("<KeyRelease>", self._on_modo_sens_keyrelease)
        self.slider_modo = _mk_slider(self.modo_inner_frame, 0.3, 0.95, 0.80, self.update_modo_sens)

        self.chat_pos_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.chat_pos_frame.pack(pady=3, padx=10, fill="x")
        self.btn_define_modo_chat = ctk.CTkButton(self.chat_pos_frame,
            text="💬 Définir Clic Chat", command=self.toggle_define_modo_chat,
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
            font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_define_modo_chat.pack(fill="x")
        self.lbl_modo_chat_coords = ctk.CTkLabel(self.modo_inner_frame,
            text="Clic Chat : Aucun", font=ctk.CTkFont(size=11), text_color=TEXT_DIM)
        self.lbl_modo_chat_coords.pack(pady=2, padx=10)
        self.btn_clear_modo = ctk.CTkButton(self.modo_inner_frame, text="🗑️ Effacer Modèles Modo",
            command=self.clear_modo, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_modo.pack(pady=6, padx=10, fill="x")

        # ─── TAB PODS ─────────────────────────────────
        tab_pods = self.tabview.tab("🎒 Pods")
        self.pods_inner_frame = ctk.CTkFrame(tab_pods, fg_color="transparent")
        self.pods_inner_frame.pack(fill="both", expand=True)
        ctk.CTkLabel(self.pods_inner_frame, text="Clic droit pour capturer l'alerte Pods pleins.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8,4))
        self.var_pods_enabled = tk.BooleanVar(value=False)
        self.chk_pods_enabled = _mk_checkbox(self.pods_inner_frame, "🎒 Activer Vidage Banque", self.var_pods_enabled, pady=6)

        self.sens_pods_frame = ctk.CTkFrame(self.pods_inner_frame, fg_color="transparent")
        self.sens_pods_frame.pack(pady=2, padx=10, fill="x")
        self.lbl_sens_pods_title = ctk.CTkLabel(self.sens_pods_frame, text="Précision :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_sens_pods_title.pack(side="left", padx=4)
        self.entry_pods_sens = ctk.CTkEntry(self.sens_pods_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_pods_sens.insert(0, "80")
        self.entry_pods_sens.pack(side="right", padx=4)
        self.entry_pods_sens.bind("<Return>", self._on_pods_sens_entry)
        self.entry_pods_sens.bind("<FocusOut>", self._on_pods_sens_entry)
        self.entry_pods_sens.bind("<KeyRelease>", self._on_pods_sens_keyrelease)
        self.slider_pods = _mk_slider(self.pods_inner_frame, 0.3, 0.95, 0.80, self.update_pods_sens)

        self.pods_capture_selector = ctk.CTkSegmentedButton(self.pods_inner_frame,
            values=["Alerte","Banque","Transferts","Tout Transférer"],
            variable=self.var_pods_capture_type,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=22)
        self.pods_capture_selector.pack(pady=4, padx=10, fill="x")
        self.lbl_pods_counts = ctk.CTkLabel(self.pods_inner_frame,
            text="Modèles : A:0 | B:0 | T:0 | TT:0",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_counts.pack(pady=2)
        # Labels coords pods (requis par load_config)
        self.lbl_pods_bank_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Banque : non définie", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_bank_coords.pack(pady=1, padx=10)
        self.lbl_pods_transfers_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Transferts : non défini", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_transfers_coords.pack(pady=1, padx=10)
        self.lbl_pods_transfer_all_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Transférer : non défini", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_transfer_all_coords.pack(pady=1, padx=10)

        self.btn_clear_pods = ctk.CTkButton(self.pods_inner_frame, text="🗑️ Effacer Modèles Pods",
            command=self.clear_pods, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_pods.pack(pady=6, padx=10, fill="x")

        # ── BOUTON BOT + STATUS ────────────────────────
        self.btn_bot = ctk.CTkButton(self.sidebar_frame,
            text="⚔  LANCER LE BOT  (F4)",
            command=self.toggle_bot, height=50,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            text_color="#FFFFFF", corner_radius=0)
        self.btn_bot.pack(side="bottom", fill="x")

        ctk.CTkFrame(self.sidebar_frame, height=1, fg_color=BORDER_COLOR).pack(side="bottom", fill="x")

        self.status_frame = ctk.CTkFrame(self.sidebar_frame, fg_color=CARD_COLOR, corner_radius=0, height=92)
        self.status_frame.pack(side="bottom", fill="x")
        self.status_frame.pack_propagate(False)

        row_badge = ctk.CTkFrame(self.status_frame, fg_color="transparent")
        row_badge.pack(fill="x", padx=12, pady=(8, 1))
        self.lbl_state_badge = ctk.CTkLabel(row_badge, text="⬛ INACTIF",
            font=ctk.CTkFont(weight="bold", size=13), text_color=TEXT_DIM)
        self.lbl_state_badge.pack(side="left")
        self.lbl_combat_count = ctk.CTkLabel(row_badge, text="Combats : 0",
            font=ctk.CTkFont(size=11), text_color=TEXT_DIM)
        self.lbl_combat_count.pack(side="right")

        self.lbl_status = ctk.CTkLabel(self.status_frame, text="Statut : Prêt",
            text_color=TEXT_COLOR, font=ctk.CTkFont(size=11), anchor="w")
        self.lbl_status.pack(fill="x", padx=12, pady=0)

        self.lbl_debug = ctk.CTkLabel(self.status_frame,
            text="M: 0%  C: 0%  V: 0%",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM, anchor="w")
        self.lbl_debug.pack(fill="x", padx=12, pady=(0, 6))

                        # --- UI Vidéo (Canvas à droite) ---
        self.video_frame = ctk.CTkFrame(self, fg_color=BG_COLOR, corner_radius=0)
        self.video_frame.pack(side="right", fill="both", expand=True, padx=0, pady=0)
        
        self.canvas = tk.Canvas(self.video_frame, bg="#2A2018", highlightthickness=0, cursor="cross")
        self.canvas.pack(fill="both", expand=True, padx=5, pady=5)
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        
        self.rect = None
        self.start_x = 0
        self.start_y = 0
        
        self.refresh_window_list()
        self.load_templates_to_cache()
        self.load_config()
        self._on_enu_mode_toggle()  # applique l'état du clic droit selon le mode Enutrof
        self._on_speed_change()  # met à jour l'indice du curseur de vitesse
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        try:
            keyboard.add_hotkey('f4', lambda: self.after(0, self.toggle_bot))
            keyboard.add_hotkey('f2', lambda: self.after(0, self.instant_stop))
        except Exception as e:
            print(f"[HOTKEY] Erreur d'enregistrement des raccourcis: {e}")

        # ── Infobulles complètes ──────────────────────────
        T = self.add_tooltip
        T(self.btn_capture,      "👁 APERÇU\nDémarre/arrête la prévisualisation du jeu en direct.\nNécessaire pour définir les zones de clic.")
        T(self.btn_open_folder,  "📂 DOSSIER MODÈLES\nOuvre le dossier où sont stockées les images\ncapturées (monstres, combat, victoire).")
        T(self.btn_show_last_match, "🔍 DERNIER MATCH\nOuvre l'image du dernier modèle détecté\npour vérifier que la détection est correcte.")
        T(self.window_selector,  "🖥 FENÊTRE CIBLE\nSélectionne la fenêtre Dofus à surveiller.\nDoit être différent de 'Écran Complet'\npour activer les modes Fantôme/Masquée.")
        T(self.btn_refresh,      "🔄 RAFRAÎCHIR\nMet à jour la liste des fenêtres ouvertes.\nÀ utiliser si Dofus n'apparaît pas dans la liste.")
        T(self.chk_background_mode, "🖱 CONTRÔLES FANTÔME\nEnvoie les clics et touches directement à Dofus\nsans déplacer ta souris physique.\n✅ Recommandé : tu peux utiliser ton PC\nlibrement pendant que le bot joue.")
        T(self.chk_hidden_capture, "🥷 CAPTURE MASQUÉE\nCapture l'écran de Dofus même si la fenêtre\nest en arrière-plan ou minimisée.\nUtilise GDI (PrintWindow) au lieu de MSS.")
        T(self.chk_dpi_scaling,  "🔎 FIX DPI\nCorrige les décalages de clic si ton écran\nutil une mise à l'échelle (125%, 150%, etc.)\nDans Paramètres Windows > Affichage > Mise à l'échelle.")
        T(self.sens_entry,       "🎯 PRÉCISION IA\nSeuil minimum de ressemblance (%) pour\nqu'une image soit considérée comme détectée.\n• Trop bas (< 60%) → faux positifs\n• Trop haut (> 85%) → rate des détections\nValeur recommandée : 70-77%")
        T(self.slider,           "🎯 SLIDER PRÉCISION\nFais glisser pour ajuster la précision IA.\nLa valeur s'affiche dans le champ à droite.")
        T(self.entry_map_delay,  "⏰ DÉLAI CARTE\nTemps d'attente (s) entre deux tentatives\nde clic sur un monstre (min 0.01).\nAugmente si le bot clique trop vite.")
        T(self.entry_launch_timeout, "⏱ ATTENTE LANCEMENT\nDurée max (s) pour qu'un combat se lance\naprès un clic. Sert aussi d'anti-vol : si le\nbot croit être en combat sans jamais jouer,\nil revient à la Carte après ce délai.")
        T(self.entry_monster_cooldown, "🛡 COOLDOWN MONSTRE\nDurée minimale (secondes) entre deux clics\nsur un monstre — empêche le double-clic.\nBaisse si tu veux que le bot réattaque plus vite.\nValeur recommandée : 2.0 - 4.0s")
        T(self.chk_close_menu,   "❌ FERMER MENU\nAppuie automatiquement sur Echap si le\nmenu principal de Dofus s'ouvre.")
        T(self.btn_clear,        "🗑 EFFACER MONSTRES\nSupprime toutes les images capturées\nde monstres. À faire avant de recapturer\npour un autre type de monstre.")
        T(self.btn_clear_menu,   "🗑 EFFACER MENU\nSupprime les images du menu principal.")
        T(self.btn_define_zone,  "🎯 ZONE DE CLIC\nClique ici puis fais un clic droit + glisser\nsur la vidéo pour définir où le bot va cliquer\npendant les combats (case cible du sort).")
        T(self.zone_mode_selector, "📏 MODE ZONE\n• Ligne : clic aléatoire sur une droite\n• Rectangle : clic aléatoire dans un rectangle\nLigne = plus précis pour une seule case cible.")
        T(self.entry_spell_key,  "⌨ TOUCHE SORT\nTouche du sort à utiliser en combat.\nExemples : 1, 2, 3, q, w, e...")
        T(self.entry_chain_count, "🔢 NB LANCERS\nNombre de fois que le sort est lancé par tour.\nDépend du nombre de PA et de la portée du sort.")
        T(self.entry_delay,      "⏳ DÉLAI ENTRE SORTS\nTemps d'attente (s) entre chaque lancer.\nAugmente si le jeu ne suit pas le rythme.")
        T(self.chk_pass_turn,    "⏭ PASSER LE TOUR\nAppuie automatiquement sur la touche de\npassage de tour après avoir lancé tous les sorts.")
        T(self.entry_pass_key,   "⌨ TOUCHE PASSAGE\nTouche pour passer le tour.\nGénéralement F1 dans Dofus.")
        T(self.entry_start_delay, "⏰ ATTENTE DÉBUT\nDélai (s) avant de commencer à jouer\nle tour — laisse le temps aux animations.")
        T(self.entry_end_delay,  "⏰ DÉLAI FIN TOUR\nAttente (s) après les sorts et avant\nde passer le tour.")
        T(self.entry_ready_delay, "⏰ ATTENTE APRÈS PRÊT\nPause après le clic sur 'Prêt' au début\ndu combat, avant de jouer le tour.")
        T(self.chk_victory_esc,  "🏆 FERMER PAR ECHAP\nFerme l'écran de fin de combat avec Echap.\nPlus rapide que de cliquer sur un bouton.")
        T(self.entry_victory_delay_min, "⏱ DÉLAI MIN VICTOIRE\nTemps minimum (s) d'attente avant de\nfermer l'écran de fin de combat.")
        T(self.entry_victory_delay_max, "⏱ DÉLAI MAX VICTOIRE\nTemps maximum (s) d'attente avant de\nfermer l'écran de fin de combat.\nValeur aléatoire entre Min et Max.")
        T(self.entry_victory_cooldown, "⏳ COOLDOWN POST-COMBAT\nDurée (s) à attendre après un combat\navant de chercher un nouveau monstre.")
        T(self.btn_clear_victoire, "🗑 EFFACER VICTOIRE\nSupprime les images du bouton de victoire.")
        T(self.btn_bot,          "⚔ LANCER / ARRÊTER\nDémarre ou stoppe le bot (aussi sur F4).\nF2 = arrêt d'urgence instantané.")
        T(self.chk_modo_enabled, "🛡 ANTI-MODO\nDétecte la présence d'un modérateur\net répond automatiquement dans le chat.")
        T(self.modo_mode_selector, "🔍 MODE DÉTECTION\n• Présence : réagit si le modèle est vu\n• Changement : réagit si la zone change")
        T(self.entry_modo_text,  "💬 MESSAGE AUTO\nTexte envoyé automatiquement dans le chat\nquand un modérateur est détecté.")
        T(self.btn_define_modo_chat, "💬 POSITION CHAT\nClique ici puis fais un clic gauche\nsur la zone de chat pour la définir.")
        T(self.btn_clear_modo,   "🗑 EFFACER MODO\nSupprime les images de détection modo.")
        T(self.chk_pods_enabled, "🎒 VIDAGE BANQUE\nVide automatiquement en banque quand\nl'alerte de pods pleins est détectée.")
        T(self.entry_pods_sens,  "🎯 PRÉCISION PODS\nSeuil de détection pour l'alerte pods.")
        T(self.pods_capture_selector, "📸 ÉTAPE À CAPTURER\nSélectionne l'étape avant de faire\nun clic droit sur la vidéo pour capturer.")
        T(self.btn_clear_pods,   "🗑 EFFACER PODS\nSupprime les images d'alerte pods.")

    def add_tooltip(self, widget, text):
        ToolTip(widget, text)

    def update_ghost_options_state(self, choice):
        if choice == "Écran Complet":
            self.var_background_mode.set(False)
            self.var_hidden_capture.set(False)
            self.chk_background_mode.configure(state="disabled")
            self.chk_hidden_capture.configure(state="disabled")
        else:
            self.chk_background_mode.configure(state="normal")
            self.chk_hidden_capture.configure(state="normal")

    # --- Callbacks de synchronisation slider <-> champ de saisie ---
    def update_sens(self, value):
        self.sens_entry.delete(0, tk.END)
        self.sens_entry.insert(0, str(int(value * 100)))

    def _on_sens_entry(self, event=None):
        try:
            raw = self.sens_entry.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(30, min(95, v))
            self.slider.set(v / 100.0)
            self.sens_entry.delete(0, tk.END)
            self.sens_entry.insert(0, str(v))
        except ValueError:
            pass

    def _on_sens_keyrelease(self, event=None):
        try:
            raw = self.sens_entry.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(30, min(95, v))
            self.slider.set(v / 100.0)
        except ValueError:
            pass

    def _on_chain_count_entry(self, event=None):
        try:
            raw = self.entry_chain_count.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(1, min(10, v))
            self.entry_chain_count.delete(0, tk.END)
            self.entry_chain_count.insert(0, str(v))
        except ValueError:
            pass

    @staticmethod
    def _delay_seconds_from_config(raw, lo, hi, default):
        """Normalise un delai charge : ancien format ms (>5) -> secondes, puis borne."""
        try:
            v = float(str(raw).replace(",", "."))
        except Exception:
            return default
        if v > 5:  # ancienne valeur stockee en millisecondes
            v = v / 1000.0
        return round(max(lo, min(hi, v)), 2)

    def update_delay_lbl(self, value):
        self.entry_delay.delete(0, tk.END)
        self.entry_delay.insert(0, f"{float(value):.2f}")

    def _on_delay_entry(self, event=None):
        try:
            raw = self.entry_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(3.0, float(raw))), 2)
            self.slider_delay.set(v)
            self.entry_delay.delete(0, tk.END)
            self.entry_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(3.0, float(raw))), 2)
            self.slider_delay.set(v)
        except ValueError:
            pass

    def update_start_delay_lbl(self, value):
        self.entry_start_delay.delete(0, tk.END)
        self.entry_start_delay.insert(0, f"{float(value):.3f}")

    def _on_start_delay_entry(self, event=None):
        try:
            raw = self.entry_start_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_start_delay.set(v)
            self.entry_start_delay.delete(0, tk.END)
            self.entry_start_delay.insert(0, f"{v:.3f}")
        except ValueError:
            pass

    def _on_start_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_start_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_start_delay.set(v)
        except ValueError:
            pass

    def update_end_delay_lbl(self, value):
        self.entry_end_delay.delete(0, tk.END)
        self.entry_end_delay.insert(0, f"{float(value):.3f}")

    def _on_end_delay_entry(self, event=None):
        try:
            raw = self.entry_end_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_end_delay.set(v)
            self.entry_end_delay.delete(0, tk.END)
            self.entry_end_delay.insert(0, f"{v:.3f}")
        except ValueError:
            pass

    def _on_end_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_end_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_end_delay.set(v)
        except ValueError:
            pass

    def update_ready_delay_lbl(self, value):
        self.entry_ready_delay.delete(0, tk.END)
        self.entry_ready_delay.insert(0, f"{float(value):.3f}")

    def _on_ready_delay_entry(self, event=None):
        try:
            raw = self.entry_ready_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_ready_delay.set(v)
            self.entry_ready_delay.delete(0, tk.END)
            self.entry_ready_delay.insert(0, f"{v:.3f}")
        except ValueError:
            pass

    def _on_ready_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_ready_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.001, min(2.0, float(raw))), 3)
            self.slider_ready_delay.set(v)
        except ValueError:
            pass

    def _on_modo_sens_entry(self, event=None):
        try:
            raw = self.entry_modo_sens.get().strip()
            if not raw: return
            v = int(raw)
            v = max(30, min(95, v))
            self.slider_modo.set(v / 100.0)
            self.entry_modo_sens.delete(0, tk.END)
            self.entry_modo_sens.insert(0, str(v))
            self.save_config()
        except ValueError:
            pass

    def _on_modo_sens_keyrelease(self, event=None):
        try:
            raw = self.entry_modo_sens.get().strip()
            if not raw: return
            v = int(raw)
            if 30 <= v <= 95:
                self.slider_modo.set(v / 100.0)
                self.save_config()
        except ValueError:
            pass

    def update_modo_sens(self, value):
        self.entry_modo_sens.delete(0, tk.END)
        self.entry_modo_sens.insert(0, str(int(value * 100)))
        self.save_config()

    def toggle_define_modo_chat(self):
        self.is_defining_modo_chat = not self.is_defining_modo_chat
        if self.is_defining_modo_chat:
            self.is_defining_zone = False # Désactiver l'autre dessin
            self.btn_define_modo_chat.configure(text="[Cliquez sur l'image]", fg_color=GREEN_COLOR)
        else:
            self.btn_define_modo_chat.configure(text="💬 Définir Clic Chat", fg_color=ACCENT_COLOR)

    def clear_modo(self):
        for f in os.listdir(self.templates_modo):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_modo, f))
        self.load_templates_to_cache()
        original = self.btn_clear_modo.cget("text")
        self.btn_clear_modo.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_modo.configure(text=original))
        self.log_status("Modèles Modo effacés")

    def clear_menu(self):
        for f in os.listdir(self.templates_menu):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_menu, f))
        self.load_templates_to_cache()
        original = self.btn_clear_menu.cget("text")
        self.btn_clear_menu.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_menu.configure(text=original))
        self.log_status("Modèles Menu Principal effacés")

    def _on_pods_sens_entry(self, event=None):
        try:
            raw = self.entry_pods_sens.get().strip()
            if not raw: return
            v = int(raw)
            v = max(30, min(95, v))
            self.slider_pods.set(v / 100.0)
            self.entry_pods_sens.delete(0, tk.END)
            self.entry_pods_sens.insert(0, str(v))
            self.save_config()
        except ValueError:
            pass

    def _on_pods_sens_keyrelease(self, event=None):
        try:
            raw = self.entry_pods_sens.get().strip()
            if not raw: return
            v = int(raw)
            if 30 <= v <= 95:
                self.slider_pods.set(v / 100.0)
                self.save_config()
        except ValueError:
            pass

    def update_pods_sens(self, value):
        self.entry_pods_sens.delete(0, tk.END)
        self.entry_pods_sens.insert(0, str(int(value * 100)))
        self.save_config()



    def clear_pods(self):
        for d in [self.templates_pods, self.templates_pods_bank, self.templates_pods_transfers, self.templates_pods_transfer_all]:
            if os.path.exists(d):
                for f in os.listdir(d):
                    if f.endswith(".png"):
                        os.remove(os.path.join(d, f))
        self.load_templates_to_cache()
        original = self.btn_clear_pods.cget("text")
        self.btn_clear_pods.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_pods.configure(text=original))
        self.log_status("Modèles Pods effacés")

    def _on_infinite_delay_entry(self, event=None):
        try:
            raw = self.entry_infinite_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = max(0.01, min(2.0, float(raw)))
            self.entry_infinite_delay.delete(0, tk.END)
            self.entry_infinite_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass
        self.save_config()

    def _on_map_delay_entry(self, event=None):
        try:
            raw = self.entry_map_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.0, min(8.0, v))
            self.entry_map_delay.delete(0, tk.END)
            self.entry_map_delay.insert(0, f"{v:.3f}")
            self.current_map_delay = v * np.random.uniform(0.85, 1.15)
        except ValueError:
            pass

    def _on_monster_cooldown_entry(self, event=None):
        try:
            raw = self.entry_monster_cooldown.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.01, min(10.0, v))
            self.entry_monster_cooldown.delete(0, tk.END)
            self.entry_monster_cooldown.insert(0, f"{v:.2f}")
        except ValueError:
            pass
        self.save_config()

    def _on_launch_timeout_entry(self, event=None):
        try:
            raw = self.entry_launch_timeout.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.01, min(30.0, v))
            self.entry_launch_timeout.delete(0, tk.END)
            self.entry_launch_timeout.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_victory_delay_min_entry(self, event=None):
        try:
            raw = self.entry_victory_delay_min.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.0, min(10.0, v))
            self.entry_victory_delay_min.delete(0, tk.END)
            self.entry_victory_delay_min.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_victory_delay_max_entry(self, event=None):
        try:
            raw = self.entry_victory_delay_max.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.0, min(10.0, v))
            self.entry_victory_delay_max.delete(0, tk.END)
            self.entry_victory_delay_max.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_victory_cooldown_entry(self, event=None):
        try:
            raw = self.entry_victory_cooldown.get().strip().replace(",", ".")
            if not raw:
                return
            v = float(raw)
            v = max(0.0, min(10.0, v))
            self.entry_victory_cooldown.delete(0, tk.END)
            self.entry_victory_cooldown.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def save_config(self):
        try:
            config = {
                "window_target": self.window_selector.get(),
                "background_mode": self.var_background_mode.get(),
                "hidden_capture": self.var_hidden_capture.get(),
                "dpi_scaling": self.var_dpi_scaling.get(),
                "precision": self.slider.get(),
                "map_delay": self.entry_map_delay.get(),
                "launch_timeout": self.entry_launch_timeout.get(),
                "zone_x": self.entry_zone_x.get(),
                "zone_y": self.entry_zone_y.get(),
                "zone_w": self.entry_zone_w.get(),
                "zone_h": self.entry_zone_h.get(),
                "spell_key": self.entry_spell_key.get(),
                "spell_right_click": self.var_spell_right_click.get(),
                "enu_mode": self.var_enu_mode.get(),
                "enu_chest_key": self.entry_enu_chest_key.get(),
                "enu_chance_key": self.entry_enu_chance_key.get(),
                "enu_chest_once": self.var_enu_chest_once.get(),
                "infinite_click": self.var_infinite_click.get(),
                "roi_enabled": self.var_roi_enabled.get(),
                "speed_slider": self.slider_speed.get(),
                "fast_detect": self.var_fast_detect.get(),
                "adaptive_capture": self.var_adaptive_capture.get(),
                "infinite_delay": self.entry_infinite_delay.get(),
                "spell_right_clicks_min": self.entry_right_clicks_min.get(),
                "spell_right_clicks_max": self.entry_right_clicks_max.get(),
                "chain_count": self.entry_chain_count.get(),
                "delay": self.entry_delay.get(),
                "pass_turn": self.var_pass_turn.get(),
                "pass_key": self.entry_pass_key.get(),
                "start_delay": self.entry_start_delay.get(),
                "end_delay": self.entry_end_delay.get(),
                "ready_delay": self.entry_ready_delay.get(),
                "victory_esc": self.var_victory_esc.get(),
                "victory_delay_min": self.entry_victory_delay_min.get(),
                "victory_delay_max": self.entry_victory_delay_max.get(),
                "victory_delay_migrated_v4": True,
                "monster_cd_migrated_v3": True,
                "map_delay_zeroed_v5": True,
                "victory_cd_zeroed_v6": True,
                "victory_cooldown": self.entry_victory_cooldown.get(),
                "zone_mode": self.zone_mode_var.get(),
                "enu_zone": self.enu_zone,
                "modo_enabled": self.var_modo_enabled.get(),
                "modo_trigger_mode": self.var_modo_trigger_mode.get(),
                "modo_precision": self.slider_modo.get(),
                "modo_chat_x": self.modo_chat_x if self.modo_chat_x is not None else "",
                "modo_chat_y": self.modo_chat_y if self.modo_chat_y is not None else "",
                "modo_crop_x": self.modo_crop_x if self.modo_crop_x is not None else "",
                "modo_crop_y": self.modo_crop_y if self.modo_crop_y is not None else "",
                "modo_crop_w": self.modo_crop_w if self.modo_crop_w is not None else "",
                "modo_crop_h": self.modo_crop_h if self.modo_crop_h is not None else "",
                "modo_text": self.entry_modo_text.get(),
                "close_menu": self.var_close_menu.get(),
                "pods_enabled": self.var_pods_enabled.get(),
                "pods_precision": self.slider_pods.get(),
                "pods_bank_x": self.pods_bank_x if self.pods_bank_x is not None else "",
                "pods_bank_y": self.pods_bank_y if self.pods_bank_y is not None else "",
                "pods_transfers_x": self.pods_transfers_x if self.pods_transfers_x is not None else "",
                "pods_transfers_y": self.pods_transfers_y if self.pods_transfers_y is not None else "",
                "pods_transfer_all_x": self.pods_transfer_all_x if self.pods_transfer_all_x is not None else "",
                "pods_transfer_all_y": self.pods_transfer_all_y if self.pods_transfer_all_y is not None else "",
                "monster_cooldown": self.entry_monster_cooldown.get()
            }
            import json
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
            print(f"[CONFIG] Sauvegardée dans {self.config_file}")
        except Exception as e:
            print(f"[CONFIG] Erreur sauvegarde: {e}")

    def load_config(self):
        try:
            if not os.path.exists(self.config_file):
                return
            import json
            with open(self.config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
                
            # Restauration des valeurs
            if "window_target" in config:
                val = config["window_target"]
                self.window_selector.set(val)
                self.vision.set_target_window(val)
                self.update_ghost_options_state(val)
                
            if "background_mode" in config:
                self.var_background_mode.set(config["background_mode"])
            if "hidden_capture" in config:
                self.var_hidden_capture.set(config["hidden_capture"])
            if "dpi_scaling" in config:
                self.var_dpi_scaling.set(config["dpi_scaling"])
                
            if "precision" in config:
                val = float(config["precision"])
                self.slider.set(val)
                self.sens_entry.delete(0, tk.END)
                self.sens_entry.insert(0, str(int(val * 100)))
                
            if "map_delay" in config:
                self.entry_map_delay.delete(0, tk.END)
                self.entry_map_delay.insert(0, config["map_delay"])
                try:
                    self.current_map_delay = float(config["map_delay"])
                except:
                    pass
                    
            if "launch_timeout" in config:
                self.entry_launch_timeout.delete(0, tk.END)
                self.entry_launch_timeout.insert(0, config["launch_timeout"])
                
            if "zone_x" in config:
                self.entry_zone_x.delete(0, tk.END)
                self.entry_zone_x.insert(0, config["zone_x"])
            if "zone_y" in config:
                self.entry_zone_y.delete(0, tk.END)
                self.entry_zone_y.insert(0, config["zone_y"])
            if "zone_w" in config:
                self.entry_zone_w.delete(0, tk.END)
                self.entry_zone_w.insert(0, config["zone_w"])
            if "zone_h" in config:
                self.entry_zone_h.delete(0, tk.END)
                self.entry_zone_h.insert(0, config["zone_h"])
                try:
                    x1 = int(float(config["zone_x"]))
                    y1 = int(float(config["zone_y"]))
                    x2 = int(float(config["zone_w"]))
                    y2 = int(float(config["zone_h"]))
                    self.combat_zone = ((x1, y1), (x2, y2))
                except:
                    pass

            if config.get("enu_zone"):
                try:
                    (ex1, ey1), (ex2, ey2) = config["enu_zone"]
                    self.enu_zone = ((int(ex1), int(ey1)), (int(ex2), int(ey2)))
                    self.lbl_enu_zone.configure(
                        text=f"Zone coffre : définie ✓  ({int(ex1)},{int(ey1)})→({int(ex2)},{int(ey2)})")
                except Exception:
                    pass
                    
            if "spell_key" in config:
                self.entry_spell_key.delete(0, tk.END)
                self.entry_spell_key.insert(0, config["spell_key"])
            if "spell_right_click" in config:
                self.var_spell_right_click.set(config["spell_right_click"])
            if "enu_mode" in config:
                self.var_enu_mode.set(config["enu_mode"])
            if "enu_chest_key" in config:
                self.entry_enu_chest_key.delete(0, tk.END)
                self.entry_enu_chest_key.insert(0, config["enu_chest_key"])
            if "enu_chance_key" in config:
                self.entry_enu_chance_key.delete(0, tk.END)
                self.entry_enu_chance_key.insert(0, config["enu_chance_key"])
            if "enu_chest_once" in config:
                self.var_enu_chest_once.set(config["enu_chest_once"])
            if "infinite_click" in config:
                self.var_infinite_click.set(config["infinite_click"])
            if "roi_enabled" in config:
                self.var_roi_enabled.set(config["roi_enabled"])
            if "speed_slider" in config:
                try:
                    self.slider_speed.set(float(config["speed_slider"]))
                except Exception:
                    pass
            elif config.get("speed_profile") in SPEED_PROFILES:
                # migration ancien profil -> position du curseur
                self.slider_speed.set({"Lent": 1.0, "Normal": 5.0, "Rapide": 10.0}.get(config["speed_profile"], 10.0))
            if "fast_detect" in config:
                self.var_fast_detect.set(config["fast_detect"])
            if "adaptive_capture" in config:
                self.var_adaptive_capture.set(config["adaptive_capture"])
            if "infinite_delay" in config:
                self.entry_infinite_delay.delete(0, tk.END)
                self.entry_infinite_delay.insert(0, config["infinite_delay"])
            if "spell_right_clicks_min" in config:
                self.entry_right_clicks_min.delete(0, tk.END)
                self.entry_right_clicks_min.insert(0, config["spell_right_clicks_min"])
            if "spell_right_clicks_max" in config:
                self.entry_right_clicks_max.delete(0, tk.END)
                self.entry_right_clicks_max.insert(0, config["spell_right_clicks_max"])
            if "chain_count" in config:
                self.entry_chain_count.delete(0, tk.END)
                self.entry_chain_count.insert(0, config["chain_count"])
                
            if "delay" in config:
                v = self._delay_seconds_from_config(config["delay"], 0.01, 3.0, 0.08)
                self.entry_delay.delete(0, tk.END)
                self.entry_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_delay.set(v)
                except:
                    pass
                    
            if "pass_turn" in config:
                self.var_pass_turn.set(config["pass_turn"])
            if "pass_key" in config:
                self.entry_pass_key.delete(0, tk.END)
                self.entry_pass_key.insert(0, config["pass_key"])
                
            if "start_delay" in config:
                v = self._delay_seconds_from_config(config["start_delay"], 0.01, 2.0, 0.30)
                self.entry_start_delay.delete(0, tk.END)
                self.entry_start_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_start_delay.set(v)
                except:
                    pass
            if "end_delay" in config:
                v = self._delay_seconds_from_config(config["end_delay"], 0.01, 2.0, 0.15)
                self.entry_end_delay.delete(0, tk.END)
                self.entry_end_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_end_delay.set(v)
                except:
                    pass
            if "ready_delay" in config:
                v = self._delay_seconds_from_config(config["ready_delay"], 0.01, 2.0, 0.50)
                self.entry_ready_delay.delete(0, tk.END)
                self.entry_ready_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_ready_delay.set(v)
                except:
                    pass
                    
            if "victory_esc" in config:
                self.var_victory_esc.set(config["victory_esc"])
            if "victory_delay_min" in config:
                self.entry_victory_delay_min.delete(0, tk.END)
                self.entry_victory_delay_min.insert(0, config["victory_delay_min"])
            if "victory_delay_max" in config:
                self.entry_victory_delay_max.delete(0, tk.END)
                self.entry_victory_delay_max.insert(0, config["victory_delay_max"])
            if "victory_cooldown" in config:
                self.entry_victory_cooldown.delete(0, tk.END)
                self.entry_victory_cooldown.insert(0, config["victory_cooldown"])
                
            if "zone_mode" in config:
                self.zone_mode_var.set(config["zone_mode"])
                self.click_zone_mode = config["zone_mode"]
                
            if "modo_enabled" in config:
                self.var_modo_enabled.set(config["modo_enabled"])
            if "modo_trigger_mode" in config:
                self.var_modo_trigger_mode.set(config["modo_trigger_mode"])
            if "modo_precision" in config:
                val = float(config["modo_precision"])
                self.slider_modo.set(val)
                self.entry_modo_sens.delete(0, tk.END)
                self.entry_modo_sens.insert(0, str(int(val * 100)))
            if "modo_chat_x" in config and config["modo_chat_x"] != "":
                self.modo_chat_x = int(config["modo_chat_x"])
            if "modo_chat_y" in config and config["modo_chat_y"] != "":
                self.modo_chat_y = int(config["modo_chat_y"])
                self.lbl_modo_chat_coords.configure(text=f"Clic Chat : X={self.modo_chat_x}, Y={self.modo_chat_y}", text_color=GREEN_COLOR)
            if "modo_crop_x" in config and config["modo_crop_x"] != "":
                self.modo_crop_x = int(config["modo_crop_x"])
            if "modo_crop_y" in config and config["modo_crop_y"] != "":
                self.modo_crop_y = int(config["modo_crop_y"])
            if "modo_crop_w" in config and config["modo_crop_w"] != "":
                self.modo_crop_w = int(config["modo_crop_w"])
            if "modo_crop_h" in config and config["modo_crop_h"] != "":
                self.modo_crop_h = int(config["modo_crop_h"])
            if "modo_text" in config:
                self.entry_modo_text.delete(0, tk.END)
                self.entry_modo_text.insert(0, config["modo_text"])
            if "close_menu" in config:
                self.var_close_menu.set(config["close_menu"])
            if "pods_enabled" in config:
                self.var_pods_enabled.set(config["pods_enabled"])
            if "pods_precision" in config:
                val = float(config["pods_precision"])
                self.slider_pods.set(val)
                self.entry_pods_sens.delete(0, tk.END)
                self.entry_pods_sens.insert(0, str(int(val * 100)))
            if "pods_bank_x" in config and config["pods_bank_x"] != "":
                self.pods_bank_x = int(config["pods_bank_x"])
            if "pods_bank_y" in config and config["pods_bank_y"] != "":
                self.pods_bank_y = int(config["pods_bank_y"])
                self.lbl_pods_bank_coords.configure(text=f"Banque : X={self.pods_bank_x}, Y={self.pods_bank_y}", text_color=GREEN_COLOR)
            if "pods_transfers_x" in config and config["pods_transfers_x"] != "":
                self.pods_transfers_x = int(config["pods_transfers_x"])
            if "pods_transfers_y" in config and config["pods_transfers_y"] != "":
                self.pods_transfers_y = int(config["pods_transfers_y"])
                self.lbl_pods_transfers_coords.configure(text=f"Transferts : X={self.pods_transfers_x}, Y={self.pods_transfers_y}", text_color=GREEN_COLOR)
            if "pods_transfer_all_x" in config and config["pods_transfer_all_x"] != "":
                self.pods_transfer_all_x = int(config["pods_transfer_all_x"])
            if "pods_transfer_all_y" in config and config["pods_transfer_all_y"] != "":
                self.pods_transfer_all_y = int(config["pods_transfer_all_y"])
                self.lbl_pods_transfer_all_coords.configure(text=f"Transférer : X={self.pods_transfer_all_x}, Y={self.pods_transfer_all_y}", text_color=GREEN_COLOR)
                
            if "monster_cooldown" in config:
                self.entry_monster_cooldown.delete(0, tk.END)
                self.entry_monster_cooldown.insert(0, str(config["monster_cooldown"]))

            # ===== MIGRATIONS (à la TOUTE FIN pour ne JAMAIS être écrasées par les
            # chargements ci-dessus). Mettent les délais à 0 une seule fois chacun. =====
            _need_save = False
            if not config.get("victory_delay_migrated_v4", False):
                self.entry_victory_delay_min.delete(0, tk.END)
                self.entry_victory_delay_min.insert(0, "0.0")
                self.entry_victory_delay_max.delete(0, tk.END)
                self.entry_victory_delay_max.insert(0, "0.0")
                _need_save = True
            if not config.get("monster_cd_migrated_v3", False):
                self.entry_monster_cooldown.delete(0, tk.END)
                self.entry_monster_cooldown.insert(0, "0.0")
                _need_save = True
            if not config.get("map_delay_zeroed_v5", False):
                self.entry_map_delay.delete(0, tk.END)
                self.entry_map_delay.insert(0, "0.0")
                self.current_map_delay = 0.0
                _need_save = True
            if not config.get("victory_cd_zeroed_v6", False):
                self.entry_victory_cooldown.delete(0, tk.END)
                self.entry_victory_cooldown.insert(0, "0.0")
                _need_save = True
            if _need_save:
                try:
                    self.save_config()
                except Exception:
                    pass

            print("[CONFIG] Restaurée avec succès.")
        except Exception as e:
            print(f"[CONFIG] Erreur chargement: {e}")


    def on_close(self):
        self.is_bot_active = False
        self._bot_stop_event.set()
        try: ctypes.windll.winmm.timeEndPeriod(1)
        except Exception: pass
        self.save_config()
        self.destroy()

    def load_templates_to_cache(self):
        """Charge tous les templates depuis le disque dans le cache mémoire."""
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: [],
            self.templates_pods: [],
            self.templates_pods_bank: [],
            self.templates_pods_transfers: [],
            self.templates_pods_transfer_all: []
        }
        for t_dir in self.templates_cache.keys():
            if not os.path.exists(t_dir):
                continue
            for f in os.listdir(t_dir):
                if f.endswith(".png"):
                    t_path = os.path.join(t_dir, f)
                    try:
                        t_img = cv2.imread(t_path, cv2.IMREAD_GRAYSCALE)
                        if t_img is not None:
                            self.templates_cache[t_dir].append((f, t_img))
                    except Exception as e:
                        print(f"Erreur chargement template {f}: {e}")
        
        # Mettre à jour l'étiquette des comptes de modèles pods si elle existe
        if hasattr(self, "lbl_pods_counts"):
            self.lbl_pods_counts.configure(
                text=f"Modèles : A:{len(self.templates_cache[self.templates_pods])} | B:{len(self.templates_cache[self.templates_pods_bank])} | T:{len(self.templates_cache[self.templates_pods_transfers])} | TT:{len(self.templates_cache[self.templates_pods_transfer_all])}"
            )
            
        print(f"Templates chargés en mémoire : M:{len(self.templates_cache[self.templates_monstres])} | C:{len(self.templates_cache[self.templates_combat])} | V:{len(self.templates_cache[self.templates_victoire])} | Modo:{len(self.templates_cache[self.templates_modo])} | Menu:{len(self.templates_cache[self.templates_menu])} | Pods:{len(self.templates_cache[self.templates_pods])} | PodsBank:{len(self.templates_cache[self.templates_pods_bank])} | PodsTrans:{len(self.templates_cache[self.templates_pods_transfers])} | PodsAll:{len(self.templates_cache[self.templates_pods_transfer_all])}")

    def refresh_window_list(self):
        windows = ["Écran Complet"] + self.vision.get_available_windows()
        current = self.window_selector.get()
        self.window_selector.configure(values=windows)
        if current in windows:
            self.window_selector.set(current)
            self.update_ghost_options_state(current)
        else:
            self.window_selector.set("Écran Complet")
            self.vision.set_target_window("Écran Complet")
            self.update_ghost_options_state("Écran Complet")

    def on_window_selected(self, choice):
        self.vision.set_target_window(choice)
        self.update_ghost_options_state(choice)

    def on_zone_mode_changed(self, choice):
        self.click_zone_mode = choice
        self.log_status(f"Format zone : {choice}")

    def capture_loop(self):
        while self.is_capturing or self.is_bot_active:
            bg_capture = getattr(self, 'hidden_capture_active', False)
            try:
                frame = self.vision.get_latest_frame(background_mode=bg_capture)
                if frame is not None:
                    self.latest_captured_frame = frame
                    # Gris calculé 1 seule fois ici, réutilisé par toute la détection
                    try:
                        self._frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    except Exception:
                        self._frame_gray = None
                    self._frame_id = getattr(self, '_frame_id', 0) + 1
            except Exception as e:
                print("Erreur thread capture:", e)
            
            # Cadence adaptative : capture rapide sur la CARTE (course au vol, réactivité),
            # ralentie en COMBAT (le bot ne peut pas gagner de course là → CPU libéré,
            # Dofus plus fluide). La détection victoire/tour reste largement assez rapide.
            adaptive = getattr(self, "var_adaptive_capture", None)
            in_combat = (getattr(self, "bot_state", None) == "COMBAT" and self.is_bot_active)
            if in_combat and adaptive is not None and adaptive.get():
                sleep_time = self._spd("cap_combat_bg") if bg_capture else self._spd("cap_combat_fg")
            else:
                sleep_time = self._spd("cap_map_bg") if bg_capture else self._spd("cap_map_fg")
            time.sleep(sleep_time)

    def toggle_capture(self):
        if not self.is_capturing:
            self.is_capturing = True
            self.latest_captured_frame = None
            self.processed_frame = None
            self.btn_capture.configure(text="Arrêter Aperçu", fg_color="red", hover_color="darkred")
            
            if not hasattr(self, "cap_thread") or not self.cap_thread.is_alive():
                self.cap_thread = threading.Thread(target=self.capture_loop)
                self.cap_thread.daemon = True
                self.cap_thread.start()
            
            self.update_video_feed()
        else:
            self.is_capturing = False
            self.btn_capture.configure(text="Démarrer Aperçu", fg_color=ACCENT_COLOR)
            self.canvas.delete("all")
            self.canvas.create_text(400, 225, text="Aperçu arrêté.", fill="white", font=("Arial", 16))

    def open_templates_folder(self):
        try:
            os.startfile(self.templates_dir)
        except Exception as e:
            print(f"Erreur lors de l'ouverture du dossier: {e}")

    def open_last_match(self):
        path = getattr(self, 'last_matched_template_path', None)
        if path and os.path.exists(path):
            import subprocess
            win_path = os.path.normpath(path)
            # Sous Windows, /select permet d'ouvrir le dossier et sélectionner le fichier
            subprocess.run(f'explorer /select,"{win_path}"')
        else:
            self.log_status("⚠️ Aucun modèle n'a encore été matché.")
            try:
                os.startfile(self.templates_dir)
            except Exception as e:
                print(f"Erreur: {e}")

    def on_press(self, event):
        if not self.is_capturing or self.current_cv_img is None: return
        self.start_x = event.x
        self.start_y = event.y
        active_tab = self.tabview.get()
        if active_tab == "🛡️ Modo" and self.is_defining_modo_chat:
            self.rect = None
            return

        if active_tab == "Combat" and self.is_defining_zone:
            if self.click_zone_mode == "Ligne":
                self.rect = self.canvas.create_line(self.start_x, self.start_y, self.start_x, self.start_y, fill="#00ff00", width=2, tags="annot")
            else:
                self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline="#00ff00", width=2, tags="annot")
        else:
            self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline="#00ff00", width=2, tags="annot")

    def on_drag(self, event):
        if self.rect:
            self.canvas.coords(self.rect, self.start_x, self.start_y, event.x, event.y)
        self.update_magnifier(event.x, event.y)

    def on_mouse_move(self, event):
        self.update_magnifier(event.x, event.y)

    def update_magnifier(self, event_x, event_y):
        if not self.is_capturing or self.current_cv_img is None:
            return
        
        show_mag = self.is_defining_zone or self.rect is not None
        
        if not show_mag:
            self.canvas.delete("magnifier")
            return
            
        real_x = int((event_x - self.x_offset) / self.scale_ratio)
        real_y = int((event_y - self.y_offset) / self.scale_ratio)
        
        img_h, img_w = self.current_cv_img.shape[:2]
        if not (0 <= real_x < img_w and 0 <= real_y < img_h):
            self.canvas.delete("magnifier")
            return
            
        r = 15
        x_min = max(0, real_x - r)
        x_max = min(img_w, real_x + r + 1)
        y_min = max(0, real_y - r)
        y_max = min(img_h, real_y + r + 1)
        
        crop = self.current_cv_img[y_min:y_max, x_min:x_max].copy()
        
        pad_top = max(0, r - (real_y - y_min))
        pad_bottom = max(0, r - (y_max - 1 - real_y))
        pad_left = max(0, r - (real_x - x_min))
        pad_right = max(0, r - (x_max - 1 - real_x))
        
        if pad_top > 0 or pad_bottom > 0 or pad_left > 0 or pad_right > 0:
            crop = cv2.copyMakeBorder(crop, pad_top, pad_bottom, pad_left, pad_right, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            
        mag_size = 155
        zoom_img = cv2.resize(crop, (mag_size, mag_size), interpolation=cv2.INTER_NEAREST)
        
        center = mag_size // 2
        cv2.line(zoom_img, (center - 10, center), (center + 10, center), (0, 0, 255), 1)
        cv2.line(zoom_img, (center, center - 10), (center, center + 10), (0, 0, 255), 1)
        cv2.rectangle(zoom_img, (0, 0), (mag_size - 1, mag_size - 1), (255, 255, 255), 2)
        
        zoom_rgb = cv2.cvtColor(zoom_img, cv2.COLOR_BGR2RGB)
        pil_mag = Image.fromarray(zoom_rgb)
        self.tk_mag = ImageTk.PhotoImage(image=pil_mag)
        
        canvas_w = self.canvas.winfo_width()
        mag_x = canvas_w - mag_size - 10
        mag_y = 10
        
        if event_x > canvas_w - 200 and event_y < 200:
            mag_x = 10
            
        self.canvas.delete("magnifier")
        self.canvas.create_image(mag_x, mag_y, image=self.tk_mag, anchor="nw", tags="magnifier")
        
        coord_text = f"X: {real_x}, Y: {real_y}"
        self.canvas.create_rectangle(mag_x, mag_y + mag_size, mag_x + mag_size, mag_y + mag_size + 20, fill="black", outline="white", tags="magnifier")
        self.canvas.create_text(mag_x + mag_size // 2, mag_y + mag_size + 10, text=coord_text, fill="white", font=("Arial", 10, "bold"), tags="magnifier")

    def on_release(self, event):
        active_tab = self.tabview.get()
        if active_tab == "🛡️ Modo" and self.is_defining_modo_chat:
            real_x = int((event.x - self.x_offset) / self.scale_ratio)
            real_y = int((event.y - self.y_offset) / self.scale_ratio)
            img_h, img_w = self.current_cv_img.shape[:2]
            real_x = max(0, min(real_x, img_w - 1))
            real_y = max(0, min(real_y, img_h - 1))
            
            self.modo_chat_x = real_x
            self.modo_chat_y = real_y
            self.is_defining_modo_chat = False
            self.btn_define_modo_chat.configure(text="💬 Définir Clic Chat", fg_color=ACCENT_COLOR)
            self.lbl_modo_chat_coords.configure(text=f"Clic Chat : X={real_x}, Y={real_y}", text_color=GREEN_COLOR)
            
            msg = self.canvas.create_text(event.x, event.y, text="🎯 Position Chat définie !", fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
            self.save_config()
            return
            

            
        if not self.rect: return
        left = min(self.start_x, event.x)
        top = min(self.start_y, event.y)
        width = abs(self.start_x - event.x)
        height = abs(self.start_y - event.y)
        self.canvas.delete(self.rect)
        self.rect = None
        self.canvas.delete("magnifier")
        
        if self.current_cv_img is not None:
            real_left = int((left - self.x_offset) / self.scale_ratio)
            real_top = int((top - self.y_offset) / self.scale_ratio)
            real_width = int(width / self.scale_ratio)
            real_height = int(height / self.scale_ratio)
            
            img_h, img_w = self.current_cv_img.shape[:2]
            real_left = max(0, min(real_left, img_w - 1))
            real_top = max(0, min(real_top, img_h - 1))
            
            active_tab = self.tabview.get()
            
            if active_tab == "⚔️ Combat" and self.is_defining_zone:
                real_x1 = int((self.start_x - self.x_offset) / self.scale_ratio)
                real_y1 = int((self.start_y - self.y_offset) / self.scale_ratio)
                real_x2 = int((event.x - self.x_offset) / self.scale_ratio)
                real_y2 = int((event.y - self.y_offset) / self.scale_ratio)
                
                img_h, img_w = self.current_cv_img.shape[:2]
                real_x1 = max(0, min(real_x1, img_w - 1))
                real_y1 = max(0, min(real_y1, img_h - 1))
                real_x2 = max(0, min(real_x2, img_w - 1))
                real_y2 = max(0, min(real_y2, img_h - 1))
                
                self.combat_zone = ((real_x1, real_y1), (real_x2, real_y2))
                self.is_defining_zone = False
                self.btn_define_zone.configure(text="Définir zone de clic", fg_color=ACCENT_COLOR)
                
                # Mettre à jour les champs de texte
                self.entry_zone_x.delete(0, tk.END)
                self.entry_zone_x.insert(0, str(real_x1))
                self.entry_zone_y.delete(0, tk.END)
                self.entry_zone_y.insert(0, str(real_y1))
                self.entry_zone_w.delete(0, tk.END)
                self.entry_zone_w.insert(0, str(real_x2))
                self.entry_zone_h.delete(0, tk.END)
                self.entry_zone_h.insert(0, str(real_y2))
                
                msg_txt = "🎯 Ligne définie !" if self.click_zone_mode == "Ligne" else "🎯 Zone définie !"
                msg = self.canvas.create_text(event.x, event.y, text=msg_txt, fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
                self.after(1500, lambda: self.canvas.delete(msg))
                return

            if active_tab == "⚔️ Combat" and self.is_defining_enu_zone:
                real_x1 = int((self.start_x - self.x_offset) / self.scale_ratio)
                real_y1 = int((self.start_y - self.y_offset) / self.scale_ratio)
                real_x2 = int((event.x - self.x_offset) / self.scale_ratio)
                real_y2 = int((event.y - self.y_offset) / self.scale_ratio)
                img_h, img_w = self.current_cv_img.shape[:2]
                real_x1 = max(0, min(real_x1, img_w - 1))
                real_y1 = max(0, min(real_y1, img_h - 1))
                real_x2 = max(0, min(real_x2, img_w - 1))
                real_y2 = max(0, min(real_y2, img_h - 1))
                self.enu_zone = ((real_x1, real_y1), (real_x2, real_y2))
                self.is_defining_enu_zone = False
                self.btn_define_enu_zone.configure(text="🎯 Dessiner Zone Coffre (Clic Droit)", fg_color=ACCENT_COLOR)
                try:
                    self.lbl_enu_zone.configure(text=f"Zone coffre : définie ✓  ({real_x1},{real_y1})→({real_x2},{real_y2})")
                except Exception:
                    pass
                self.save_config()
                msg = self.canvas.create_text(event.x, event.y, text="🪙 Zone coffre définie !", fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
                self.after(1500, lambda: self.canvas.delete(msg))
                return
                
            if real_width > 5 and real_height > 5:
                real_width = max(1, min(real_width, img_w - real_left))
                real_height = max(1, min(real_height, img_h - real_top))
                
                if active_tab == "🗺️ Carte":
                    if self.var_carte_capture_type.get() == "Menu Principal":
                        target_dir = self.templates_menu
                        name_prefix = "menu"
                    else:
                        target_dir = self.templates_monstres
                        name_prefix = "monstre"
                elif active_tab == "⚔️ Combat":
                    target_dir = self.templates_combat
                    name_prefix = "combat"
                elif active_tab == "🏆 Victoire":
                    target_dir = self.templates_victoire
                    name_prefix = "victoire"
                elif active_tab == "🛡️ Modo":
                    target_dir = self.templates_modo
                    name_prefix = "modo"
                    self.modo_crop_x = real_left
                    self.modo_crop_y = real_top
                    self.modo_crop_w = real_width
                    self.modo_crop_h = real_height
                    self.save_config()
                elif active_tab == "🎒 Pods":
                    cap_type = self.var_pods_capture_type.get()
                    if cap_type == "Alerte":
                        target_dir = self.templates_pods
                        name_prefix = "pods"
                    elif cap_type == "Banque":
                        target_dir = self.templates_pods_bank
                        name_prefix = "pods_bank"
                    elif cap_type == "Transferts":
                        target_dir = self.templates_pods_transfers
                        name_prefix = "pods_transfers"
                    elif cap_type == "Tout Transférer":
                        target_dir = self.templates_pods_transfer_all
                        name_prefix = "pods_transfer_all"
                    else:
                        target_dir = self.templates_pods
                        name_prefix = "pods"
                else:
                    return
                    
                try:
                    crop = self.current_cv_img[real_top:real_top+real_height, real_left:real_left+real_width]
                    # Ouvrir la fenêtre de prévisualisation avant de sauvegarder
                    self.show_template_preview(crop, target_dir, name_prefix, event.x, event.y)
                except Exception as e:
                    print("Erreur crop:", e)

    def show_template_preview(self, crop_img, target_dir, name_prefix, canvas_x, canvas_y):
        """Affiche une popup de prévisualisation du template capturé avant sauvegarde."""
        preview_win = ctk.CTkToplevel(self)
        preview_win.title("Aperçu du modèle")
        preview_win.attributes("-topmost", True)
        preview_win.resizable(False, False)
        
        # Calculer la taille d'affichage (zoom x4 minimum pour bien voir, max 400px)
        h, w = crop_img.shape[:2]
        zoom = max(4, min(400 // max(w, h, 1), 10))
        display_w = w * zoom
        display_h = h * zoom
        
        # Convertir BGR -> RGB pour l'affichage
        crop_rgb = cv2.cvtColor(crop_img, cv2.COLOR_BGR2RGB)
        pil_preview = Image.fromarray(crop_rgb).resize((display_w, display_h), Image.Resampling.NEAREST)
        tk_preview = ImageTk.PhotoImage(image=pil_preview)
        
        # Centrer la fenêtre
        win_w = max(display_w + 40, 280)
        win_h = display_h + 120
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w - win_w) // 2
        pos_y = (screen_h - win_h) // 2
        preview_win.geometry(f"{win_w}x{win_h}+{pos_x}+{pos_y}")
        
        # Titre
        type_names = {"monstre": "🐉 Monstre", "combat": "⚔️ Combat", "victoire": "🏆 Victoire"}
        title_text = type_names.get(name_prefix, name_prefix)
        ctk.CTkLabel(preview_win, text=f"Template capturé : {title_text}", font=ctk.CTkFont(size=14, weight="bold")).pack(pady=(10, 5))
        
        # Taille en pixels
        ctk.CTkLabel(preview_win, text=f"Taille : {w} × {h} px", font=ctk.CTkFont(size=11), text_color="gray").pack()
        
        # Image prévisualisée
        img_label = ctk.CTkLabel(preview_win, text="", image=ctk.CTkImage(light_image=pil_preview, dark_image=pil_preview, size=(display_w, display_h)))
        img_label.pack(pady=10)
        # Garder une référence pour éviter le garbage collection
        img_label._tk_img = tk_preview
        
        # Boutons
        btn_frame = ctk.CTkFrame(preview_win, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        def save_template():
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(target_dir, f"{name_prefix}_{ts}.png")
            cv2.imwrite(filepath, crop_img)
            self.load_templates_to_cache()
            preview_win.destroy()
            msg = self.canvas.create_text(canvas_x, canvas_y, text="✅ Modèle sauvé !", fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
        
        def cancel_template():
            preview_win.destroy()
            msg = self.canvas.create_text(canvas_x, canvas_y, text="❌ Annulé", fill="#ff5555", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
        
        ctk.CTkButton(btn_frame, text="✅ Sauvegarder", command=save_template, fg_color="#6F9A4D", hover_color="#5E8740", font=ctk.CTkFont(size=13, weight="bold")).pack(side="left", expand=True, fill="x", padx=(0, 5))
        ctk.CTkButton(btn_frame, text="❌ Annuler", command=cancel_template, fg_color="#C85A30", hover_color="#AE4A24", font=ctk.CTkFont(size=13, weight="bold")).pack(side="right", expand=True, fill="x", padx=(5, 0))

    def toggle_define_zone(self):
        self.is_defining_zone = not self.is_defining_zone
        if self.is_defining_zone:
            self.is_defining_enu_zone = False
            self.btn_define_zone.configure(text="[Dessine sur l'image]", fg_color=GREEN_COLOR)
        else:
            self.btn_define_zone.configure(text="🎯 Dessiner Zone (Clic Droit)", fg_color=ACCENT_COLOR)
            self.canvas.delete("magnifier")

    def _on_speed_change(self, val=None):
        try:
            s = float(self.slider_speed.get())
            tag = "Rapide" if s >= 8.5 else ("Moyen" if s >= 4.0 else "Lent")
            self.lbl_speed.configure(text=tag)
        except Exception:
            pass
        self.save_config()

    def _on_enu_mode_toggle(self):
        # Le mode Enutrof ignore le clic droit (self-cast) : on grise simplement la case
        # SANS changer sa valeur, pour qu'elle revienne comme avant en désactivant l'Enutrof.
        try:
            if self.var_enu_mode.get():
                self.chk_spell_right_click.configure(state="disabled")
            else:
                self.chk_spell_right_click.configure(state="normal")
        except Exception:
            pass
        self.save_config()

    def toggle_define_enu_zone(self):
        self.is_defining_enu_zone = not self.is_defining_enu_zone
        if self.is_defining_enu_zone:
            self.is_defining_zone = False
            try:
                self.btn_define_zone.configure(text="🎯 Dessiner Zone (Clic Droit)", fg_color=ACCENT_COLOR)
            except Exception:
                pass
            self.btn_define_enu_zone.configure(text="[Dessine la case du coffre]", fg_color=GREEN_COLOR)
        else:
            self.btn_define_enu_zone.configure(text="🎯 Dessiner Zone Coffre (Clic Droit)", fg_color=ACCENT_COLOR)
            self.canvas.delete("magnifier")

    def apply_manual_zone(self):
        try:
            x1 = int(self.entry_zone_x.get().strip())
            y1 = int(self.entry_zone_y.get().strip())
            x2 = int(self.entry_zone_w.get().strip())
            y2 = int(self.entry_zone_h.get().strip())
            
            if self.current_cv_img is not None:
                img_h, img_w = self.current_cv_img.shape[:2]
                x1 = max(0, min(x1, img_w - 1))
                y1 = max(0, min(y1, img_h - 1))
                x2 = max(0, min(x2, img_w - 1))
                y2 = max(0, min(y2, img_h - 1))
            else:
                x1 = max(0, x1)
                y1 = max(0, y1)
                x2 = max(0, x2)
                y2 = max(0, y2)
                
            self.entry_zone_x.delete(0, tk.END)
            self.entry_zone_x.insert(0, str(x1))
            self.entry_zone_y.delete(0, tk.END)
            self.entry_zone_y.insert(0, str(y1))
            self.entry_zone_w.delete(0, tk.END)
            self.entry_zone_w.insert(0, str(x2))
            self.entry_zone_h.delete(0, tk.END)
            self.entry_zone_h.insert(0, str(y2))
            
            self.combat_zone = ((x1, y1), (x2, y2))
            self.log_status(f"Ligne de clic manuelle appliquée : {self.combat_zone}")
        except ValueError:
            self.log_status("⚠️ Coordonnées invalides !")

    def clear_monstres(self):
        for f in os.listdir(self.templates_monstres):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_monstres, f))
        self.load_templates_to_cache()
        original = self.btn_clear.cget("text")
        self.btn_clear.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear.configure(text=original))
        self.log_status("Modèles monstres effacés")

    def clear_combat(self):
        for f in os.listdir(self.templates_combat):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_combat, f))
        self.load_templates_to_cache()
        original = self.btn_clear_combat.cget("text")
        self.btn_clear_combat.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_combat.configure(text=original))
        self.log_status("Modèles combat effacés")

    def clear_victoire(self):
        for f in os.listdir(self.templates_victoire):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_victoire, f))
        self.load_templates_to_cache()
        original = self.btn_clear_victoire.cget("text")
        self.btn_clear_victoire.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_victoire.configure(text=original))
        self.log_status("Modèles victoire effacés")

    def log_status(self, text):
        self.lbl_status.configure(text=f"Statut : {text}")
        print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {text}")

    def set_gui_state(self, state):
        self.entry_spell_key.configure(state=state)
        self.chk_spell_right_click.configure(state=state)
        self.entry_right_clicks_min.configure(state=state)
        self.entry_right_clicks_max.configure(state=state)
        self.entry_chain_count.configure(state=state)
        self.entry_pass_key.configure(state=state)
        self.entry_zone_x.configure(state=state)
        self.entry_zone_y.configure(state=state)
        self.entry_zone_w.configure(state=state)
        self.entry_zone_h.configure(state=state)
        
        self.btn_apply_zone.configure(state=state)
        self.btn_define_zone.configure(state=state)
        try:
            self.btn_define_enu_zone.configure(state=state)
        except Exception:
            pass
        self.zone_mode_selector.configure(state=state)
        self.btn_clear.configure(state=state)
        self.btn_clear_combat.configure(state=state)
        self.btn_clear_victoire.configure(state=state)
        self.btn_refresh.configure(state=state)
        
        self.chk_pass_turn.configure(state=state)
        self.chk_victory_esc.configure(state=state)
        self.chk_background_mode.configure(state=state)
        self.chk_hidden_capture.configure(state=state)
        self.chk_dpi_scaling.configure(state=state)
        self.window_selector.configure(state=state)
        self.entry_victory_delay_min.configure(state=state)
        self.entry_victory_delay_max.configure(state=state)
        self.entry_victory_cooldown.configure(state=state)
        self.entry_map_delay.configure(state=state)
        self.entry_launch_timeout.configure(state=state)
        
        self.chk_modo_enabled.configure(state=state)
        self.modo_mode_selector.configure(state=state)
        self.entry_modo_text.configure(state=state)
        self.entry_modo_sens.configure(state=state)
        self.slider_modo.configure(state=state)
        self.btn_define_modo_chat.configure(state=state)
        self.btn_clear_modo.configure(state=state)
        
        self.chk_close_menu.configure(state=state)
        self.carte_capture_selector.configure(state=state)
        self.btn_clear_menu.configure(state=state)
        
        self.chk_pods_enabled.configure(state=state)
        self.entry_pods_sens.configure(state=state)
        self.slider_pods.configure(state=state)
        self.pods_capture_selector.configure(state=state)
        self.btn_clear_pods.configure(state=state)

    def toggle_bot(self):
        self.is_bot_active = not self.is_bot_active
        if self.is_bot_active:
            self.focus()
            self.set_gui_state("disabled")
            self.save_config()
            self.bot_state = "MAP"
            self.my_turn = False
            self.last_click_time = 0
            self.last_combat_time = 0
            self.combat_launching = False
            self.combat_launch_time = 0
            self.combat_button_seen = False
            self.last_victory_time = 0
            self._last_monster_click_time = 0
            self.combat_count = 0
            try:
                v_min = float(self.entry_victory_delay_min.get().strip())
                v_max = float(self.entry_victory_delay_max.get().strip())
                self.current_victory_delay = np.random.uniform(min(v_min, v_max), max(v_min, v_max))
                self.current_map_delay = float(self.entry_map_delay.get().strip())
            except:
                self.current_victory_delay = 0.0
                self.current_map_delay = 3.0
            self.btn_bot.configure(text="🛑 Arrêter le Bot (F4)", fg_color=RED_COLOR, hover_color=RED_HOVER)
            self.log_status("Bot Démarré - État: CARTE")
            self._update_state_badge("MAP")
            print(f"[BOT] === DÉMARRAGE === État={self.bot_state}")

            # FIX FLUIDITÉ 1 : timers Windows haute résolution (1ms au lieu de 15ms)
            try:
                ctypes.windll.winmm.timeBeginPeriod(1)
            except Exception:
                pass

            # FIX FLUIDITÉ 2 : mettre Dofus en haute priorité CPU
            try:
                title = self.vision.target_window_title
                if title and title not in ["Écran Complet", "", None]:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        _, pid = win32process.GetWindowThreadProcessId(hwnd)
                        h = win32api.OpenProcess(0x0200 | 0x0400, False, pid)
                        if h:
                            win32process.SetPriorityClass(h, win32process.HIGH_PRIORITY_CLASS)
                            win32api.CloseHandle(h)
                            self._dofus_pid = pid
                            print(f"[BOOST] Dofus PID {pid} → HAUTE PRIORITÉ")
            except Exception as e:
                print(f"[BOOST] {e}")

            # AUTO-DPI : détecter la mise à l'échelle Windows (125%, 150%...) et activer
            # automatiquement la correction pour que les clics FANTÔME tombent au bon
            # endroit, sans que l'utilisateur ait à connaître son % ni cocher "Fix DPI".
            try:
                title = self.vision.target_window_title
                if title and title not in ["Écran Complet", "", None]:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        rx, ry = self.get_dpi_ratios(target_hwnd)
                        if rx > 0 and (abs(rx - 1.0) > 0.02 or abs(ry - 1.0) > 0.02):
                            if not self.var_dpi_scaling.get():
                                self.var_dpi_scaling.set(True)
                            scale_pct = int(round(100.0 / rx))
                            self.log_status(f"🔎 Mise à l'échelle {scale_pct}% détectée → correction clic auto activée")
                            print(f"[AUTO-DPI] ratio=({rx:.3f},{ry:.3f}) → Fix DPI ON ({scale_pct}%)")
                        else:
                            print(f"[AUTO-DPI] ratio=({rx:.3f},{ry:.3f}) → 100%, aucune correction nécessaire")
            except Exception as e:
                print(f"[AUTO-DPI] {e}")

            # FIX FLUIDITÉ 3 : booster le process DU BOT (un cran SOUS Dofus) pour que
            # les threads capture + détection tournent sans saccade.
            try:
                import os
                hbot = win32api.OpenProcess(0x0200 | 0x0400, False, os.getpid())
                if hbot:
                    win32process.SetPriorityClass(hbot, win32process.ABOVE_NORMAL_PRIORITY_CLASS)
                    win32api.CloseHandle(hbot)
                    print("[BOOST] Bot → priorité AU-DESSUS DE LA NORMALE")
            except Exception as e:
                print(f"[BOOST-BOT] {e}")

            if not hasattr(self, "cap_thread") or not self.cap_thread.is_alive():
                self.cap_thread = threading.Thread(target=self.capture_loop)
                self.cap_thread.daemon = True
                self.cap_thread.start()

            # FIX DOUBLE-CLIC : bot dans un thread dédié (pas de double instance via self.after)
            self._bot_stop_event.clear()
            self._bot_thread = threading.Thread(target=self._bot_thread_func, daemon=True)
            self._bot_thread.start()

            # Thread du clic infini (spam la case du sort en parallèle, en fantôme)
            self._infinite_thread = threading.Thread(target=self._infinite_click_loop, daemon=True)
            self._infinite_thread.start()
        else:
            self._bot_stop_event.set()
            self.set_gui_state("normal")
            self.save_config()
            self.btn_bot.configure(text="▶ Lancer le Bot (F4)", fg_color=GREEN_COLOR, hover_color=GREEN_HOVER)
            self.log_status("Bot Arrêté")
            self._update_state_badge("INACTIF")
            try:
                ctypes.windll.winmm.timeEndPeriod(1)
            except Exception:
                pass
            try:
                pid = getattr(self, '_dofus_pid', None)
                if pid:
                    h = win32api.OpenProcess(0x0200 | 0x0400, False, pid)
                    if h:
                        win32process.SetPriorityClass(h, win32process.NORMAL_PRIORITY_CLASS)
                        win32api.CloseHandle(h)
            except Exception:
                pass
            # Remettre le process du bot en priorité normale + libérer le cache GDI de capture
            try:
                import os
                hbot = win32api.OpenProcess(0x0200 | 0x0400, False, os.getpid())
                if hbot:
                    win32process.SetPriorityClass(hbot, win32process.NORMAL_PRIORITY_CLASS)
                    win32api.CloseHandle(hbot)
            except Exception:
                pass
            try:
                self.vision._free_gdi_cache()
            except Exception:
                pass

    def _update_state_badge(self, state):
        """Met à jour le badge état + compteur combats (thread-safe)."""
        badges = {
            "MAP":     ("🗺️  CARTE",    "#6F9A4D"),
            "COMBAT":  ("⚔️  COMBAT",   "#C85A30"),
            "VICTORY": ("🏆  VICTOIRE", "#DB8A2E"),
            "INACTIF": ("⬛  INACTIF",  "#7A5E3A"),
        }
        text, color = badges.get(state, ("⬛  INACTIF", "#7A5E3A"))
        def _do():
            if hasattr(self, 'lbl_state_badge'):
                self.lbl_state_badge.configure(text=text, text_color=color)
            if hasattr(self, 'lbl_combat_count'):
                self.lbl_combat_count.configure(text=f"Combats : {self.combat_count}")
        self.after(0, _do)

    def instant_stop(self):
        if self.is_bot_active:
            self.is_bot_active = False
            self.set_gui_state("normal")
            self.save_config()
            self.btn_bot.configure(text="🚀 Lancer le Bot (F4)", fg_color=GREEN_COLOR, hover_color=GREEN_HOVER)
            self.log_status("🚨 BOT ARRÊTÉ D'URGENCE !")
            self._update_state_badge("INACTIF")

    def focus_target_window(self):
        if hasattr(self, 'var_background_mode') and self.var_background_mode.get():
            return True
            
        title = self.vision.target_window_title
        if not title or title == "Écran Complet":
            return True
        try:
            hwnd = win32gui.FindWindow(None, title)
            if hwnd:
                if win32gui.IsIconic(hwnd):
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                curr_foreground = win32gui.GetForegroundWindow()
                if curr_foreground != hwnd:
                    # Assurer le focus clavier/souris Windows
                    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                    win32gui.SetForegroundWindow(hwnd)
                    time.sleep(0.1)
                return True
        except Exception as e:
            print("Erreur focus_target_window:", e)
        return False

    def win32_move_to(self, x, y, duration=0.15):
        try:
            start_x, start_y = win32gui.GetCursorPos()
            steps = int(duration * 60)
            if steps < 1:
                win32api.SetCursorPos((x, y))
                return
            for i in range(steps + 1):
                t = i / steps
                curr_x = int(start_x + (x - start_x) * t)
                curr_y = int(start_y + (y - start_y) * t)
                win32api.SetCursorPos((curr_x, curr_y))
                time.sleep(duration / steps)
        except Exception as e:
            print(f"Erreur win32_move_to: {e}")
            win32api.SetCursorPos((x, y))

    def send_key(self, vk_code, background_mode=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        scancode = ctypes.windll.user32.MapVirtualKeyW(vk_code, 0)
                        lParam_down = 1 | (scancode << 16)
                        lParam_up = 1 | (scancode << 16) | (1 << 30) | (1 << 31)
                        win32gui.PostMessage(target_hwnd, win32con.WM_KEYDOWN, vk_code, lParam_down)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_KEYUP, vk_code, lParam_up)
                        time.sleep(0.005)
                        return
                    else:
                        print("[KEY] Window handle not found for background key.")
                        return
                except Exception as e:
                    print(f"Erreur touche fantôme: {e}")
                    return
            else:
                print("[KEY] Cannot send background key on full screen.")
                return
                    
        # Repli sur l'envoi matériel classique
        hardware_key(vk_code)

    def send_text(self, text, background_mode=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        for char in text:
                            win32gui.PostMessage(target_hwnd, 0x0102, ord(char), 0) # 0x0102 is WM_CHAR
                            time.sleep(0.01)
                        return
                except Exception as e:
                    print(f"Erreur texte fantôme: {e}")
                    return
        try:
            keyboard.write(text)
            time.sleep(0.05)
        except Exception as e:
            print(f"Erreur keyboard.write: {e}")

    def get_dpi_ratios(self, hwnd):
        try:
            # 1. Obtenir les dimensions physiques (notre thread est DPI aware par défaut)
            _, _, phys_w, phys_h = win32gui.GetClientRect(hwnd)
            if phys_w <= 0 or phys_h <= 0:
                return 1.0, 1.0
                
            # 2. Obtenir les dimensions logiques en passant temporairement en DPI Unaware
            import ctypes
            try:
                SetThreadDpiAwarenessContext = ctypes.windll.user32.SetThreadDpiAwarenessContext
                SetThreadDpiAwarenessContext.restype = ctypes.c_void_p
                SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
                
                old_ctx = SetThreadDpiAwarenessContext(ctypes.c_void_p(-1))
                _, _, log_w, log_h = win32gui.GetClientRect(hwnd)
                if old_ctx:
                    SetThreadDpiAwarenessContext(old_ctx)
                    
                if log_w > 0 and log_h > 0:
                    return log_w / phys_w, log_h / phys_h
            except Exception as e:
                print("Erreur GetThreadDpiAwarenessContext:", e)
        except Exception as e:
            print("Erreur get_dpi_ratios:", e)
        return 1.0, 1.0

    def click_on_game(self, rel_x, rel_y, background_mode=None, dpi_scaling=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if dpi_scaling is None:
            dpi_scaling = hasattr(self, 'var_dpi_scaling') and self.var_dpi_scaling.get()
            
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        # Par défaut, Dofus Unity (DPI-aware) attend des coordonnées physiques directes.
                        # On n'applique le ratio de mise à l'échelle que si l'utilisateur l'active explicitement.
                        if dpi_scaling:
                            ratio_x, ratio_y = self.get_dpi_ratios(target_hwnd)
                            lx = int(rel_x * ratio_x)
                            ly = int(rel_y * ratio_y)
                        else:
                            lx = rel_x
                            ly = rel_y
                            
                        lParam = win32api.MAKELONG(lx, ly)
                        # Envoyer un déplacement de souris pour mettre à jour la case ciblée dans Dofus
                        win32gui.PostMessage(target_hwnd, win32con.WM_MOUSEMOVE, 0, lParam)
                        time.sleep(0.015) # Attendre que le jeu gère le survol de la case
                        
                        win32gui.PostMessage(target_hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lParam)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_LBUTTONUP, 0, lParam)
                        time.sleep(0.005)
                        return
                    else:
                        print("[CLICK] Window handle not found for background click.")
                        return
                except Exception as e:
                    print(f"Erreur clic fantôme: {e}")
                    return
            else:
                print("[CLICK] Cannot perform background click on full screen.")
                return

        if not self.focus_target_window():
            return

        screen_x = int(self.vision.monitor['left'] + rel_x)
        screen_y = int(self.vision.monitor['top'] + rel_y)

        try:
            # FIX : vérifier que Dofus est TOUJOURS au premier plan juste avant de cliquer
            # Evite d'envoyer des clics involontaires quand l'utilisateur est sur une autre fenêtre
            title = self.vision.target_window_title
            if title and title not in ["Écran Complet", ""]:
                hwnd_check = win32gui.FindWindow(None, title)
                if hwnd_check and win32gui.GetForegroundWindow() != hwnd_check:
                    print(f"[CLICK] Dofus n'est pas au premier plan — clic ignoré pour ne pas perturber l'utilisateur")
                    return

            win32api.SetCursorPos((screen_x, screen_y))
            time.sleep(0.005)
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, screen_x, screen_y, 0, 0)
            time.sleep(0.010)
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, screen_x, screen_y, 0, 0)

        except Exception as e:
            print(f"Erreur clic matériel: {e}")

    def right_click_on_game(self, rel_x, rel_y, background_mode=None, dpi_scaling=None):
        """Clic DROIT sur le jeu, même méthode que le clic gauche (win32api / PostMessage)."""
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if dpi_scaling is None:
            dpi_scaling = hasattr(self, 'var_dpi_scaling') and self.var_dpi_scaling.get()

        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        if dpi_scaling:
                            ratio_x, ratio_y = self.get_dpi_ratios(target_hwnd)
                            lx = int(rel_x * ratio_x)
                            ly = int(rel_y * ratio_y)
                        else:
                            lx = rel_x
                            ly = rel_y
                        lParam = win32api.MAKELONG(lx, ly)
                        win32gui.PostMessage(target_hwnd, win32con.WM_MOUSEMOVE, 0, lParam)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_RBUTTONDOWN, win32con.MK_RBUTTON, lParam)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_RBUTTONUP, 0, lParam)
                        time.sleep(0.005)
                        return
                except Exception as e:
                    print(f"Erreur clic droit fantôme: {e}")
                    return
            return

        if not self.focus_target_window():
            return

        screen_x = int(self.vision.monitor['left'] + rel_x)
        screen_y = int(self.vision.monitor['top'] + rel_y)
        try:
            title = self.vision.target_window_title
            if title and title not in ["Écran Complet", ""]:
                hwnd_check = win32gui.FindWindow(None, title)
                if hwnd_check and win32gui.GetForegroundWindow() != hwnd_check:
                    print("[RCLICK] Dofus pas au premier plan — clic droit ignoré")
                    return
            win32api.SetCursorPos((screen_x, screen_y))
            time.sleep(0.005)
            win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, screen_x, screen_y, 0, 0)
            time.sleep(0.010)
            win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP, screen_x, screen_y, 0, 0)
        except Exception as e:
            print(f"Erreur clic droit matériel: {e}")

    def _get_roi(self, templates_dir, img_h, img_w):
        """Zone de recherche (en % de la fenêtre → indépendant de la résolution) pour
        chaque type de template. Retourne (x1,y1,x2,y2) en pixels, ou None = tout l'écran.
        Désactivable via la case 'Zones optimisées'. Zones VOLONTAIREMENT généreuses
        pour rester fiables même si ta mise en page varie un peu."""
        try:
            if not self.var_roi_enabled.get():
                return None
        except Exception:
            return None
        if templates_dir == self.templates_combat:
            # Bouton "Terminer le tour" : moitié droite, bas de l'écran
            rx1, ry1, rx2, ry2 = 0.45, 0.58, 1.0, 1.0
        elif templates_dir == self.templates_victoire:
            # Écran de victoire : grand cadre centré
            rx1, ry1, rx2, ry2 = 0.08, 0.08, 0.92, 0.92
        elif templates_dir == self.templates_monstres:
            # Monstres : aire de jeu, on exclut juste la barre d'interface du bas
            rx1, ry1, rx2, ry2 = 0.0, 0.0, 1.0, 0.86
        else:
            return None
        x1 = max(0, int(img_w * rx1)); x2 = min(img_w, int(img_w * rx2))
        y1 = max(0, int(img_h * ry1)); y2 = min(img_h, int(img_h * ry2))
        if x2 - x1 < 10 or y2 - y1 < 10:
            return None
        return (x1, y1, x2, y2)

    def detect_template(self, gray_img, templates_dir, custom_threshold=None):
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
            
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
            
        if custom_threshold is not None:
            threshold = custom_threshold
        else:
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6

        # --- Zone de recherche (ROI) : ne matcher que là où l'élément peut apparaître ---
        roi = self._get_roi(templates_dir, gray_img.shape[0], gray_img.shape[1])
        if roi is not None:
            rx1, ry1, rx2, ry2 = roi
            roi_dx, roi_dy = rx1, ry1
            search_img = gray_img[ry1:ry2, rx1:rx2]
        else:
            # Repli : comportement d'origine (ignorer 45px du haut pour combat/victoire)
            roi_dx, roi_dy = 0, 0
            search_img = gray_img
            if templates_dir in [self.templates_combat, self.templates_victoire]:
                if gray_img.shape[0] > 100:
                    search_img = gray_img[45:, :]
                    roi_dy = 45

        # --- Crop-First cache optimization for static buttons ---
        last_loc_attr = None
        if templates_dir == self.templates_combat:
            last_loc_attr = 'last_combat_button_loc'
        elif templates_dir == self.templates_victoire:
            last_loc_attr = 'last_victory_button_loc'
            
        if last_loc_attr:
            last_loc = getattr(self, last_loc_attr, None)
            if last_loc is not None:
                (x, y), (h, w) = last_loc
                # Coordonnées dans search_img (on retire les offsets de la ROI)
                x_in_search = x - roi_dx
                y_in_search = y - roi_dy
                img_h, img_w = search_img.shape[:2]
                pad = 15
                y1 = max(0, y_in_search - pad)
                y2 = min(img_h, y_in_search + h + pad)
                x1 = max(0, x_in_search - pad)
                x2 = min(img_w, x_in_search + w + pad)
                if (y2 - y1) >= h and (x2 - x1) >= w:
                    crop = search_img[y1:y2, x1:x2]
                    val, loc, shape, name = self.detect_template_in_crop(crop, templates_dir)
                    if val >= threshold:
                        exact_x = x1 + loc[0] + roi_dx
                        exact_y = y1 + loc[1] + roi_dy
                        setattr(self, last_loc_attr, ((exact_x, exact_y), shape))
                        if name:
                            self.last_matched_template_path = os.path.join(templates_dir, name)
                        return val, (exact_x, exact_y), shape, name

        best_val = 0
        best_loc = None
        best_shape = None
        best_name = None
        best_idx = -1
        
        for idx, (t_name, t_img) in enumerate(cached_list):
            # S'assurer que le template n'est pas plus grand que l'image de recherche
            if t_img.shape[0] > search_img.shape[0] or t_img.shape[1] > search_img.shape[1]:
                continue
                
            res = cv2.matchTemplate(search_img, t_img, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            
            if max_val > best_val:
                best_val = max_val
                best_loc = max_loc
                best_shape = t_img.shape
                best_name = t_name
                best_idx = idx
                
            # Arrêt précoce : si on a un match parfait/excellent (> 85%), c'est forcément la bonne cible
            if max_val >= 0.85:
                break
                
        # Move-To-Front (MTF) cache optimization
        if best_val >= threshold and best_idx > 0:
            cached_list.insert(0, cached_list.pop(best_idx))
            
        if best_loc is not None:
            best_loc = (best_loc[0] + roi_dx, best_loc[1] + roi_dy)
            if last_loc_attr:
                setattr(self, last_loc_attr, (best_loc, best_shape))
            
        return best_val, best_loc, best_shape, best_name

    def detect_template_nearest(self, gray_img, templates_dir, center_xy, custom_threshold=None, exclude=None):
        """Comme detect_template mais renvoie la cible (au-dessus du seuil) dont le
        centre est le PLUS PROCHE de center_xy (le perso, ~ centre de l'ecran).
        Chaque zone de match distincte = 1 candidat (regroupement par composantes
        connexes), donc un monstre n'est pas compte plusieurs fois."""
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
        if custom_threshold is not None:
            threshold = custom_threshold
        else:
            try:
                threshold = self.slider.get()
            except Exception:
                threshold = 0.6

        # Zone de recherche (ROI) monstres : aire de jeu (exclut la barre du bas)
        roi = self._get_roi(templates_dir, gray_img.shape[0], gray_img.shape[1])
        if roi is not None:
            rx1, ry1, rx2, ry2 = roi
            roi_dx, roi_dy = rx1, ry1
            search_img = gray_img[ry1:ry2, rx1:rx2]
        else:
            roi_dx, roi_dy = 0, 0
            search_img = gray_img
        # Détection : 2 temps (rapide) si activé, sinon pleine résolution
        use_fast = False
        try:
            use_fast = self.var_fast_detect.get()
        except Exception:
            use_fast = False
        if use_fast:
            candidates = self._detect_nearest_fast(search_img, templates_dir, cached_list, threshold, roi_dx, roi_dy)
        else:
            candidates = self._detect_nearest_full(search_img, cached_list, threshold, roi_dx, roi_dy)

        if not candidates:
            return 0, None, None, None

        tx, ty = center_xy
        def _d2(c):
            (x, y), (h, w) = c[1], c[2]
            mx, my = x + w / 2.0, y + h / 2.0
            return (mx - tx) ** 2 + (my - ty) ** 2

        # Exclure les positions blacklistées (groupes pris encore visibles) :
        # on renvoie alors le PLUS PROCHE parmi les NON blacklistés.
        if exclude:
            def _excluded(c):
                (x, y), (h, w) = c[1], c[2]
                mx, my = x + w / 2.0, y + h / 2.0
                for ex, ey in exclude:
                    if abs(mx - ex) < 60 and abs(my - ey) < 60:
                        return True
                return False
            filtered = [c for c in candidates if not _excluded(c)]
            if filtered:
                candidates = filtered
            # si TOUS sont blacklistés, on ne renvoie rien (rien de cliquable)
            else:
                return 0, None, None, None

        best = min(candidates, key=_d2)
        if best[3]:
            self.last_matched_template_path = os.path.join(templates_dir, best[3])
        return best[0], best[1], best[2], best[3]

    def _get_small_templates(self, templates_dir, cached_list, scale):
        """Cache des templates réduits (évite de redimensionner à chaque frame).
        Reconstruit automatiquement si le nombre de templates change."""
        cache = getattr(self, "_templates_small_cache", None)
        if cache is None:
            cache = {}
            self._templates_small_cache = cache
        entry = cache.get(templates_dir)
        if entry is not None and entry[0] == len(cached_list) and abs(entry[1] - scale) < 1e-6:
            return entry[2]
        small_list = []
        for t_name, t_img in cached_list:
            h, w = t_img.shape[:2]
            ts = cv2.resize(t_img, (max(1, int(w * scale)), max(1, int(h * scale))),
                            interpolation=cv2.INTER_AREA)
            small_list.append((t_name, ts, t_img))
        cache[templates_dir] = (len(cached_list), scale, small_list)
        return small_list

    def _detect_nearest_full(self, search_img, cached_list, threshold, roi_dx, roi_dy):
        """Passe unique pleine résolution (comportement d'origine)."""
        candidates = []
        for t_name, t_img in cached_list:
            if t_img.shape[0] > search_img.shape[0] or t_img.shape[1] > search_img.shape[1]:
                continue
            res = cv2.matchTemplate(search_img, t_img, cv2.TM_CCOEFF_NORMED)
            mask = (res >= threshold).astype("uint8")
            if not mask.any():
                continue
            num, labels = cv2.connectedComponents(mask)
            for lbl in range(1, num):
                comp = (labels == lbl)
                ys, xs = np.where(comp)
                k = int(np.argmax(res[comp]))
                py, px = int(ys[k]), int(xs[k])
                candidates.append((float(res[py, px]), (px + roi_dx, py + roi_dy), t_img.shape, t_name))
        return candidates

    def _detect_nearest_fast(self, search_img, templates_dir, cached_list, threshold, roi_dx, roi_dy):
        """Détection 2 temps : passe grossière sur image réduite (~4× moins de pixels)
        pour repérer les candidats, puis vérif PRÉCISE en pleine résolution dans une
        petite fenêtre autour de chaque candidat. Coordonnées et score finaux exacts."""
        SCALE = 0.5
        coarse_thr = max(0.40, threshold - 0.22)  # seuil abaissé (marge de sécurité, validée en test)
        sh, sw = search_img.shape[:2]
        if sh < 8 or sw < 8:
            return self._detect_nearest_full(search_img, cached_list, threshold, roi_dx, roi_dy)
        small = cv2.resize(search_img, (max(1, int(sw * SCALE)), max(1, int(sh * SCALE))),
                           interpolation=cv2.INTER_AREA)
        small_templates = self._get_small_templates(templates_dir, cached_list, SCALE)
        candidates = []
        seen = []  # anti-doublon (même monstre trouvé par 2 templates)
        for t_name, t_small, t_full in small_templates:
            th_s, tw_s = t_small.shape[:2]
            fh, fw = t_full.shape[:2]
            if th_s < 2 or tw_s < 2:
                continue
            if th_s > small.shape[0] or tw_s > small.shape[1]:
                continue
            res = cv2.matchTemplate(small, t_small, cv2.TM_CCOEFF_NORMED)
            mask = (res >= coarse_thr).astype("uint8")
            if not mask.any():
                continue
            num, labels = cv2.connectedComponents(mask)
            margin = int(4 / SCALE) + 4  # tolérance de localisation grossière
            for lbl in range(1, num):
                comp = (labels == lbl)
                ys, xs = np.where(comp)
                k = int(np.argmax(res[comp]))
                spy, spx = int(ys[k]), int(xs[k])
                ax, ay = int(spx / SCALE), int(spy / SCALE)
                wx1, wy1 = max(0, ax - margin), max(0, ay - margin)
                wx2, wy2 = min(sw, ax + fw + margin), min(sh, ay + fh + margin)
                win = search_img[wy1:wy2, wx1:wx2]
                if win.shape[0] < fh or win.shape[1] < fw:
                    continue
                r2 = cv2.matchTemplate(win, t_full, cv2.TM_CCOEFF_NORMED)
                _, maxv, _, maxloc = cv2.minMaxLoc(r2)
                if maxv < threshold:
                    continue
                fx = wx1 + maxloc[0] + roi_dx
                fy = wy1 + maxloc[1] + roi_dy
                dup = False
                for ex, ey in seen:
                    if abs(fx - ex) < fw * 0.5 and abs(fy - ey) < fh * 0.5:
                        dup = True
                        break
                if dup:
                    continue
                seen.append((fx, fy))
                candidates.append((float(maxv), (fx, fy), t_full.shape, t_name))
        return candidates

    def detect_template_in_crop(self, gray_crop, templates_dir):
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
            
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
            
        best_val = 0
        best_loc = None
        best_shape = None
        best_name = None
        best_idx = -1
        
        for idx, (t_name, t_img) in enumerate(cached_list):
            if t_img.shape[0] > gray_crop.shape[0] or t_img.shape[1] > gray_crop.shape[1]:
                continue
                
            res = cv2.matchTemplate(gray_crop, t_img, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            
            if max_val > best_val:
                best_val = max_val
                best_loc = max_loc
                best_shape = t_img.shape
                best_name = t_name
                best_idx = idx
                
            # Arrêt précoce
            if max_val >= 0.85:
                break
                
        try:
            threshold = self.slider.get()
        except:
            threshold = 0.6
            
        if best_val >= threshold and best_idx > 0:
            cached_list.insert(0, cached_list.pop(best_idx))
            
        return best_val, best_loc, best_shape, best_name

    def is_combat_button_visible(self, threshold=None, background_mode=None):
        if threshold is None:
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
        if background_mode is None:
            background_mode = getattr(self, 'hidden_capture_active', False)
            
        # 1. Première vérification ultra-rapide en mémoire (0ms)
        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
            try:
                frame = self.latest_captured_frame.copy()
                gray_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                check_threshold = max(0.40, threshold - 0.15)
                
                last_loc = getattr(self, 'last_combat_button_loc', None)
                if last_loc is not None:
                    (x, y), (h, w) = last_loc
                    img_h, img_w = gray_img.shape[:2]
                    pad = 10
                    y1 = max(0, y - pad)
                    y2 = min(img_h, y + h + pad)
                    x1 = max(0, x - pad)
                    x2 = min(img_w, x + w + pad)
                    if (y2 - y1) >= h and (x2 - x1) >= w:
                        crop = gray_img[y1:y2, x1:x2]
                        val, loc, shape, name = self.detect_template_in_crop(crop, self.templates_combat)
                        if val >= check_threshold:
                            exact_x = x1 + loc[0]
                            exact_y = y1 + loc[1]
                            self.last_combat_button_loc = ((exact_x, exact_y), shape)
                            if name:
                                self.last_matched_template_path = os.path.join(self.templates_combat, name)
                            return True
                
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= check_threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    return True
            except Exception as e:
                print(f"Erreur première vérification mémoire: {e}")

        # 2. Si non trouvé en mémoire (ex: bouton caché par animation), on fait jusqu'à 2 tentatives supplémentaires en capturant une NOUVELLE image à chaque fois
        for attempt in range(1, 3):
            try:
                time.sleep(0.04) # Laisser le temps au jeu d'avancer
                
                # Forcer une nouvelle capture d'écran fraîche en direct
                frame = self.vision.get_latest_frame(background_mode=background_mode)
                if frame is None:
                    continue
                
                gray_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                check_threshold = max(0.40, threshold - 0.15)
                
                last_loc = getattr(self, 'last_combat_button_loc', None)
                if last_loc is not None:
                    (x, y), (h, w) = last_loc
                    img_h, img_w = gray_img.shape[:2]
                    pad = 10
                    y1 = max(0, y - pad)
                    y2 = min(img_h, y + h + pad)
                    x1 = max(0, x - pad)
                    x2 = min(img_w, x + w + pad)
                    if (y2 - y1) >= h and (x2 - x1) >= w:
                        crop = gray_img[y1:y2, x1:x2]
                        val, loc, shape, name = self.detect_template_in_crop(crop, self.templates_combat)
                        if val >= check_threshold:
                            exact_x = x1 + loc[0]
                            exact_y = y1 + loc[1]
                            self.last_combat_button_loc = ((exact_x, exact_y), shape)
                            if name:
                                self.last_matched_template_path = os.path.join(self.templates_combat, name)
                            return True
                
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= check_threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    return True
            except Exception as e:
                print(f"Erreur tentative {attempt} is_combat_button_visible: {e}")
                
        # Si après ces tentatives le bouton reste introuvable, on confirme sa disparition
        return False

    def execute_combat_turn(self):
        try:
            if self.var_spell_right_click.get() and not self.var_enu_mode.get():
                spell_key_vk = "RIGHT_CLICK"
            else:
                spell_key_str = self.entry_spell_key.get().strip()
                spell_key_vk = get_vk_code(spell_key_str)
                if spell_key_vk is None:
                    spell_key_vk = 0x31
        except Exception:
            spell_key_vk = 0x31

        try:
            chain_count = int(self.entry_chain_count.get().strip())
        except Exception:
            chain_count = 2

        try:
            delay_s = self.slider_delay.get()
        except Exception:
            delay_s = 1.0

        pass_turn_checked = self.var_pass_turn.get()
        try:
            pass_turn_key_str = self.entry_pass_key.get().strip()
            pass_turn_key_vk = get_vk_code(pass_turn_key_str)
            if pass_turn_key_vk is None:
                pass_turn_key_vk = 0x70
        except Exception:
            pass_turn_key_vk = 0x70

        try:
            base_start_delay = self.slider_start_delay.get()
        except Exception:
            base_start_delay = 0.3

        try:
            base_end_delay = self.slider_end_delay.get()
        except Exception:
            base_end_delay = 0.15

        background_mode = self.var_background_mode.get()
        dpi_scaling = self.var_dpi_scaling.get()

        combat_zone = None
        try:
            ex1 = int(float(self.entry_zone_x.get().strip()))
            ey1 = int(float(self.entry_zone_y.get().strip()))
            ex2 = int(float(self.entry_zone_w.get().strip()))
            ey2 = int(float(self.entry_zone_h.get().strip()))
            combat_zone = ((ex1, ey1), (ex2, ey2))
        except Exception:
            combat_zone = getattr(self, 'combat_zone', None)

        click_zone_mode = self.zone_mode_var.get()
        
        try:
            threshold = self.slider.get()
        except:
            threshold = 0.6

        # Mode Enutrof : poser le coffre + lancer Chance dessus
        enu_mode = self.var_enu_mode.get()
        try:
            enu_chest_vk = get_vk_code(self.entry_enu_chest_key.get().strip())
            if enu_chest_vk is None:
                enu_chest_vk = 0x35  # '5'
        except Exception:
            enu_chest_vk = 0x35
        try:
            enu_chance_vk = get_vk_code(self.entry_enu_chance_key.get().strip())
            if enu_chance_vk is None:
                enu_chance_vk = 0x36  # '6'
        except Exception:
            enu_chance_vk = 0x36
        enu_chest_once = self.var_enu_chest_once.get()

        # Lancer les actions en arrière-plan avec la configuration figée thread-safe
        t = threading.Thread(target=self.run_combat_actions, args=(
            spell_key_vk, chain_count, delay_s, pass_turn_checked, pass_turn_key_vk,
            base_start_delay, base_end_delay, background_mode, dpi_scaling, combat_zone,
            click_zone_mode, threshold,
            enu_mode, enu_chest_vk, enu_chance_vk, enu_chest_once
        ))
        t.daemon = True
        t.start()

    def sleep_check(self, seconds):
        start = time.time()
        while time.time() - start < seconds:
            if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                return False
            time.sleep(0.05)
        return True

    def sleep_check_pods(self, seconds):
        start = time.time()
        while time.time() - start < seconds:
            if not self.is_bot_active:
                return False
            time.sleep(0.05)
        return True

    def run_combat_actions(self, spell_key_vk, chain_count, delay_s, pass_turn_checked, pass_turn_key_vk,
                           base_start_delay, base_end_delay, background_mode, dpi_scaling, combat_zone,
                           click_zone_mode, threshold,
                           enu_mode=False, enu_chest_vk=0x35, enu_chance_vk=0x36, enu_chest_once=True):
        try:
            # Attendre le délai début de tour configuré (avec jitter aléatoire de +-15%)
            start_delay = base_start_delay * np.random.uniform(0.85, 1.15)
            if not self.sleep_check(start_delay):
                return
            
            # S'assurer que le jeu est au premier plan (si non fantôme)
            if not background_mode:
                self.focus_target_window()
            
            # Zone des sorts (rox) : TOUJOURS requise — c'est le sort lancé "comme d'hab"
            if not combat_zone:
                self.log_status("⚠️ Zone de clic indéfinie !")
                if pass_turn_checked and pass_turn_key_vk:
                    self.log_status("Passage du tour...")
                    self.send_key(pass_turn_key_vk, background_mode=background_mode)
                return
            (cx1, cy1), (cx2, cy2) = combat_zone
            # Position du sort rox, figée une fois par combat (centre + micro-décalage)
            if self.combat_click_pos is None:
                ccx = (cx1 + cx2) // 2
                ccy = (cy1 + cy2) // 2
                cjx = min(4, max(0, abs(cx2 - cx1) // 4))
                cjy = min(4, max(0, abs(cy2 - cy1) // 4))
                self.combat_click_pos = (ccx + (random.randint(-cjx, cjx) if cjx > 0 else 0),
                                         ccy + (random.randint(-cjy, cjy) if cjy > 0 else 0))
                self.log_status(f"Position de clic du combat : {self.combat_click_pos}")
            spell_target = self.combat_click_pos

            # Zone coffre (Enutrof) : requise UNIQUEMENT en mode Enutrof
            enu_target = None
            if enu_mode:
                ez = getattr(self, 'enu_zone', None)
                if not ez:
                    self.log_status("⚠️ Zone Coffre (Enutrof) non définie ! Dessine-la dans l'onglet Combat.")
                    if pass_turn_checked and pass_turn_key_vk:
                        self.send_key(pass_turn_key_vk, background_mode=background_mode)
                    return
                (ex1, ey1), (ex2, ey2) = ez
                if getattr(self, 'enu_click_pos', None) is None:
                    ecx = (ex1 + ex2) // 2
                    ecy = (ey1 + ey2) // 2
                    ejx = min(4, max(0, abs(ex2 - ex1) // 4))
                    ejy = min(4, max(0, abs(ey2 - ey1) // 4))
                    self.enu_click_pos = (ecx + (random.randint(-ejx, ejx) if ejx > 0 else 0),
                                          ecy + (random.randint(-ejy, ejy) if ejy > 0 else 0))
                    self.log_status(f"Position coffre (Enutrof) : {self.enu_click_pos}")
                enu_target = self.enu_click_pos

            # ── Rotation Enutrof : coffre + Chance AVANT le sort rox ──
            if enu_mode and enu_target is not None:
                delay_after_key = self._spd("key_bg") if background_mode else self._spd("key_fg")
                place_chest = (not enu_chest_once) or (not getattr(self, "_enu_chest_placed", False))
                if place_chest:
                    if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                        self.my_turn = False
                        return
                    if not background_mode:
                        self.focus_target_window(); time.sleep(0.15)
                    self.log_status("🪙 Pose du coffre...")
                    self.send_key(enu_chest_vk, background_mode=background_mode)
                    if not self.sleep_check(delay_after_key):
                        return
                    self.click_on_game(enu_target[0], enu_target[1], background_mode=background_mode, dpi_scaling=dpi_scaling)
                    self._enu_chest_placed = True
                    if not self.sleep_check(delay_s):
                        return
                # Chance sur le coffre (à chaque tour)
                if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                    self.my_turn = False
                    return
                if not background_mode:
                    self.focus_target_window(); time.sleep(0.15)
                self.log_status("🍀 Chance sur le coffre...")
                self.send_key(enu_chance_vk, background_mode=background_mode)
                if not self.sleep_check(delay_after_key):
                    return
                self.click_on_game(enu_target[0], enu_target[1], background_mode=background_mode, dpi_scaling=dpi_scaling)
                if not self.sleep_check(delay_s):
                    return

            # ── Sort rox (comme d'hab) : boucle normale sur la zone des sorts ──
            target_x, target_y = spell_target
            for i in range(chain_count):
                if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                    return
                
                # Vérification en temps réel avant chaque sort
                if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                    self.log_status("⚠️ Bouton 'Terminer' invisible. Fin de combat/tour détecté !")
                    self.my_turn = False
                    return
                
                # S'assurer que le jeu est toujours actif (si non fantôme)
                if not background_mode:
                    self.focus_target_window()
                    time.sleep(0.15)
                
                self.log_status(f"Sort {i+1}/{chain_count}...")
                
                # 1. Touche Sort (uniquement en mode clavier)
                if spell_key_vk != "RIGHT_CLICK":
                    self.send_key(spell_key_vk, background_mode=background_mode)
                    delay_after_key = self._spd("key_bg") if background_mode else self._spd("key_fg")
                    if not self.sleep_check(delay_after_key):
                        return

                    # 2. Clic gauche sur la cible (uniquement en mode clavier)
                    self.click_on_game(target_x, target_y, background_mode=background_mode, dpi_scaling=dpi_scaling)

                # 3. Attente délai entre les sorts
                if not self.sleep_check(delay_s):
                    return
                
            # 4. Passer le tour
            if pass_turn_checked and pass_turn_key_vk:
                if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                    return
                
                # Attente délai de fin
                if base_end_delay > 0:
                    if not self.sleep_check(base_end_delay):
                        return
                
                # Vérification en temps réel avant de passer le tour
                if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                    self.log_status("⚠️ Bouton 'Terminer' invisible avant de passer le tour. Annulé.")
                    self.my_turn = False
                    return

                if not background_mode:
                    self.focus_target_window()
                self.log_status("Fin de mon tour (Pass)")
                # Si clic droit active, clic droit sur le sort (position fixe du combat).
                # En mode Enutrof on passe toujours par la touche (pas de self-cast clic droit).
                if spell_key_vk == "RIGHT_CLICK" and not enu_mode:
                    try:
                        min_c = int(self.entry_right_clicks_min.get().strip() or "1")
                        max_c = int(self.entry_right_clicks_max.get().strip() or "3")
                        min_c = max(1, min(min_c, max_c))
                        max_c = max(min_c, max_c)
                    except Exception:
                        min_c, max_c = 1, 3
                    num_clicks = random.randint(min_c, max_c)
                    for _ in range(num_clicks):
                        self.right_click_on_game(target_x, target_y, background_mode=background_mode, dpi_scaling=dpi_scaling)
                        if _ < num_clicks - 1:
                            time.sleep(random.uniform(0.08, 0.20))
                else:
                    self.send_key(pass_turn_key_vk, background_mode=background_mode)
                self.sleep_check(self._spd("post_combat"))
        except Exception as e:
            print(f"Erreur actions combat: {e}")

    def _infinite_click_loop(self):
        """Spam-clique en continu la case du sort (centre de la zone), en mode
        FANTÔME (PostMessage) pour ne pas bouger le curseur ni gêner les autres
        clics du bot. Tourne tant que l'option est cochée et le bot actif."""
        while not self._bot_stop_event.is_set() and self.is_bot_active:
            try:
                if self.var_infinite_click.get():
                    zone = getattr(self, 'combat_zone', None)
                    if zone:
                        (x1, y1), (x2, y2) = zone
                        cx = (x1 + x2) // 2
                        cy = (y1 + y2) // 2
                        dpi = hasattr(self, 'var_dpi_scaling') and self.var_dpi_scaling.get()
                        # Clic droit si le sort est en mode clic droit, sinon clic gauche.
                        # Toujours en fantôme (background_mode=True) → ne bouge pas la souris.
                        if self.var_spell_right_click.get():
                            self.right_click_on_game(cx, cy, background_mode=True, dpi_scaling=dpi)
                        else:
                            self.click_on_game(cx, cy, background_mode=True, dpi_scaling=dpi)
                    try:
                        d = float(self.entry_infinite_delay.get().strip().replace(",", "."))
                    except Exception:
                        d = 0.05
                    d = max(0.01, d)
                    self._bot_stop_event.wait(timeout=d)
                else:
                    self._bot_stop_event.wait(timeout=0.15)
            except Exception as e:
                print(f"[CLIC-INFINI] {e}")
                self._bot_stop_event.wait(timeout=0.2)

    def _bot_thread_func(self):
        """Thread dédié — évite le throttling de tkinter en arrière-plan."""
        last_fid = -1
        last_proc_small = None
        last_proc_time = 0.0
        while not self._bot_stop_event.is_set() and self.is_bot_active:
            try:
                fid = getattr(self, '_frame_id', 0)
                # Ne traiter QUE les images neuves : inutile de re-scanner 2x la même
                if (hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None
                        and fid != last_fid):
                    last_fid = fid
                    do_process = True
                    # En COMBAT (cadence adaptative ON) : sauter le scan si l'écran n'a
                    # pas changé (statique = rien de neuf). Filet : on traite quand même
                    # au moins toutes les 150ms. Sur la CARTE on ne saute jamais (course au vol).
                    adaptive = getattr(self, "var_adaptive_capture", None)
                    if (self.bot_state == "COMBAT" and adaptive is not None and adaptive.get()):
                        g = self._get_current_gray()
                        if g is not None:
                            small = cv2.resize(g, (64, 36), interpolation=cv2.INTER_AREA)
                            now = time.time()
                            static = (last_proc_small is not None
                                      and float(np.mean(cv2.absdiff(small, last_proc_small))) < 2.0)
                            if static and (now - last_proc_time) < 0.15:
                                do_process = False
                            else:
                                last_proc_small = small
                                last_proc_time = now
                    if do_process:
                        self.bot_logic_loop()
            except Exception as e:
                import traceback
                print("[BOT THREAD]", e, traceback.format_exc())
            # Sondage rapide et léger (le travail lourd ne tourne que sur image neuve)
            interval = self._spd("poll_combat") if self.bot_state == "COMBAT" else self._spd("poll_map")
            self._bot_stop_event.wait(timeout=interval)

    def _spd(self, key):
        """Valeur de timing interpolée selon le curseur de vitesse globale
        (1 = lent .. 10 = rapide), entre les profils Lent et Rapide."""
        try:
            s = float(self.slider_speed.get())
        except Exception:
            s = 10.0
        s = max(1.0, min(10.0, s))
        t = (s - 1.0) / 9.0  # 0 (lent) .. 1 (rapide)
        lo = SPEED_PROFILES["Lent"].get(key, 0.0)
        hi = SPEED_PROFILES["Rapide"].get(key, 0.0)
        return lo + (hi - lo) * t

    def _get_current_gray(self):
        """Renvoie le niveau de gris de la frame courante, calculé une seule fois
        dans le thread de capture et réutilisé partout (évite de reconvertir la même
        image plusieurs fois par boucle). Fallback si pas encore prêt."""
        gray = getattr(self, "_frame_gray", None)
        if gray is not None:
            return gray
        frame = getattr(self, "latest_captured_frame", None)
        if frame is None:
            return None
        try:
            return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        except Exception:
            return None

    def _monster_still_present(self, rel_x, rel_y, margin=80):
        """Re-vérifie sur l'image LA PLUS FRAÎCHE qu'un monstre est toujours
        présent près de (rel_x, rel_y). Évite de cliquer un groupe qui vient
        d'être pris par un joueur plus rapide, dans l'intervalle détection→clic."""
        try:
            frame = getattr(self, 'latest_captured_frame', None)
            if frame is None:
                return True  # impossible de vérifier → on autorise le clic
            cached_list = self.templates_cache.get(self.templates_monstres, [])
            if not cached_list:
                return True
            gray = self._get_current_gray()
            if gray is None:
                return True
            H, W = gray.shape[:2]
            try:
                thr = float(self.slider.get())
            except Exception:
                thr = 0.77
            for t_name, t_img in cached_list:
                th, tw = t_img.shape[:2]
                x1 = max(0, rel_x - tw // 2 - margin)
                y1 = max(0, rel_y - th // 2 - margin)
                x2 = min(W, rel_x + tw // 2 + margin)
                y2 = min(H, rel_y + th // 2 + margin)
                region = gray[y1:y2, x1:x2]
                if region.shape[0] < th or region.shape[1] < tw:
                    continue
                res = cv2.matchTemplate(region, t_img, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, _ = cv2.minMaxLoc(res)
                if max_val >= thr:
                    return True
            return False
        except Exception:
            return True  # en cas d'erreur, ne pas casser le farm

    def bot_logic_loop(self):
        try:
            if not self.is_bot_active:
                return
                
            if not hasattr(self, 'latest_captured_frame') or self.latest_captured_frame is None:
                return
                
            gray_img = self._get_current_gray()
            if gray_img is None:
                return
            
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
                
            # --- DETECTION DU MENU PRINCIPAL (uniquement hors combat) ---
            if self.var_close_menu.get() and self.bot_state != "COMBAT":
                has_menu_templates = len(self.templates_cache.get(self.templates_menu, [])) > 0
                if has_menu_templates:
                    menu_val, menu_loc, menu_shape, menu_name = self.detect_template(gray_img, self.templates_menu)
                    if menu_val >= threshold and menu_loc is not None:
                        self.log_status(f"📋 Menu Principal détecté (Score: {int(menu_val*100)}%). Fermeture avec Echap...")
                        self.focus_target_window()
                        time.sleep(0.1)
                        self.send_key(0x1B) # VK_ESCAPE is 0x1B
                        time.sleep(0.3)
                        
                        return
            
                    # --- VERIFICATION DES PODS (BANQUE AUTOMATIQUE) ---
            if self.var_pods_enabled.get():
                has_pods_templates = len(self.templates_cache.get(self.templates_pods, [])) > 0
                if has_pods_templates:
                    pods_threshold = self.slider_pods.get()
                    pods_val, pods_loc, _ , _ = self.detect_template(gray_img, self.templates_pods, custom_threshold=pods_threshold)
                    if pods_val >= pods_threshold and pods_loc is not None:
                        self.log_status(f"🎒 [PODS] Alerte Pods détectée ! (Score: {int(pods_val*100)}%). Lancement de la séquence Banque...")
                        
                        self.focus_target_window()
                        time.sleep(0.2)
                        
                        # 1. Clic Ouvrir Banque
                        self.log_status("1/3 Recherche du bouton Banque par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            b_val, b_loc, b_shape, _ = self.detect_template(curr_gray, self.templates_pods_bank, custom_threshold=pods_threshold)
                            if b_loc is not None and b_val >= pods_threshold:
                                cx = b_loc[0] + b_shape[1] // 2
                                cy = b_loc[1] + b_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("1/3 Banque ouverte (clic effectué).")
                            else:
                                self.log_status("⚠️ Étape 1/3 échouée : Bouton Banque non détecté à l'écran.")
                                return
                                
                        # Attente ouverture banque
                        if not self.sleep_check_pods(2.0): return
                        
                        # 2. Clic Transferts Avancés
                        self.log_status("2/3 Recherche du bouton Transferts par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            t_val, t_loc, t_shape, _ = self.detect_template(curr_gray, self.templates_pods_transfers, custom_threshold=pods_threshold)
                            if t_loc is not None and t_val >= pods_threshold:
                                cx = t_loc[0] + t_shape[1] // 2
                                cy = t_loc[1] + t_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("2/3 Clic Transferts effectué.")
                            else:
                                self.log_status("⚠️ Étape 2/3 échouée : Bouton Transferts non détecté.")
                                self.send_key(0x1B) # Tenter de fermer par sécurité
                                return
                                
                        # Attente ouverture menu transfert
                        if not self.sleep_check_pods(2.0): return
                        
                        # 3. Clic Transférer tout
                        self.log_status("3/3 Recherche du bouton Tout Transférer par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            a_val, a_loc, a_shape, _ = self.detect_template(curr_gray, self.templates_pods_transfer_all, custom_threshold=pods_threshold)
                            if a_loc is not None and a_val >= pods_threshold:
                                cx = a_loc[0] + a_shape[1] // 2
                                cy = a_loc[1] + a_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("3/3 Clic Tout Transférer effectué.")
                            else:
                                self.log_status("⚠️ Étape 3/3 échouée : Bouton Tout Transférer non détecté.")
                                self.send_key(0x1B)
                                return
                                
                        # Attente fin de transfert
                        if not self.sleep_check_pods(2.0): return
                        
                        # 4. Appuyer sur Echap
                        self.log_status("Fermeture de la banque par Echap...")
                        self.send_key(0x1B) # Escape
                        if not self.sleep_check_pods(1.0): return
                        
                        self.log_status("🎒 [PODS] Banque complétée. Reprise du bot.")
                        
                        return

            
            # --- VERIFICATION ANTI-MODO ---
            if self.var_modo_enabled.get():
                has_modo_templates = len(self.templates_cache.get(self.templates_modo, [])) > 0
                if has_modo_templates:
                    if (self.modo_crop_x is not None and self.modo_crop_y is not None and 
                        self.modo_crop_w is not None and self.modo_crop_h is not None):
                        img_h, img_w = gray_img.shape[:2]
                        x1 = max(0, min(self.modo_crop_x, img_w - 1))
                        y1 = max(0, min(self.modo_crop_y, img_h - 1))
                        x2 = max(0, min(self.modo_crop_x + self.modo_crop_w, img_w))
                        y2 = max(0, min(self.modo_crop_y + self.modo_crop_h, img_h))
                        
                        if (x2 - x1) > 5 and (y2 - y1) > 5:
                            gray_crop = gray_img[y1:y2, x1:x2]
                            modo_val, modo_loc, modo_shape, modo_name = self.detect_template_in_crop(gray_crop, self.templates_modo)
                        else:
                            modo_val, modo_loc, modo_shape, modo_name = self.detect_template(gray_img, self.templates_modo)
                    else:
                        modo_val, modo_loc, modo_shape, modo_name = self.detect_template(gray_img, self.templates_modo)
                        
                    trigger_mode = self.var_modo_trigger_mode.get()
                    modo_threshold = self.slider_modo.get()
                    
                    trigger_fired = False
                    reason = ""
                    
                    if trigger_mode == "Présence":
                        if modo_val >= modo_threshold:
                            trigger_fired = True
                            reason = f"Modèle Modo '{modo_name}' détecté avec une ressemblance de {int(modo_val*100)}% (seuil: {int(modo_threshold*100)}%)"
                    elif trigger_mode == "Changement":
                        if modo_val < modo_threshold:
                            trigger_fired = True
                            reason = f"Changement détecté dans la zone Modo! La ressemblance a chuté à {int(modo_val*100)}% (seuil: {int(modo_threshold*100)}%)"
                            
                    if trigger_fired:
                        self.log_status(f"🚨 [ANTI-MODO] DECLENCHE ! Raison: {reason}")
                        # 1. Arrêter immédiatement le bot
                        self.is_bot_active = False
                        self.btn_bot.configure(text="🚀 Lancer le Bot (F4)", fg_color=GREEN_COLOR)
                        self.set_gui_state("normal")
                        
                        # Déclencher le popup d'alerte dans un thread séparé (topmost)
                        def show_warning_popup():
                            try:
                                import ctypes
                                ctypes.windll.user32.MessageBoxW(0, "Attention modo !", "Alerte Securité", 0x10 | 0x40000)
                            except Exception as e:
                                print(f"Erreur popup: {e}")
                        threading.Thread(target=show_warning_popup, daemon=True).start()
                        
                        # 2. Amener de force Dofus en avant-plan pour réaction rapide
                        title = self.vision.target_window_title
                        if title and title != "Écran Complet":
                            try:
                                hwnd = win32gui.FindWindow(None, title)
                                if hwnd:
                                    if win32gui.IsIconic(hwnd):
                                        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                                    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                                    win32gui.SetForegroundWindow(hwnd)
                                    time.sleep(0.2)
                            except Exception as e:
                                print(f"Erreur force focus: {e}")
                        
                        custom_text = self.entry_modo_text.get().strip() or "oui ?"
                        
                        # 3. Aller sur la zone de clic sélectionnée pour le chat (si définie) et cliquer
                        if self.modo_chat_x is not None and self.modo_chat_y is not None:
                            self.log_status(f"Clic sur le chat de réponse à ({self.modo_chat_x}, {self.modo_chat_y})...")
                            self.click_on_game(self.modo_chat_x, self.modo_chat_y)
                            time.sleep(0.2)
                            
                            # 4. Écrire le texte personnalisé
                            self.log_status(f"Envoi du message '{custom_text}'...")
                            self.send_text(custom_text)
                            time.sleep(0.2)
                            
                            # 5. Appuyer sur Entrée pour envoyer le message
                            self.log_status("Validation du message par Entrée...")
                            self.send_key(0x0D) # VK_RETURN is 0x0D
                            time.sleep(0.2)
                        else:
                            self.log_status("⚠️ Zone clic chat non configurée, envoi direct sans clic...")
                            self.send_text(custom_text)
                            time.sleep(0.2)
                            self.send_key(0x0D)
                            time.sleep(0.2)
                            
                        # 6. Eteindre le bot et stopper la boucle
                        self.log_status("🚨 [ANTI-MODO] Bot éteint pour sécurité !")
                        return
            
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
            current_time = time.time()
            
            # Détection sélective pour économiser du CPU et accélérer la boucle de vision
            combat_val, combat_loc, combat_shape, combat_name = 0.0, None, None, None
            victoire_val, victoire_loc, victoire_shape, victoire_name = 0.0, None, None, None
            monstre_val, monstre_loc, monstre_shape, monstre_name = 0.0, None, None, None
            combat_val, combat_loc, combat_shape, combat_name = 0.0, None, None, None
            victoire_val, victoire_loc, victoire_shape, victoire_name = 0.0, None, None, None

            if self.bot_state == "MAP":
                # Sur la carte : monstres + bouton combat (pas de victoire, inutile ici)
                _pcx, _pcy = gray_img.shape[1] // 2, gray_img.shape[0] // 2
                # Construire la liste des groupes pris récemment (< 5s) à éviter
                self._failed_clicks = [(x, y, t) for (x, y, t) in self._failed_clicks if current_time - t < 5.0]
                _exclude = [(x, y) for (x, y, t) in self._failed_clicks]
                monstre_val, monstre_loc, monstre_shape, monstre_name = self.detect_template_nearest(gray_img, self.templates_monstres, (_pcx, _pcy), exclude=_exclude)
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
            elif self.bot_state == "COMBAT":
                # En combat : bouton "Terminer" + détection de victoire (pas de monstres)
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                victoire_val, victoire_loc, victoire_shape, victoire_name = self.detect_template(gray_img, self.templates_victoire)
            
            self.after(0, lambda m=f"M:{int(monstre_val*100)}%  C:{int(combat_val*100)}%  V:{int(victoire_val*100)}%": self.lbl_debug.configure(text=m))
            
            try:
                victory_cooldown = float(self.entry_victory_cooldown.get().strip())
            except Exception:
                victory_cooldown = 2.0
                
            # Compteur de confirmation : la victoire doit être vue sur 2 images
            # consécutives ET on doit être réellement en COMBAT. Sinon un simple
            # faux positif d'une image enverrait Échap → ouvrirait le menu en plein combat.
            victory_seen = (victoire_val >= threshold and victoire_loc is not None
                            and self.bot_state == "COMBAT")
            if victory_seen:
                self._victory_confirm_count += 1
            else:
                self._victory_confirm_count = 0

            if self._victory_confirm_count >= 2 and (current_time - self.last_victory_time > victory_cooldown):
                self._victory_confirm_count = 0
                self.bot_state = "MAP"
                self.my_turn = False
                self.combat_launching = False
                self.farm_commands_sent = False
                if victoire_name:
                    self.last_matched_template_path = os.path.join(self.templates_victoire, victoire_name)
                
                h, w = victoire_shape
                
                if self.var_victory_esc.get():
                    self.log_status(f"Victoire Détectée ! (Score: {int(victoire_val*100)}%) - Modèle: {victoire_name or 'Inconnu'}. Fermeture par Echap...")
                    self.focus_target_window()
                    time.sleep(0.04)
                    self.send_key(0x1B)
                else:
                    self.log_status(f"Victoire Détectée ! (Score: {int(victoire_val*100)}%) - Modèle: {victoire_name or 'Inconnu'}. Fermeture par Clic...")
                    rel_x = victoire_loc[0] + w // 2
                    rel_y = victoire_loc[1] + h // 2
                    self.click_on_game(rel_x, rel_y)
                    
                self.last_click_time = 0
                self.combat_launch_time = 0
                self.last_victory_time = current_time
                # Réinitialiser le cooldown monstre : après un combat rapide, on doit
                # pouvoir engager le monstre suivant TOUT DE SUITE (pas d'attente résiduelle).
                self._last_monster_click_time = 0
                # Vider la blacklist des groupes pris (nouveau tour de jeu)
                self._failed_clicks = []

                # Retour carte : délai selon le profil de vitesse (0 en Rapide, plus en Normal/Lent
                # pour laisser le temps à la carte de se charger sur connexion/machine plus lente).
                self.current_victory_delay = self._spd("victory")
                if self.current_victory_delay <= 0:
                    self.log_status("Retour Carte (instantané)")
                else:
                    self.log_status(f"Retour Carte (délai {self.current_victory_delay:.2f}s)")
                
            elif self.bot_state == "MAP":
                if current_time - self.last_victory_time < self.current_victory_delay:
                    pass
                else:
                    active_threshold = max(0.45, threshold - 0.15) if self.combat_launching else threshold
                    if combat_val >= active_threshold and combat_loc is not None:
                        self.bot_state = "COMBAT"
                        self.my_turn = False
                        self.last_combat_time = current_time
                        self.combat_button_seen = False
                        self.combat_click_pos = None
                        self._enu_chest_placed = False
                        self.enu_click_pos = None
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.combat_count += 1
                        if combat_name:
                            self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                        self.log_status(f"Combat Détecté ! (Score: {int(combat_val*100)}%) - Modèle: {combat_name or 'Inconnu'}")
                        self._update_state_badge("COMBAT")

                    else:
                        if self.combat_launching:
                            elapsed = current_time - self.combat_launch_time
                            try:
                                timeout = float(self.entry_launch_timeout.get().strip())
                            except Exception:
                                timeout = 8.0
                            _pending = getattr(self, "_pending_click_pos", None)
                            # Cas 1 : monstres DISPARUS après un court délai → groupe pris (sprite parti)
                            disparu = (elapsed > 0.08 and (monstre_val < threshold or monstre_loc is None))
                            # Cas 2 : combat PAS démarré en 0.02s ET aucun signe du bouton de
                            # combat (combat_val bas) → groupe pris. Si le bouton commence à
                            # apparaître (combat qui se charge), on NE déclenche PAS (ton combat).
                            pas_lance = (elapsed > 0.02 and combat_val < 0.35)
                            if disparu or pas_lance:
                                self.combat_launching = False
                                self.last_click_time = 0
                                # Réinitialiser le cooldown monstre : le groupe est pris,
                                # on doit pouvoir cliquer le SUIVANT tout de suite (réactivité).
                                self._last_monster_click_time = 0
                                # Blacklister cette position pour aller voir AILLEURS
                                if _pending is not None:
                                    self._failed_clicks.append((_pending[0], _pending[1], current_time))
                                if disparu:
                                    self.log_status("Groupe disparu (pris ?), recherche ailleurs...")
                                else:
                                    self.log_status("Combat non lancé (groupe pris ?), recherche ailleurs...")
                                # ⚡ RE-CLIC IMMÉDIAT (même frame) : re-détecter en excluant le
                                # groupe pris et cliquer le suivant SANS attendre une frame.
                                self._failed_clicks = [(x, y, t) for (x, y, t) in self._failed_clicks if current_time - t < 5.0]
                                _excl = [(x, y) for (x, y, t) in self._failed_clicks]
                                _pcx, _pcy = gray_img.shape[1] // 2, gray_img.shape[0] // 2
                                mv, ml, ms, mn = self.detect_template_nearest(gray_img, self.templates_monstres, (_pcx, _pcy), exclude=_excl)
                                if mv >= threshold and ml is not None and ms is not None:
                                    nhh, nww = ms
                                    nx = ml[0] + nww // 2
                                    ny = ml[1] + nhh // 2
                                    # Le mob vient d'être détecté sur CETTE image → on clique
                                    # direct, sans re-vérif (qui bloquerait inutilement).
                                    if mn:
                                        self.last_matched_template_path = os.path.join(self.templates_monstres, mn)
                                    self.log_status(f"⚡ Re-clic direct groupe suivant ({int(mv*100)}%)")
                                    self._pending_click_pos = (nx, ny)
                                    self._last_monster_click_pos = (nx, ny)
                                    self.click_on_game(nx, ny)
                                    self.last_click_time = current_time
                                    self._last_monster_click_time = current_time
                                    self.combat_launching = True
                                    self.combat_launch_time = current_time
                            elif elapsed > timeout:
                                self.combat_launching = False
                                self.log_status("Délai de lancement combat dépassé, nouvel essai...")
                        else:
                            if current_time - self.last_click_time > self.current_map_delay:
                                if monstre_val >= threshold and monstre_loc is not None:
                                    # FIX double-clic : cooldown minimum absolu
                                    try:
                                        _cd = float(self.entry_monster_cooldown.get().strip())
                                    except Exception:
                                        _cd = self.MONSTER_CLICK_MIN_COOLDOWN
                                    h, w = monstre_shape
                                    rel_x = monstre_loc[0] + w // 2
                                    rel_y = monstre_loc[1] + h // 2
                                    # (les groupes pris sont déjà exclus par detect_template_nearest)
                                    # Le cooldown ne s'applique QUE si on re-clique le MÊME
                                    # endroit (anti double-clic). Cliquer un AUTRE groupe est
                                    # toujours autorisé immédiatement → pas de faux cooldown.
                                    _lp = self._last_monster_click_pos
                                    same_spot = (_lp is not None and abs(rel_x - _lp[0]) < 60 and abs(rel_y - _lp[1]) < 60)
                                    if same_spot and (current_time - self._last_monster_click_time < _cd):
                                        self.log_status(f"⏳ Cooldown même case ({current_time - self._last_monster_click_time:.1f}s / {_cd:.1f}s)...")
                                    else:
                                        # Re-vérification ULTIME sur l'image fraîche :
                                        # le groupe est-il encore là MAINTENANT, ou pris entre-temps ?
                                        if not self._monster_still_present(rel_x, rel_y):
                                            self._failed_clicks.append((rel_x, rel_y, current_time))
                                            self._last_monster_click_time = 0
                                            self.log_status("Groupe pris à la dernière seconde, recherche ailleurs...")
                                        else:
                                            if monstre_name:
                                                self.last_matched_template_path = os.path.join(self.templates_monstres, monstre_name)
                                            self.log_status(f"Lancement combat... (Monstre: {int(monstre_val*100)}%) - Modèle: {monstre_name or 'Inconnu'}")
                                            self._pending_click_pos = (rel_x, rel_y)
                                            self._last_monster_click_pos = (rel_x, rel_y)
                                            self.click_on_game(rel_x, rel_y)
                                            self.last_click_time = current_time
                                            self._last_monster_click_time = current_time
                                            self.combat_launching = True
                                            self.combat_launch_time = current_time
                                            try:
                                                base_map_delay = float(self.entry_map_delay.get().strip())
                                            except:
                                                base_map_delay = 3.0
                                            self.current_map_delay = base_map_delay * np.random.uniform(0.85, 1.15)
                                    
            elif self.bot_state == "COMBAT":
                if combat_val >= threshold and combat_loc is not None:
                    self.last_combat_time = current_time
                    self.combat_button_seen = True
                    h, w = combat_shape
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    
                    is_ready_btn = "pret" in combat_name.lower() or "prêt" in combat_name.lower()
                    if is_ready_btn:
                        if not self.my_turn:
                            self.log_status(f"Bouton PRÊT détecté (Score: {int(combat_val*100)}%). Clic automatique...")
                            rel_x = combat_loc[0] + w // 2
                            rel_y = combat_loc[1] + h // 2
                            bg_mode = self.var_background_mode.get()
                            self.focus_target_window()
                            self.click_on_game(rel_x, rel_y, background_mode=bg_mode)
                            try:
                                ready_wait = float(self.slider_ready_delay.get())
                            except Exception:
                                ready_wait = 0.5
                            time.sleep(ready_wait)
                            self.my_turn = False
                    else:
                        if not self.my_turn:
                            self.my_turn = True
                            self.combat_button_seen = True
                            self.log_status(f"Mon Tour ! (Bouton: {int(combat_val*100)}%) - Modèle: {combat_name or 'Inconnu'}")
                            self.execute_combat_turn()
                else:
                    if self.my_turn:
                        self.my_turn = False
                        self.log_status("Attente Tour...")
                        
                    try:
                        _bail = float(self.entry_launch_timeout.get().strip())
                    except Exception:
                        _bail = 8.0
                    if (not self.combat_button_seen) and (current_time - self.last_combat_time > _bail):
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        self.log_status("🔄 Combat volé ou non démarré — retour Carte")
                    elif monstre_val >= threshold and monstre_loc is not None and (current_time - self.last_combat_time > 45.0):
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        if monstre_name:
                            self.last_matched_template_path = os.path.join(self.templates_monstres, monstre_name)
                        self.log_status(f"🔄 Auto-recovery : Retour Carte (Monstre détecté: {monstre_name or 'Inconnu'})")
                    elif current_time - self.last_combat_time > 90.0:
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        self.log_status(f"🔄 Auto-recovery : Timeout combat (90s)")
    
            self.processed_frame = self.latest_captured_frame
        except Exception as e:
            import traceback
            print("ERREUR FATALE bot_logic_loop:", e)
            print(traceback.format_exc())
            
        # Scheduling géré par _bot_thread_func

    def update_video_feed(self):
        if self.is_capturing:
            if hasattr(self, "processed_frame") and self.processed_frame is not None and self.is_bot_active:
                cv_img = self.processed_frame.copy()
            elif hasattr(self, "latest_captured_frame") and self.latest_captured_frame is not None:
                cv_img = self.latest_captured_frame.copy()
            else:
                self.after(20, self.update_video_feed)
                return
                
            self.current_cv_img = cv_img.copy()
            
            if self.tabview.get() == "Combat" and self.combat_zone is not None:
                (x1, y1), (x2, y2) = self.combat_zone
                if self.click_zone_mode == "Ligne":
                    cv2.line(cv_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.circle(cv_img, (x1, y1), 4, (0, 0, 255), -1)
                    cv2.circle(cv_img, (x2, y2), 4, (0, 0, 255), -1)
                    cv2.putText(cv_img, "Ligne de Clic", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
                else:
                    cv2.rectangle(cv_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(cv_img, "Zone de Clic", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
            
            elif self.tabview.get() == "🛡️ Modo":
                if self.modo_crop_x is not None and self.modo_crop_y is not None and self.modo_crop_w is not None and self.modo_crop_h is not None:
                    x1, y1 = self.modo_crop_x, self.modo_crop_y
                    x2, y2 = self.modo_crop_x + self.modo_crop_w, self.modo_crop_y + self.modo_crop_h
                    cv2.rectangle(cv_img, (x1, y1), (x2, y2), (0, 165, 255), 2) # Orange border
                    cv2.putText(cv_img, "Zone Alerte Modo", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 1, cv2.LINE_AA)
                if self.modo_chat_x is not None and self.modo_chat_y is not None:
                    cx, cy = self.modo_chat_x, self.modo_chat_y
                    cv2.circle(cv_img, (cx, cy), 6, (0, 255, 255), -1) # Yellow dot
                    cv2.putText(cv_img, "Clic Chat", (cx + 8, cy + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
            
            elif self.tabview.get() == "🎒 Pods":
                pass
            
            cv_img_rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(cv_img_rgb)
            
            orig_w, orig_h = pil_image.size
            self.update_idletasks()
            max_w = self.canvas.winfo_width()
            max_h = self.canvas.winfo_height()
            if max_w <= 10: max_w = 800
            if max_h <= 10: max_h = 450
            
            self.scale_ratio = min(max_w / max(1, orig_w), max_h / max(1, orig_h))
            new_w, new_h = max(1, int(orig_w * self.scale_ratio)), max(1, int(orig_h * self.scale_ratio))
            self.x_offset = max(0, (max_w - new_w) // 2)
            self.y_offset = max(0, (max_h - new_h) // 2)
            
            resized_pil = pil_image.resize((new_w, new_h), Image.Resampling.NEAREST)
            self.tk_image = ImageTk.PhotoImage(image=resized_pil)
            
            self.canvas.delete("video")
            self.canvas.create_image(self.x_offset, self.y_offset, image=self.tk_image, anchor="nw", tags="video")
            self.canvas.tag_lower("video")
            
            self.after(20, self.update_video_feed)

if __name__ == "__main__":
    app = BotGUI()
    app.mainloop()

