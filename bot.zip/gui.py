import ctypes
# --- Rendre le processus DPI Aware pour éviter les décalages de capture sous Windows ---
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2) # Per-Monitor DPI Aware
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware() # System DPI Aware
    except Exception:
        pass

import sys, os

# --- Sorties "crash-proof" : empeche definitivement un print() de planter le bot ---
# Indispensable si le bot tourne sans console (ex: pythonw.exe), cas ou
# sys.stdout / sys.stderr valent None. Sans ca, le 1er print() leve une exception
# qui tue silencieusement le thread de combat -> "rien ne se passe a mon tour".
def _install_safe_output():
    try:
        if getattr(sys, "frozen", False):
            _base = os.path.dirname(sys.executable)
        else:
            _base = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        _base = os.getcwd()
    try:
        _logf = open(os.path.join(_base, "bot.log"), "a", encoding="utf-8", buffering=1)
    except Exception:
        _logf = None

    class _SafeStream:
        def __init__(self, real, logf):
            self._real, self._logf = real, logf
        def write(self, data):
            try:
                if self._real is not None:
                    self._real.write(data)
            except Exception:
                pass
            try:
                if self._logf is not None:
                    self._logf.write(data)
            except Exception:
                pass
            return len(data) if data else 0
        def flush(self):
            for s in (self._real, self._logf):
                try:
                    if s is not None:
                        s.flush()
                except Exception:
                    pass
        def isatty(self):
            try:
                return bool(self._real) and self._real.isatty()
            except Exception:
                return False

    sys.stdout = _SafeStream(sys.stdout, _logf)
    sys.stderr = _SafeStream(sys.stderr, _logf)

try:
    _install_safe_output()
except Exception:
    pass

import customtkinter as ctk
import tkinter as tk
from PIL import Image, ImageTk
import cv2
import os
import time
import numpy as np
import pyautogui
import pydirectinput
import pygetwindow as gw
import win32gui
import win32api
import win32con
import win32process
import keyboard

from capture import DofusVision
import datetime
import threading
import socket
import json as _json

# --- Structures CTYPES pour le clic et clavier Hardware ---
PUL = ctypes.POINTER(ctypes.c_ulong)
class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort),
                ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong),
                ("wParamL", ctypes.c_ushort),
                ("wParamH", ctypes.c_ushort)]

class Input_I(ctypes.Union):
    _fields_ = [("mi", MouseInput),
                ("ki", KeyBdInput),
                ("hi", HardwareInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]

def hardware_click():
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    
    # 0x0002 = LEFTDOWN
    ii_.mi = MouseInput(0, 0, 0, 0x0002, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
    
    time.sleep(0.015)
    
    # 0x0004 = LEFTUP
    ii_.mi = MouseInput(0, 0, 0, 0x0004, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

# Flags Clavier
KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008

def hardware_key(vk_code):
    extra = ctypes.c_ulong(0)
    scancode = ctypes.windll.user32.MapVirtualKeyW(vk_code, 0)
    
    # Appui (Scancode)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(0, scancode, KEYEVENTF_SCANCODE, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_) # 1 = INPUT_KEYBOARD
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))
    
    time.sleep(0.015)
    
    # Relâchement (Scancode)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(0, scancode, KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def get_vk_code(key_str):
    key_str = key_str.lower().strip()
    if len(key_str) == 1:
        if 'a' <= key_str <= 'z':
            return ord(key_str.upper())
        if '0' <= key_str <= '9':
            return ord(key_str)
    
    if key_str.startswith('f') and len(key_str) > 1:
        try:
            num = int(key_str[1:])
            if 1 <= num <= 12:
                return 0x6F + num # F1 = 0x70, F2 = 0x71, ...
        except ValueError:
            pass
            
    common = {
        'enter': 0x0D,
        'space': 0x20,
        'escape': 0x1B,
        'tab': 0x09,
        'shift': 0x10,
        'ctrl': 0x11,
        'alt': 0x12,
        'capslock': 0x14,
    }
    return common.get(key_str, None)

class ToolTip:
    def __init__(self, widget, text, delay=400):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tip_window = None
        self.id = None
        
        # Liaison récursive sur le widget et tous ses enfants (pour survoler les textes, les cases, etc.)
        self.bind_widget_recursively(self.widget)

    def bind_widget_recursively(self, w):
        try:
            # add="+" permet de ne pas écraser les événements de CustomTkinter
            w.bind("<Enter>", self.start_timer, add="+")
            w.bind("<Leave>", self.hide_tip, add="+")
            w.bind("<ButtonPress>", self.hide_tip, add="+")
        except Exception:
            pass
            
        try:
            for child in w.winfo_children():
                self.bind_widget_recursively(child)
        except Exception:
            pass

    def start_timer(self, event=None):
        self.cancel_timer()
        self.id = self.widget.after(self.delay, self.show_tip)

    def cancel_timer(self):
        if self.id:
            self.widget.after_cancel(self.id)
            self.id = None

    def show_tip(self):
        self.cancel_timer()
        if self.tip_window or not self.text:
            return
        
        x = self.widget.winfo_pointerx() + 12
        y = self.widget.winfo_pointery() + 12
        
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tw.attributes("-topmost", True)
        
        label = tk.Label(tw, text=self.text, justify='left',
                         background="#1E1E2E", fg="#CAD3F5",
                         relief='flat', borderwidth=0,
                         font=("Helvetica", 9),
                         padx=8, pady=6)
        label.pack()
        tw.configure(background="#8AADF4")

    def hide_tip(self, event=None):
        self.cancel_timer()
        
        # Vérifier si la souris a réellement quitté les frontières du widget principal
        if event:
            try:
                pointer_x = self.widget.winfo_pointerx()
                pointer_y = self.widget.winfo_pointery()
                
                widget_x = self.widget.winfo_rootx()
                widget_y = self.widget.winfo_rooty()
                widget_w = self.widget.winfo_width()
                widget_h = self.widget.winfo_height()
                
                # Si le pointeur est toujours dans le rectangle du widget, on ne détruit pas l'info-bulle
                if (widget_x <= pointer_x <= widget_x + widget_w and
                    widget_y <= pointer_y <= widget_y + widget_h):
                    return
            except Exception:
                pass
                
        tw = self.tip_window
        self.tip_window = None
        if tw:
            tw.destroy()

def get_game_rendering_hwnd(parent_hwnd):
    child_hwnds = []
    def enum_cb(hwnd, extra):
        child_hwnds.append(hwnd)
        return True
    try:
        import win32gui
        win32gui.EnumChildWindows(parent_hwnd, enum_cb, None)
    except Exception:
        pass
    if child_hwnds:
        for chwd in child_hwnds:
            try:
                class_name = win32gui.GetClassName(chwd)
                if "unity" in class_name.lower():
                    return chwd
            except Exception:
                pass
        return child_hwnds[0]
    return parent_hwnd

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Palette Retrozia
BG_COLOR      = "#0C0C1E"
SIDEBAR_COLOR = "#10102B"
CARD_COLOR    = "#1A1A3E"
CARD2_COLOR   = "#22224E"
TEXT_COLOR    = "#DDD8FF"
TEXT_DIM      = "#7A709A"
ACCENT_COLOR  = "#8B2FC9"
ACCENT_HOVER  = "#A855F7"
ACCENT_LIGHT  = "#C084FC"
GREEN_COLOR   = "#34D058"
GREEN_HOVER   = "#28A745"
RED_COLOR     = "#EF4444"
RED_HOVER     = "#DC2626"
BORDER_COLOR  = "#2D1B69"


# ══════════════════════════════════════════════════════════════════════
#  SERVEUR WEB MOBILE — Aperçu vidéo + contrôle à distance (4G/WiFi)
# ══════════════════════════════════════════════════════════════════════
import random, base64, struct

MOBILE_HTML = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Retrozia Bot</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{background:#07071A;color:#E0D8FF;font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:flex;flex-direction:column;align-items:center;min-height:100vh;padding:0}
#pin-screen{position:fixed;inset:0;background:#07071A;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:99;padding:30px}
.logo{font-size:28px;font-weight:900;letter-spacing:-1px;margin-bottom:6px}
.logo span{color:#A855F7}
.pin-title{color:#6B6B9A;font-size:13px;margin-bottom:28px}
.pin-dots{display:flex;gap:14px;margin-bottom:28px}
.pin-dot{width:14px;height:14px;border-radius:50%;background:#2D1B69;transition:background .15s}
.pin-dot.filled{background:#8B2FC9}
.pin-pad{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;width:240px}
.pin-btn{background:#1A1A3E;border:1px solid #2D1B69;color:#E0D8FF;font-size:22px;font-weight:500;padding:18px;border-radius:12px;cursor:pointer;transition:background .1s;user-select:none}
.pin-btn:active{background:#2D1B69}
.pin-error{color:#EF4444;font-size:12px;margin-top:10px;height:16px}
#main{display:none;width:100%;max-width:480px;flex-direction:column;align-items:center;padding-bottom:30px}
.header{width:100%;display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#04040F}
.h-logo{font-size:18px;font-weight:900}.h-logo span{color:#A855F7}
.h-badge{padding:4px 10px;border-radius:12px;font-size:11px;font-weight:700}
.badge-inactive{background:#1A1A3A;color:#6B6B9A}
.badge-map{background:#0D2B0D;color:#34D058}
.badge-combat{background:#2B0D0D;color:#EF4444}
.preview-wrap{width:100%;background:#000;position:relative;min-height:180px;display:flex;align-items:center;justify-content:center}
#preview{width:100%;display:block;object-fit:contain}
.preview-off{color:#2D1B69;font-size:12px;padding:40px}
.overlay-scores{position:absolute;bottom:8px;left:8px;display:flex;gap:6px}
.os{padding:3px 8px;border-radius:6px;font-size:11px;font-weight:700;background:rgba(0,0,0,.7)}
.os.m{color:#EF4444}.os.c{color:#A855F7}.os.v{color:#34D058}
.stats-row{width:100%;display:flex;padding:10px 14px;gap:10px;background:#10102B}
.stat{flex:1;text-align:center}
.stat-v{font-size:20px;font-weight:700;color:#E0D8FF}
.stat-l{font-size:10px;color:#6B6B9A;margin-top:1px}
.controls{width:100%;padding:14px;display:flex;flex-direction:column;gap:10px}
.btn{width:100%;padding:18px;border-radius:14px;border:none;font-size:16px;font-weight:800;cursor:pointer;transition:opacity .1s}
.btn:active{opacity:.7}
.btn-start{background:#8B2FC9;color:#fff}
.btn-stop{background:#EF4444;color:#fff}
.btn-dis{background:#1A1A3E;color:#2D1B69;cursor:not-allowed}
.status-txt{font-size:11px;color:#6B6B9A;text-align:center;padding:0 14px;word-break:break-word}
.conn{display:flex;align-items:center;gap:5px;justify-content:center;padding:8px;font-size:11px;color:#6B6B9A}
.dot{width:7px;height:7px;border-radius:50%}
.dot-on{background:#34D058;animation:p 1.5s infinite}
.dot-off{background:#EF4444}
@keyframes p{0%,100%{opacity:1}50%{opacity:.3}}
</style>
</head>
<body>

<!-- Écran PIN -->
<div id="pin-screen">
  <div class="logo">RETRO<span>ZIA</span></div>
  <div class="pin-title">Entrez le code d'accès</div>
  <div class="pin-dots">
    <div class="pin-dot" id="d0"></div>
    <div class="pin-dot" id="d1"></div>
    <div class="pin-dot" id="d2"></div>
    <div class="pin-dot" id="d3"></div>
  </div>
  <div class="pin-pad">
    <button class="pin-btn" onclick="pinPress('1')">1</button>
    <button class="pin-btn" onclick="pinPress('2')">2</button>
    <button class="pin-btn" onclick="pinPress('3')">3</button>
    <button class="pin-btn" onclick="pinPress('4')">4</button>
    <button class="pin-btn" onclick="pinPress('5')">5</button>
    <button class="pin-btn" onclick="pinPress('6')">6</button>
    <button class="pin-btn" onclick="pinPress('7')">7</button>
    <button class="pin-btn" onclick="pinPress('8')">8</button>
    <button class="pin-btn" onclick="pinPress('9')">9</button>
    <button class="pin-btn" onclick="pinPress('del')">⌫</button>
    <button class="pin-btn" onclick="pinPress('0')">0</button>
    <button class="pin-btn" onclick="pinPress('ok')">OK</button>
  </div>
  <div class="pin-error" id="pin-err"></div>
</div>

<!-- Interface principale (cachée jusqu'au PIN) -->
<div id="main">
  <div class="header">
    <div class="h-logo">RETRO<span>ZIA</span></div>
    <div class="h-badge badge-inactive" id="badge">⬛ INACTIF</div>
  </div>

  <!-- Aperçu vidéo -->
  <div class="preview-wrap">
    <img id="preview" src="" alt="" style="display:none">
    <div class="preview-off" id="preview-off">Aperçu non disponible<br>Lance l'aperçu dans le bot</div>
    <div class="overlay-scores">
      <span class="os m" id="sm">M: 0%</span>
      <span class="os c" id="sc">C: 0%</span>
      <span class="os v" id="sv">V: 0%</span>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat"><div class="stat-v" id="combats">0</div><div class="stat-l">Combats</div></div>
    <div class="stat"><div class="stat-v" id="etat">—</div><div class="stat-l">État</div></div>
  </div>

  <!-- Contrôles -->
  <div class="controls">
    <button class="btn btn-start btn-dis" id="btn-s" onclick="action('start')">▶  LANCER LE BOT</button>
    <button class="btn btn-stop btn-dis" id="btn-x" onclick="action('stop')">⏹  ARRÊTER</button>
    <div class="status-txt" id="status-txt">—</div>
  </div>
  <div class="conn"><div class="dot dot-on" id="dot"></div><span id="conn-txt">Connecté</span></div>
</div>

<script>
let PIN = '';
let TOKEN = '';
let active = false;

function pinPress(v){
  if(v==='del'){PIN=PIN.slice(0,-1)}
  else if(v==='ok'){checkPin()}
  else if(PIN.length<4){PIN+=v}
  for(let i=0;i<4;i++) document.getElementById('d'+i).className='pin-dot'+(i<PIN.length?' filled':'');
}
function checkPin(){
  fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:PIN})})
    .then(r=>r.json()).then(d=>{
      if(d.ok){TOKEN=d.token;localStorage.setItem('rztoken',TOKEN);unlock()}
      else{document.getElementById('pin-err').textContent='Code incorrect';PIN='';for(let i=0;i<4;i++)document.getElementById('d'+i).className='pin-dot';}
    }).catch(()=>{document.getElementById('pin-err').textContent='Erreur de connexion';});
}
function unlock(){
  document.getElementById('pin-screen').style.display='none';
  document.getElementById('main').style.display='flex';
  poll(); pollFrame();
}

// Tenter le token sauvegardé
const saved = localStorage.getItem('rztoken');
if(saved){
  TOKEN=saved;
  fetch('/api/status',{headers:{'X-Token':TOKEN}})
    .then(r=>{if(r.status===200)unlock();}).catch(()=>{});
}

function h(){return{'X-Token':TOKEN}}
function action(cmd){
  fetch('/api/'+cmd,{method:'POST',headers:h()}).then(r=>r.json()).then(update).catch(console.error);
}

function update(d){
  active=d.active;
  const states={MAP:'🗺 CARTE',COMBAT:'⚔ COMBAT',INACTIF:'⬛ INACTIF'};
  const cls={MAP:'badge-map',COMBAT:'badge-combat',INACTIF:'badge-inactive'};
  const s=d.state||'INACTIF';
  const badge=document.getElementById('badge');
  badge.textContent=states[s]||s;
  badge.className='h-badge '+(cls[s]||'badge-inactive');
  document.getElementById('combats').textContent=d.combats||0;
  document.getElementById('etat').textContent=s==='INACTIF'?'—':s==='MAP'?'Carte':'Combat';
  document.getElementById('status-txt').textContent=d.status_text||'—';
  document.getElementById('sm').textContent='M: '+(d.score_m||0)+'%';
  document.getElementById('sc').textContent='C: '+(d.score_c||0)+'%';
  document.getElementById('sv').textContent='V: '+(d.score_v||0)+'%';
  document.getElementById('btn-s').className='btn btn-start'+(active?' btn-dis':'');
  document.getElementById('btn-x').className='btn btn-stop'+(active?'':' btn-dis');
  document.getElementById('dot').className='dot dot-on';
  document.getElementById('conn-txt').textContent='Connecté';
}

function poll(){
  fetch('/api/status',{headers:h()})
    .then(r=>{if(r.status===401){localStorage.removeItem('rztoken');location.reload();return null;}return r.json();})
    .then(d=>{if(d)update(d);})
    .catch(()=>{document.getElementById('dot').className='dot dot-off';document.getElementById('conn-txt').textContent='Déconnecté';});
  setTimeout(poll,1500);
}

function pollFrame(){
  const img=document.getElementById('preview');
  const off=document.getElementById('preview-off');
  const url='/api/frame?t='+Date.now()+'&token='+TOKEN;
  const tmp=new Image();
  tmp.onload=()=>{img.src=tmp.src;img.style.display='block';off.style.display='none';};
  tmp.onerror=()=>{img.style.display='none';off.style.display='block';};
  tmp.src=url;
  setTimeout(pollFrame,800);
}
</script>
</body>
</html>"""

def _get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

class BotWebServer:
    """Serveur HTTP — aperçu vidéo + contrôle mobile (WiFi et 4G via ngrok)."""

    def __init__(self, bot_gui, port=5000):
        self.bot = bot_gui
        self.port = port
        self._server = None
        # Générer un PIN aléatoire à 4 chiffres
        self.pin = str(random.randint(1000, 9999))
        self.token = base64.b64encode(random.randbytes(12)).decode()
        self._ngrok_url = None

    def _respond(self, conn, status, ctype, body):
        if isinstance(body, str):
            body = body.encode("utf-8")
        headers = (f"HTTP/1.1 {status}\r\nContent-Type: {ctype}\r\n"
                   f"Content-Length: {len(body)}\r\n"
                   f"Access-Control-Allow-Origin: *\r\n"
                   f"Cache-Control: no-cache\r\nConnection: close\r\n\r\n")
        conn.sendall(headers.encode() + body)

    def _check_token(self, headers_raw):
        for line in headers_raw.split("\r\n"):
            if line.lower().startswith("x-token:"):
                return line.split(":",1)[1].strip() == self.token
        return False

    def _handle(self, conn, addr):
        try:
            data = conn.recv(8192).decode("utf-8", errors="replace")
            if not data:
                return
            lines = data.split("\r\n")
            req = lines[0].split(" ")
            method = req[0] if req else "GET"
            path   = req[1].split("?")[0] if len(req) > 1 else "/"
            query  = req[1].split("?")[1] if len(req) > 1 and "?" in req[1] else ""
            headers_raw = "\r\n".join(lines[1:])

            # Vérifier token (sauf pour / et /api/auth)
            protected = path not in ["/", "/index.html", "/api/auth"]
            # Pour /api/frame le token peut être dans la query string
            if path == "/api/frame":
                token_ok = self._check_token(headers_raw) or f"token={self.token}" in query
            else:
                token_ok = self._check_token(headers_raw)

            if protected and not token_ok:
                self._respond(conn, "401 Unauthorized", "application/json", '{"error":"unauthorized"}')
                return

            # Routes
            if path in ["/", "/index.html"]:
                self._respond(conn, "200 OK", "text/html; charset=utf-8", MOBILE_HTML)

            elif path == "/api/auth" and method == "POST":
                body_start = data.find("\r\n\r\n")
                body = data[body_start+4:] if body_start != -1 else ""
                try:
                    payload = _json.loads(body)
                    if str(payload.get("pin", "")) == self.pin:
                        self._respond(conn, "200 OK", "application/json",
                                      _json.dumps({"ok": True, "token": self.token}))
                    else:
                        self._respond(conn, "200 OK", "application/json", '{"ok":false}')
                except Exception:
                    self._respond(conn, "400 Bad Request", "application/json", '{"ok":false}')

            elif path == "/api/status":
                sm, sc, sv = 0, 0, 0
                try:
                    import re
                    txt = self.bot.lbl_debug.cget("text")
                    nums = re.findall(r"(\d+)%", txt)
                    if len(nums) >= 3:
                        sm, sc, sv = int(nums[0]), int(nums[1]), int(nums[2])
                except Exception:
                    pass
                state = "INACTIF"
                if self.bot.is_bot_active:
                    state = getattr(self.bot, "bot_state", "MAP")
                try:
                    stxt = self.bot.lbl_status.cget("text").replace("Statut : ", "")
                except Exception:
                    stxt = ""
                self._respond(conn, "200 OK", "application/json", _json.dumps({
                    "active": self.bot.is_bot_active,
                    "state": state,
                    "combats": self.bot.combat_count,
                    "status_text": stxt,
                    "score_m": sm, "score_c": sc, "score_v": sv,
                }))

            elif path == "/api/frame":
                frame = getattr(self.bot, "latest_captured_frame", None)
                if frame is not None:
                    try:
                        import cv2 as _cv2
                        # Réduire la résolution pour le mobile (économie bande passante)
                        h, w = frame.shape[:2]
                        scale = min(1.0, 640 / max(w, 1))
                        if scale < 1.0:
                            small = _cv2.resize(frame, (int(w*scale), int(h*scale)))
                        else:
                            small = frame
                        _, buf = _cv2.imencode('.jpg', small,
                                              [_cv2.IMWRITE_JPEG_QUALITY, 55])
                        jpeg = buf.tobytes()
                        headers = (f"HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\n"
                                   f"Content-Length: {len(jpeg)}\r\n"
                                   f"Cache-Control: no-cache\r\n"
                                   f"Access-Control-Allow-Origin: *\r\n"
                                   f"Connection: close\r\n\r\n")
                        conn.sendall(headers.encode() + jpeg)
                    except Exception as e:
                        print(f"[WEB] Frame error: {e}")
                        self._respond(conn, "204 No Content", "image/jpeg", b"")
                else:
                    self._respond(conn, "204 No Content", "image/jpeg", b"")

            elif path == "/api/start" and method == "POST":
                if not self.bot.is_bot_active:
                    self.bot.after(0, self.bot.toggle_bot)
                time.sleep(0.3)
                self._respond(conn, "200 OK", "application/json", '{"ok":true}')

            elif path == "/api/stop" and method == "POST":
                if self.bot.is_bot_active:
                    self.bot.after(0, self.bot.toggle_bot)
                time.sleep(0.3)
                self._respond(conn, "200 OK", "application/json", '{"ok":true}')

            else:
                self._respond(conn, "404 Not Found", "text/plain", "Not found")

        except Exception as e:
            print(f"[WEB] Erreur: {e}")
        finally:
            try: conn.close()
            except Exception: pass

    def start(self):
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind(("0.0.0.0", self.port))
        self._server.listen(20)
        threading.Thread(target=self._loop, daemon=True).start()
        ip = _get_local_ip()
        print(f"[WEB] WiFi : http://{ip}:{self.port}  |  PIN : {self.pin}")
        return ip

    def start_tunnel_4g(self, callback=None):
        """Lance un tunnel SSH via serveo.net — zéro compte, SSH natif Windows 10/11."""
        def _run():
            try:
                import subprocess, re as _re
                # SSH est intégré à Windows 10/11 — aucune installation requise
                proc = subprocess.Popen(
                    ["ssh", "-o", "StrictHostKeyChecking=no",
                     "-o", "ServerAliveInterval=30",
                     "-R", f"80:localhost:{self.port}",
                     "serveo.net"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, creationflags=0x08000000  # CREATE_NO_WINDOW
                )
                self._tunnel_proc = proc
                for line in proc.stdout:
                    m = _re.search(r"https?://[a-zA-Z0-9.-]+\.serveo\.net", line)
                    if m:
                        self._ngrok_url = m.group(0)
                        print(f"[WEB] 4G : {self._ngrok_url}  PIN : {self.pin}")
                        if callback:
                            callback(self._ngrok_url)
                        break
            except FileNotFoundError:
                print("[WEB] SSH non trouvé — Windows 7/8 non supporté")
                if callback:
                    callback(None)
            except Exception as e:
                print(f"[WEB] Tunnel error: {e}")
                if callback:
                    callback(None)
        threading.Thread(target=_run, daemon=True).start()

    def stop_tunnel(self):
        try:
            proc = getattr(self, '_tunnel_proc', None)
            if proc:
                proc.terminate()
        except Exception:
            pass

    def _loop(self):
        while True:
            try:
                conn, addr = self._server.accept()
                threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()
            except Exception:
                break

    def stop(self):
        self.stop_tunnel()
        try: self._server.close()
        except Exception: pass


class BotGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Retrozia Bot")
        self.geometry("1150x760")
        
        self.vision = DofusVision()
        self.is_capturing = False
        self.is_bot_active = False
        self.last_click_time = 0
        self.last_combat_button_loc = None
        self.last_victory_button_loc = None
        
        self.bot_state = "MAP" # MAP, COMBAT, VICTORY
        self.my_turn = False
        self.combat_zone = None
        self.is_defining_zone = False
        self.click_zone_mode = "Ligne"
        self.victory_time = 0
        self.last_victory_time = 0
        self.current_victory_delay = 3.0
        self.current_map_delay = 3.0
        self.last_combat_time = 0
        self.combat_launching = False
        self.combat_launch_time = 0
        self.combat_button_seen = False
        self._last_monster_click_time = 0
        self.MONSTER_CLICK_MIN_COOLDOWN = 3.0
        self._bot_thread = None
        self._bot_stop_event = __import__('threading').Event()
        self.combat_count = 0
        
        # Configuration des dossiers de templates
        import sys
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
        self.config_file = os.path.join(base_dir, "config.json")
        self.templates_dir = os.path.join(base_dir, "templates")
        self.templates_monstres = os.path.join(self.templates_dir, "monstres")
        self.templates_combat = os.path.join(self.templates_dir, "combat")
        self.templates_victoire = os.path.join(self.templates_dir, "victoire")
        self.templates_modo = os.path.join(self.templates_dir, "modo")
        self.templates_menu = os.path.join(self.templates_dir, "menu")
        
        os.makedirs(self.templates_monstres, exist_ok=True)
        os.makedirs(self.templates_combat, exist_ok=True)
        os.makedirs(self.templates_victoire, exist_ok=True)
        os.makedirs(self.templates_modo, exist_ok=True)
        os.makedirs(self.templates_menu, exist_ok=True)
        
        # Cache mémoire pour éviter les lectures disque de templates à chaque frame
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: []
        }
        
        self.is_defining_modo_chat = False
        self.modo_chat_x = None
        self.modo_chat_y = None
        self.modo_crop_x = None
        self.modo_crop_y = None
        self.modo_crop_w = None
        self.modo_crop_h = None
        
        self.templates_pods = os.path.join(self.templates_dir, "pods")
        os.makedirs(self.templates_pods, exist_ok=True)
        self.templates_pods_bank = os.path.join(self.templates_dir, "pods_bank")
        os.makedirs(self.templates_pods_bank, exist_ok=True)
        self.templates_pods_transfers = os.path.join(self.templates_dir, "pods_transfers")
        os.makedirs(self.templates_pods_transfers, exist_ok=True)
        self.templates_pods_transfer_all = os.path.join(self.templates_dir, "pods_transfer_all")
        os.makedirs(self.templates_pods_transfer_all, exist_ok=True)
        
        # Cache mémoire pour éviter les lectures disque de templates à chaque frame
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: [],
            self.templates_pods: [],
            self.templates_pods_bank: [],
            self.templates_pods_transfers: [],
            self.templates_pods_transfer_all: []
        }
        self.var_pods_capture_type = tk.StringVar(value="Alerte")
        self.farm_commands_sent = False
        
        self.is_defining_pods_bank = False
        self.is_defining_pods_transfers = False
        self.is_defining_pods_transfer_all = False
        
        self.pods_bank_x = None
        self.pods_bank_y = None
        self.pods_transfers_x = None
        self.pods_transfers_y = None
        self.pods_transfer_all_x = None
        self.pods_transfer_all_y = None
        
        self.ctk_image = None
        self.current_cv_img = None
        self.scale_ratio = 1.0
        self.x_offset = 0
        self.y_offset = 0
        
                # ══════════════════════════════════════
        # SIDEBAR RETROZIA
        # ══════════════════════════════════════
        self.sidebar_frame = ctk.CTkFrame(self, width=345, corner_radius=0, fg_color=SIDEBAR_COLOR)
        self.sidebar_frame.pack(side="left", fill="y")
        self.sidebar_frame.pack_propagate(False)

        # ── HEADER ────────────────────────────────────
        header_bg = ctk.CTkFrame(self.sidebar_frame, fg_color="#08081A", corner_radius=0, height=70)
        header_bg.pack(fill="x")
        header_bg.pack_propagate(False)

        # Logo RETRO (blanc) + ZIA (violet)
        lf = ctk.CTkFrame(header_bg, fg_color="transparent")
        lf.place(x=12, y=10)
        ctk.CTkLabel(lf, text="RETRO", font=ctk.CTkFont(family="Arial Black", size=20, weight="bold"),
            text_color="#FFFFFF").pack(side="left")
        ctk.CTkLabel(lf, text="ZIA", font=ctk.CTkFont(family="Arial Black", size=20, weight="bold"),
            text_color=ACCENT_HOVER).pack(side="left")
        self.logo_label = ctk.CTkLabel(lf, text="", text_color=TEXT_COLOR)  # compatibilité
        ctk.CTkLabel(header_bg, text="Bot de combat automatique • Dofus 2.64",
            font=ctk.CTkFont(size=9), text_color=TEXT_DIM).place(x=14, y=44)

        # Boutons action (droite du header)
        self.btn_capture = ctk.CTkButton(header_bg, text="👁 Aperçu", command=self.toggle_capture,
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
            font=ctk.CTkFont(weight="bold", size=11), width=88, height=26, corner_radius=5)
        self.btn_capture.place(x=170, y=10)
        self.btn_open_folder = ctk.CTkButton(header_bg, text="📂", command=self.open_templates_folder,
            fg_color=CARD_COLOR, hover_color=CARD2_COLOR, text_color=TEXT_COLOR,
            width=26, height=26, corner_radius=5)
        self.btn_open_folder.place(x=264, y=10)
        self.btn_show_last_match = ctk.CTkButton(header_bg, text="🔍", command=self.open_last_match,
            fg_color=CARD_COLOR, hover_color=CARD2_COLOR, text_color=TEXT_COLOR,
            width=26, height=26, corner_radius=5)
        self.btn_show_last_match.place(x=296, y=10)

        # Ligne violette sous le header
        ctk.CTkFrame(self.sidebar_frame, height=2, fg_color=ACCENT_COLOR).pack(fill="x")

        # ── SCROLLABLE SETTINGS ───────────────────────
        self.scroll_frame = ctk.CTkScrollableFrame(self.sidebar_frame, fg_color="transparent",
            corner_radius=0, scrollbar_button_color=ACCENT_COLOR,
            scrollbar_button_hover_color=ACCENT_HOVER)
        self.scroll_frame.pack(fill="both", expand=True)

        def _mk_card(parent, title):
            """Crée une carte avec bandeau titre."""
            c = ctk.CTkFrame(parent, fg_color=CARD_COLOR, corner_radius=10,
                border_width=1, border_color=BORDER_COLOR)
            c.pack(pady=(8, 0), padx=10, fill="x")
            band = ctk.CTkFrame(c, fg_color=CARD2_COLOR, corner_radius=8, height=26)
            band.pack(fill="x", padx=1, pady=(1, 0))
            band.pack_propagate(False)
            ctk.CTkLabel(band, text=title, font=ctk.CTkFont(weight="bold", size=11),
                text_color=ACCENT_LIGHT).pack(side="left", padx=10, pady=4)
            return c

        def _mk_row(parent, label_text, pady=3):
            """Ligne label + widget à droite."""
            f = ctk.CTkFrame(parent, fg_color="transparent")
            f.pack(fill="x", padx=10, pady=pady)
            ctk.CTkLabel(f, text=label_text, font=ctk.CTkFont(size=11),
                text_color=TEXT_COLOR, anchor="w").pack(side="left")
            return f

        def _mk_entry(parent, default, width=48):
            e = ctk.CTkEntry(parent, width=width, height=22, font=ctk.CTkFont(size=11),
                justify="center", fg_color=CARD2_COLOR,
                border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
            e.insert(0, default)
            e.pack(side="right")
            return e

        def _mk_checkbox(parent, text, var, pady=4, padx=10):
            cb = ctk.CTkCheckBox(parent, text=text, variable=var,
                font=ctk.CTkFont(size=11), text_color=TEXT_COLOR,
                fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
                checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
            cb.pack(pady=pady, padx=padx, anchor="w")
            return cb

        def _mk_slider(parent, from_, to, default, command, pady=(2,6)):
            s = ctk.CTkSlider(parent, from_=from_, to=to, command=command,
                height=14, button_color=ACCENT_HOVER, button_hover_color=ACCENT_LIGHT,
                progress_color=ACCENT_COLOR, fg_color=CARD2_COLOR)
            s.set(default)
            s.pack(padx=10, pady=pady, fill="x")
            return s

        # ── CARTE FENÊTRE & CAPTURE ───────────────────
        self.win_card = _mk_card(self.scroll_frame, "🖥  FENÊTRE & CAPTURE")

        row_win = ctk.CTkFrame(self.win_card, fg_color="transparent")
        row_win.pack(fill="x", padx=10, pady=(6, 2))
        self.window_label = ctk.CTkLabel(row_win, text="Fenêtre :", font=ctk.CTkFont(size=11),
            text_color=TEXT_DIM, width=58, anchor="w")
        self.window_label.pack(side="left")
        self.window_selector = ctk.CTkOptionMenu(row_win, values=["Écran Complet"],
            command=self.on_window_selected,
            fg_color=CARD2_COLOR, button_color=ACCENT_COLOR, button_hover_color=ACCENT_HOVER,
            text_color=TEXT_COLOR, dropdown_fg_color=CARD_COLOR, dropdown_text_color=TEXT_COLOR,
            dropdown_hover_color=ACCENT_COLOR, height=24)
        self.window_selector.pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.btn_refresh = ctk.CTkButton(row_win, text="🔄", command=self.refresh_window_list,
            fg_color="transparent", border_width=1, border_color=ACCENT_COLOR,
            text_color=ACCENT_COLOR, width=26, height=24, corner_radius=5)
        self.btn_refresh.pack(side="left", padx=(4, 0))

        self.opts_card = ctk.CTkFrame(self.win_card, fg_color="transparent")
        self.opts_card.pack(fill="x", padx=0, pady=0)
        self.opts_header = ctk.CTkLabel(self.opts_card, text="")  # dummy ref

        row_chk = ctk.CTkFrame(self.win_card, fg_color="transparent")
        row_chk.pack(fill="x", padx=10, pady=(4, 2))
        self.var_background_mode = tk.BooleanVar(value=False)
        self.chk_background_mode = ctk.CTkCheckBox(row_chk, text="Fantôme",
            variable=self.var_background_mode, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_background_mode.pack(side="left", padx=(0, 8))

        self.var_hidden_capture = tk.BooleanVar(value=False)
        self.hidden_capture_active = False
        def update_hidden_capture(*args):
            self.hidden_capture_active = self.var_hidden_capture.get()
        self.var_hidden_capture.trace_add("write", update_hidden_capture)
        self.chk_hidden_capture = ctk.CTkCheckBox(row_chk, text="Masquée",
            variable=self.var_hidden_capture, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_hidden_capture.pack(side="left", padx=(0, 8))

        self.var_dpi_scaling = tk.BooleanVar(value=False)
        self.chk_dpi_scaling = ctk.CTkCheckBox(row_chk, text="Fix DPI",
            variable=self.var_dpi_scaling, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_dpi_scaling.pack(side="left")

        # Précision IA
        self.sens_frame = ctk.CTkFrame(self.win_card, fg_color="transparent")
        self.sens_frame.pack(fill="x", padx=10, pady=(4, 2))
        self.sens_label = ctk.CTkLabel(self.sens_frame, text="🎯 Précision IA :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.sens_label.pack(side="left")
        self.sens_pct = ctk.CTkLabel(self.sens_frame, text="%",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.sens_pct.pack(side="right", padx=(0, 2))
        self.sens_entry = ctk.CTkEntry(self.sens_frame, width=38, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.sens_entry.insert(0, "60")
        self.sens_entry.pack(side="right")
        self.sens_entry.bind("<Return>", self._on_sens_entry)
        self.sens_entry.bind("<FocusOut>", self._on_sens_entry)
        self.sens_entry.bind("<KeyRelease>", self._on_sens_keyrelease)
        self.slider = _mk_slider(self.win_card, 0.3, 0.95, 0.60, self.update_sens, pady=(0, 8))

        # ── BOUTON ACCÈS MOBILE (visible et accessible) ───────────────────
        self.btn_mobile = ctk.CTkButton(self.scroll_frame,
            text="📱  Surveillance Mobile",
            command=self._show_mobile_popup,
            height=38, corner_radius=8,
            fg_color="#2D1B69", hover_color=ACCENT_COLOR,
            text_color=ACCENT_LIGHT,
            font=ctk.CTkFont(size=12, weight="bold"),
            border_width=1, border_color=ACCENT_COLOR)
        self.btn_mobile.pack(pady=(8, 0), padx=10, fill="x")

        # ── TABVIEW ────────────────────────────────────
        self.tabview = ctk.CTkTabview(self.scroll_frame, fg_color=CARD_COLOR,
            segmented_button_selected_color=ACCENT_COLOR,
            segmented_button_selected_hover_color=ACCENT_HOVER,
            segmented_button_unselected_color=CARD2_COLOR,
            segmented_button_unselected_hover_color="#1E1E50",
            text_color=TEXT_COLOR, text_color_disabled=TEXT_DIM,
            border_width=1, border_color=BORDER_COLOR)
        self.tabview._segmented_button.configure(font=ctk.CTkFont(size=10, weight="bold"))
        self.tabview.pack(pady=8, padx=10, fill="both", expand=True)

        self.tabview.add("🗺️ Carte")
        self.tabview.add("⚔️ Combat")
        self.tabview.add("🏆 Victoire")
        self.tabview.add("🛡️ Modo")
        self.tabview.add("🎒 Pods")

        # ─── TAB CARTE ────────────────────────────────
        tab_carte = self.tabview.tab("🗺️ Carte")
        ctk.CTkLabel(tab_carte, text="Clic droit sur la vidéo pour capturer un monstre.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8, 4))

        self.map_delay_frame = _mk_row(tab_carte, "Délai carte (s) :")
        self.lbl_map_delay = self.map_delay_frame.winfo_children()[0]
        self.entry_map_delay = _mk_entry(self.map_delay_frame, "3.0")
        self.entry_map_delay.bind("<Return>", self._on_map_delay_entry)
        self.entry_map_delay.bind("<FocusOut>", self._on_map_delay_entry)

        self.launch_timeout_frame = _mk_row(tab_carte, "Attente lancement (s) :")
        self.lbl_launch_timeout = self.launch_timeout_frame.winfo_children()[0]
        self.entry_launch_timeout = _mk_entry(self.launch_timeout_frame, "8.0")
        self.entry_launch_timeout.bind("<Return>", self._on_launch_timeout_entry)
        self.entry_launch_timeout.bind("<FocusOut>", self._on_launch_timeout_entry)

        self.cooldown_frame = _mk_row(tab_carte, "⏱ Cooldown monstre (s) :")
        self.entry_monster_cooldown = _mk_entry(self.cooldown_frame, "3.0")
        self.entry_monster_cooldown.bind("<FocusOut>", lambda e: self.save_config())

        self.var_close_menu = tk.BooleanVar(value=True)
        self.chk_close_menu = _mk_checkbox(tab_carte, "❌ Fermer Menu Principal", self.var_close_menu)

        self.var_carte_capture_type = tk.StringVar(value="Monstres")
        self.carte_capture_selector = ctk.CTkSegmentedButton(tab_carte,
            values=["Monstres", "Menu Principal"], variable=self.var_carte_capture_type,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, unselected_hover_color="#1E1E50",
            text_color=TEXT_COLOR, height=24)
        self.carte_capture_selector.pack(pady=4, padx=10, fill="x")

        self.clear_buttons_frame = ctk.CTkFrame(tab_carte, fg_color="transparent")
        self.clear_buttons_frame.pack(pady=4, padx=10, fill="x")
        self.btn_clear = ctk.CTkButton(self.clear_buttons_frame, text="🗑 Monstres",
            command=self.clear_monstres, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(size=11, weight="bold"), height=26, corner_radius=6)
        self.btn_clear.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_clear_menu = ctk.CTkButton(self.clear_buttons_frame, text="🗑 Menu",
            command=self.clear_menu, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(size=11, weight="bold"), height=26, corner_radius=6)
        self.btn_clear_menu.pack(side="right", fill="x", expand=True)

        # ─── TAB COMBAT ───────────────────────────────
        tab_combat = self.tabview.tab("⚔️ Combat")
        self.btn_define_zone = ctk.CTkButton(tab_combat,
            text="🎯  Dessiner Zone de Clic  (Clic Droit)",
            command=self.toggle_define_zone, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold", size=11), height=30, corner_radius=6)
        self.btn_define_zone.pack(pady=(8, 4), padx=10, fill="x")

        self.zone_mode_var = tk.StringVar(value="Ligne")
        self.zone_mode_selector = ctk.CTkSegmentedButton(tab_combat,
            values=["Ligne", "Rectangle"], variable=self.zone_mode_var,
            command=self.on_zone_mode_changed,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=24)
        self.zone_mode_selector.pack(pady=2, padx=10, fill="x")

        self.zone_coords_frame = ctk.CTkFrame(tab_combat, fg_color="transparent")
        self.zone_coords_frame.pack(pady=2, padx=10, fill="x")
        _eopt = dict(width=34, height=20, font=ctk.CTkFont(size=10),
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_zone_x = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_x.grid(row=0, column=0, padx=2, pady=1)
        self.entry_zone_y = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_y.grid(row=0, column=1, padx=2, pady=1)
        self.entry_zone_w = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_w.grid(row=1, column=0, padx=2, pady=1)
        self.entry_zone_h = ctk.CTkEntry(self.zone_coords_frame, **_eopt)
        self.entry_zone_h.grid(row=1, column=1, padx=2, pady=1)
        self.btn_apply_zone = ctk.CTkButton(self.zone_coords_frame, text="✅",
            width=30, height=42, font=ctk.CTkFont(size=14), command=self.apply_manual_zone,
            fg_color=GREEN_COLOR, hover_color=GREEN_HOVER, text_color="#0B1A10", corner_radius=6)
        self.btn_apply_zone.grid(row=0, column=2, rowspan=2, padx=4, pady=1)

        gf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        gf.pack(pady=4, padx=10, fill="x")
        self.grid_frame = gf

        ctk.CTkLabel(gf, text="Touche Sort :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11)).grid(row=0, column=0, padx=(10,4), pady=4, sticky="w")
        self.entry_spell_key = ctk.CTkEntry(gf, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_spell_key.insert(0, "1")
        self.entry_spell_key.grid(row=0, column=1, padx=4, pady=4)

        ctk.CTkLabel(gf, text="Nb Lancers :", text_color=TEXT_COLOR,
            font=ctk.CTkFont(size=11)).grid(row=1, column=0, padx=(10,4), pady=4, sticky="w")
        self.entry_chain_count = ctk.CTkEntry(gf, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_chain_count.insert(0, "2")
        self.entry_chain_count.grid(row=1, column=1, padx=4, pady=4)
        self.entry_chain_count.bind("<Return>", self._on_chain_count_entry)
        self.entry_chain_count.bind("<FocusOut>", self._on_chain_count_entry)

        self.delay_frame = ctk.CTkFrame(gf, fg_color="transparent")
        self.delay_frame.grid(row=2, column=0, columnspan=2, padx=4, pady=(4,0), sticky="ew")
        self.lbl_delay = ctk.CTkLabel(self.delay_frame, text="Délai (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_delay.pack(side="left", padx=4)
        self.entry_delay = ctk.CTkEntry(self.delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_delay.insert(0, "0.08")
        self.entry_delay.pack(side="right", padx=4)
        self.entry_delay.bind("<Return>", self._on_delay_entry)
        self.entry_delay.bind("<FocusOut>", self._on_delay_entry)
        self.entry_delay.bind("<KeyRelease>", self._on_delay_keyrelease)
        self.slider_delay = ctk.CTkSlider(gf, from_=0.01, to=1.0, number_of_steps=99,
            command=self.update_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_delay.set(0.08)
        self.slider_delay.grid(row=3, column=0, columnspan=2, padx=10, pady=(2,8), sticky="ew")

        pf = ctk.CTkFrame(tab_combat, fg_color=CARD2_COLOR, corner_radius=8,
            border_width=1, border_color=BORDER_COLOR)
        pf.pack(pady=4, padx=10, fill="x")
        self.pass_frame = pf
        self.var_pass_turn = tk.BooleanVar(value=True)
        self.chk_pass_turn = ctk.CTkCheckBox(pf, text="Passer le Tour :",
            variable=self.var_pass_turn, font=ctk.CTkFont(size=11),
            text_color=TEXT_COLOR, fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            checkmark_color="#FFFFFF", checkbox_width=16, checkbox_height=16)
        self.chk_pass_turn.grid(row=0, column=0, padx=(10,4), pady=6, sticky="w")
        self.entry_pass_key = ctk.CTkEntry(pf, width=50, height=22,
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR,
            justify="center", text_color=TEXT_COLOR)
        self.entry_pass_key.insert(0, "f1")
        self.entry_pass_key.grid(row=0, column=1, padx=4, pady=6)

        self.start_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.start_delay_frame.grid(row=1, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_start_delay = ctk.CTkLabel(self.start_delay_frame, text="Attente début (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_start_delay.pack(side="left", padx=4)
        self.entry_start_delay = ctk.CTkEntry(self.start_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_start_delay.insert(0, "0.30")
        self.entry_start_delay.pack(side="right", padx=4)
        self.entry_start_delay.bind("<Return>", self._on_start_delay_entry)
        self.entry_start_delay.bind("<FocusOut>", self._on_start_delay_entry)
        self.entry_start_delay.bind("<KeyRelease>", self._on_start_delay_keyrelease)
        self.slider_start_delay = ctk.CTkSlider(pf, from_=0.01, to=2.0, number_of_steps=199,
            command=self.update_start_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_start_delay.set(0.30)
        self.slider_start_delay.grid(row=2, column=0, columnspan=2, padx=10, pady=(0,4), sticky="ew")

        self.end_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.end_delay_frame.grid(row=3, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_end_delay = ctk.CTkLabel(self.end_delay_frame, text="Délai fin tour (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_end_delay.pack(side="left", padx=4)
        self.entry_end_delay = ctk.CTkEntry(self.end_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_end_delay.insert(0, "0.15")
        self.entry_end_delay.pack(side="right", padx=4)
        self.entry_end_delay.bind("<Return>", self._on_end_delay_entry)
        self.entry_end_delay.bind("<FocusOut>", self._on_end_delay_entry)
        self.entry_end_delay.bind("<KeyRelease>", self._on_end_delay_keyrelease)
        self.slider_end_delay = ctk.CTkSlider(pf, from_=0.01, to=2.0, number_of_steps=199,
            command=self.update_end_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_end_delay.set(0.15)
        self.slider_end_delay.grid(row=4, column=0, columnspan=2, padx=10, pady=(0,8), sticky="ew")

        self.ready_delay_frame = ctk.CTkFrame(pf, fg_color="transparent")
        self.ready_delay_frame.grid(row=5, column=0, columnspan=2, padx=4, pady=2, sticky="ew")
        self.lbl_ready_delay = ctk.CTkLabel(self.ready_delay_frame, text="Attente après Prêt (s) :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_ready_delay.pack(side="left", padx=4)
        self.entry_ready_delay = ctk.CTkEntry(self.ready_delay_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_ready_delay.insert(0, "0.50")
        self.entry_ready_delay.pack(side="right", padx=4)
        self.entry_ready_delay.bind("<Return>", self._on_ready_delay_entry)
        self.entry_ready_delay.bind("<FocusOut>", self._on_ready_delay_entry)
        self.entry_ready_delay.bind("<KeyRelease>", self._on_ready_delay_keyrelease)
        self.slider_ready_delay = ctk.CTkSlider(pf, from_=0.01, to=2.0, number_of_steps=199,
            command=self.update_ready_delay_lbl, height=14,
            button_color=ACCENT_HOVER, progress_color=ACCENT_COLOR, fg_color=CARD_COLOR)
        self.slider_ready_delay.set(0.50)
        self.slider_ready_delay.grid(row=6, column=0, columnspan=2, padx=10, pady=(0,8), sticky="ew")

        self.btn_clear_combat = ctk.CTkButton(tab_combat, text="🗑  Effacer modèles 'Prêt'",
            command=self.clear_combat, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_combat.pack(pady=6, padx=10, fill="x")

        # ─── TAB VICTOIRE ─────────────────────────────
        tab_victoire = self.tabview.tab("🏆 Victoire")
        ctk.CTkLabel(tab_victoire, text="Clic droit pour capturer le bouton 'Fermer'.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8,4))
        self.var_victory_esc = tk.BooleanVar(value=True)
        self.chk_victory_esc = _mk_checkbox(tab_victoire, "⌨️ Fermer par touche Echap", self.var_victory_esc)

        self.victory_delay_frame = ctk.CTkFrame(tab_victoire, fg_color="transparent")
        self.victory_delay_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_victory_title = ctk.CTkLabel(self.victory_delay_frame,
            text="Retour carte (s)  Min", font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_victory_title.pack(side="left")
        _e = dict(width=34, height=22, font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_victory_delay_min = ctk.CTkEntry(self.victory_delay_frame, **_e)
        self.entry_victory_delay_min.insert(0, "2.0")
        self.entry_victory_delay_min.pack(side="left", padx=2)
        self.entry_victory_delay_min.bind("<Return>", self._on_victory_delay_min_entry)
        self.entry_victory_delay_min.bind("<FocusOut>", self._on_victory_delay_min_entry)
        self.lbl_to = ctk.CTkLabel(self.victory_delay_frame, text="Max",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_to.pack(side="left", padx=(6,2))
        self.entry_victory_delay_max = ctk.CTkEntry(self.victory_delay_frame, **_e)
        self.entry_victory_delay_max.insert(0, "4.0")
        self.entry_victory_delay_max.pack(side="left", padx=2)
        self.entry_victory_delay_max.bind("<Return>", self._on_victory_delay_max_entry)
        self.entry_victory_delay_max.bind("<FocusOut>", self._on_victory_delay_max_entry)

        self.victory_cooldown_frame = ctk.CTkFrame(tab_victoire, fg_color="transparent")
        self.victory_cooldown_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_victory_cooldown = ctk.CTkLabel(self.victory_cooldown_frame,
            text="Cooldown (s) :", font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_victory_cooldown.pack(side="left")
        self.entry_victory_cooldown = ctk.CTkEntry(self.victory_cooldown_frame, **_e)
        self.entry_victory_cooldown.insert(0, "2.0")
        self.entry_victory_cooldown.pack(side="right")
        self.entry_victory_cooldown.bind("<Return>", self._on_victory_cooldown_entry)
        self.entry_victory_cooldown.bind("<FocusOut>", self._on_victory_cooldown_entry)

        self.btn_clear_victoire = ctk.CTkButton(tab_victoire, text="🗑  Effacer modèles Victoire",
            command=self.clear_victoire, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_victoire.pack(pady=6, padx=10, fill="x")

        # ─── TAB MODO ─────────────────────────────────
        tab_modo = self.tabview.tab("🛡️ Modo")
        self.modo_inner_frame = ctk.CTkFrame(tab_modo, fg_color="transparent")
        self.modo_inner_frame.pack(fill="both", expand=True)
        self.var_modo_enabled = tk.BooleanVar(value=False)
        self.chk_modo_enabled = _mk_checkbox(self.modo_inner_frame, "🛡️ Activer Anti-Modo", self.var_modo_enabled, pady=8)

        self.modo_mode_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.modo_mode_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_modo_mode = ctk.CTkLabel(self.modo_mode_frame, text="Mode :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_modo_mode.pack(side="left", padx=4)
        self.var_modo_trigger_mode = tk.StringVar(value="Présence")
        self.modo_mode_selector = ctk.CTkSegmentedButton(self.modo_mode_frame,
            values=["Présence","Changement"], variable=self.var_modo_trigger_mode,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=22)
        self.modo_mode_selector.pack(side="right", fill="x", expand=True, padx=4)

        self.modo_text_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.modo_text_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_modo_text = ctk.CTkLabel(self.modo_text_frame, text="Message :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_modo_text.pack(side="left", padx=4)
        self.entry_modo_text = ctk.CTkEntry(self.modo_text_frame, height=22,
            font=ctk.CTkFont(size=11), fg_color=CARD2_COLOR,
            border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_modo_text.insert(0, "oui ?")
        self.entry_modo_text.pack(side="right", fill="x", expand=True, padx=4)
        self.entry_modo_text.bind("<Return>", lambda e: self.save_config())
        self.entry_modo_text.bind("<FocusOut>", lambda e: self.save_config())

        self.sens_modo_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.sens_modo_frame.pack(pady=3, padx=10, fill="x")
        self.lbl_sens_modo_title = ctk.CTkLabel(self.sens_modo_frame, text="Précision :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_sens_modo_title.pack(side="left", padx=4)
        self.entry_modo_sens = ctk.CTkEntry(self.sens_modo_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_modo_sens.insert(0, "80")
        self.entry_modo_sens.pack(side="right", padx=4)
        self.entry_modo_sens.bind("<Return>", self._on_modo_sens_entry)
        self.entry_modo_sens.bind("<FocusOut>", self._on_modo_sens_entry)
        self.entry_modo_sens.bind("<KeyRelease>", self._on_modo_sens_keyrelease)
        self.slider_modo = _mk_slider(self.modo_inner_frame, 0.3, 0.95, 0.80, self.update_modo_sens)

        self.chat_pos_frame = ctk.CTkFrame(self.modo_inner_frame, fg_color="transparent")
        self.chat_pos_frame.pack(pady=3, padx=10, fill="x")
        self.btn_define_modo_chat = ctk.CTkButton(self.chat_pos_frame,
            text="💬 Définir Clic Chat", command=self.toggle_define_modo_chat,
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
            font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_define_modo_chat.pack(fill="x")
        self.lbl_modo_chat_coords = ctk.CTkLabel(self.modo_inner_frame,
            text="Clic Chat : Aucun", font=ctk.CTkFont(size=11), text_color=TEXT_DIM)
        self.lbl_modo_chat_coords.pack(pady=2, padx=10)
        self.btn_clear_modo = ctk.CTkButton(self.modo_inner_frame, text="🗑️ Effacer Modèles Modo",
            command=self.clear_modo, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_modo.pack(pady=6, padx=10, fill="x")

        # ─── TAB PODS ─────────────────────────────────
        tab_pods = self.tabview.tab("🎒 Pods")
        self.pods_inner_frame = ctk.CTkFrame(tab_pods, fg_color="transparent")
        self.pods_inner_frame.pack(fill="both", expand=True)
        ctk.CTkLabel(self.pods_inner_frame, text="Clic droit pour capturer l'alerte Pods pleins.",
            text_color=TEXT_DIM, font=ctk.CTkFont(size=11)).pack(pady=(8,4))
        self.var_pods_enabled = tk.BooleanVar(value=False)
        self.chk_pods_enabled = _mk_checkbox(self.pods_inner_frame, "🎒 Activer Vidage Banque", self.var_pods_enabled, pady=6)

        self.sens_pods_frame = ctk.CTkFrame(self.pods_inner_frame, fg_color="transparent")
        self.sens_pods_frame.pack(pady=2, padx=10, fill="x")
        self.lbl_sens_pods_title = ctk.CTkLabel(self.sens_pods_frame, text="Précision :",
            font=ctk.CTkFont(size=11), text_color=TEXT_COLOR)
        self.lbl_sens_pods_title.pack(side="left", padx=4)
        self.entry_pods_sens = ctk.CTkEntry(self.sens_pods_frame, width=44, height=22,
            font=ctk.CTkFont(size=11), justify="center",
            fg_color=CARD2_COLOR, border_width=1, border_color=BORDER_COLOR, text_color=TEXT_COLOR)
        self.entry_pods_sens.insert(0, "80")
        self.entry_pods_sens.pack(side="right", padx=4)
        self.entry_pods_sens.bind("<Return>", self._on_pods_sens_entry)
        self.entry_pods_sens.bind("<FocusOut>", self._on_pods_sens_entry)
        self.entry_pods_sens.bind("<KeyRelease>", self._on_pods_sens_keyrelease)
        self.slider_pods = _mk_slider(self.pods_inner_frame, 0.3, 0.95, 0.80, self.update_pods_sens)

        self.pods_capture_selector = ctk.CTkSegmentedButton(self.pods_inner_frame,
            values=["Alerte","Banque","Transferts","Tout Transférer"],
            variable=self.var_pods_capture_type,
            selected_color=ACCENT_COLOR, selected_hover_color=ACCENT_HOVER,
            unselected_color=CARD2_COLOR, text_color=TEXT_COLOR, height=22)
        self.pods_capture_selector.pack(pady=4, padx=10, fill="x")
        self.lbl_pods_counts = ctk.CTkLabel(self.pods_inner_frame,
            text="Modèles : A:0 | B:0 | T:0 | TT:0",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_counts.pack(pady=2)
        # Labels coords pods (requis par load_config)
        self.lbl_pods_bank_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Banque : non définie", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_bank_coords.pack(pady=1, padx=10)
        self.lbl_pods_transfers_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Transferts : non défini", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_transfers_coords.pack(pady=1, padx=10)
        self.lbl_pods_transfer_all_coords = ctk.CTkLabel(self.pods_inner_frame,
            text="Transférer : non défini", font=ctk.CTkFont(size=10), text_color=TEXT_DIM)
        self.lbl_pods_transfer_all_coords.pack(pady=1, padx=10)

        self.btn_clear_pods = ctk.CTkButton(self.pods_inner_frame, text="🗑️ Effacer Modèles Pods",
            command=self.clear_pods, fg_color=RED_COLOR, hover_color=RED_HOVER,
            text_color="#FFFFFF", font=ctk.CTkFont(weight="bold"), height=26, corner_radius=6)
        self.btn_clear_pods.pack(pady=6, padx=10, fill="x")

        # ── BOUTON BOT + STATUS ────────────────────────
        self.btn_bot = ctk.CTkButton(self.sidebar_frame,
            text="⚔  LANCER LE BOT  (F4)",
            command=self.toggle_bot, height=50,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            text_color="#FFFFFF", corner_radius=0)
        self.btn_bot.pack(side="bottom", fill="x")

        ctk.CTkFrame(self.sidebar_frame, height=1, fg_color=BORDER_COLOR).pack(side="bottom", fill="x")

        self.status_frame = ctk.CTkFrame(self.sidebar_frame, fg_color=CARD_COLOR, corner_radius=0, height=92)
        self.status_frame.pack(side="bottom", fill="x")
        self.status_frame.pack_propagate(False)

        row_badge = ctk.CTkFrame(self.status_frame, fg_color="transparent")
        row_badge.pack(fill="x", padx=12, pady=(8, 1))
        self.lbl_state_badge = ctk.CTkLabel(row_badge, text="⬛ INACTIF",
            font=ctk.CTkFont(weight="bold", size=13), text_color=TEXT_DIM)
        self.lbl_state_badge.pack(side="left")
        self.lbl_combat_count = ctk.CTkLabel(row_badge, text="Combats : 0",
            font=ctk.CTkFont(size=11), text_color=TEXT_DIM)
        self.lbl_combat_count.pack(side="right")

        self.lbl_status = ctk.CTkLabel(self.status_frame, text="Statut : Prêt",
            text_color=TEXT_COLOR, font=ctk.CTkFont(size=11), anchor="w")
        self.lbl_status.pack(fill="x", padx=12, pady=0)

        self.lbl_debug = ctk.CTkLabel(self.status_frame,
            text="M: 0%  C: 0%  V: 0%",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM, anchor="w")
        self.lbl_debug.pack(fill="x", padx=12, pady=(0, 6))

                        # --- UI Vidéo (Canvas à droite) ---
        self.video_frame = ctk.CTkFrame(self, fg_color=BG_COLOR, corner_radius=0)
        self.video_frame.pack(side="right", fill="both", expand=True, padx=0, pady=0)
        
        self.canvas = tk.Canvas(self.video_frame, bg="#11111b", highlightthickness=0, cursor="cross")
        self.canvas.pack(fill="both", expand=True, padx=5, pady=5)
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        
        self.rect = None
        self.start_x = 0
        self.start_y = 0
        
        self.refresh_window_list()
        self.load_templates_to_cache()
        self.load_config()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        # ── Serveur web mobile ────────────────────────────────────────────
        self._web_server = BotWebServer(self, port=5000)
        self._web_ip = self._web_server.start()
        # Afficher l'URL dans le label status pour que l'utilisateur la voie
        self.after(500, lambda: self.lbl_status.configure(
            text=f"Statut : 📱 WiFi: http://{self._web_ip}:5000  PIN: {self._web_server.pin}"))
        try:
            keyboard.add_hotkey('f4', lambda: self.after(0, self.toggle_bot))
            keyboard.add_hotkey('f2', lambda: self.after(0, self.instant_stop))
        except Exception as e:
            print(f"[HOTKEY] Erreur d'enregistrement des raccourcis: {e}")

        # ── Infobulles complètes ──────────────────────────
        T = self.add_tooltip
        T(self.btn_capture,      "👁 APERÇU\nDémarre/arrête la prévisualisation du jeu en direct.\nNécessaire pour définir les zones de clic.")
        T(self.btn_open_folder,  "📂 DOSSIER MODÈLES\nOuvre le dossier où sont stockées les images\ncapturées (monstres, combat, victoire).")
        T(self.btn_show_last_match, "🔍 DERNIER MATCH\nOuvre l'image du dernier modèle détecté\npour vérifier que la détection est correcte.")
        T(self.window_selector,  "🖥 FENÊTRE CIBLE\nSélectionne la fenêtre Dofus à surveiller.\nDoit être différent de 'Écran Complet'\npour activer les modes Fantôme/Masquée.")
        T(self.btn_refresh,      "🔄 RAFRAÎCHIR\nMet à jour la liste des fenêtres ouvertes.\nÀ utiliser si Dofus n'apparaît pas dans la liste.")
        T(self.chk_background_mode, "🖱 CONTRÔLES FANTÔME\nEnvoie les clics et touches directement à Dofus\nsans déplacer ta souris physique.\n✅ Recommandé : tu peux utiliser ton PC\nlibrement pendant que le bot joue.")
        T(self.chk_hidden_capture, "🥷 CAPTURE MASQUÉE\nCapture l'écran de Dofus même si la fenêtre\nest en arrière-plan ou minimisée.\nUtilise GDI (PrintWindow) au lieu de MSS.")
        T(self.chk_dpi_scaling,  "🔎 FIX DPI\nCorrige les décalages de clic si ton écran\nutil une mise à l'échelle (125%, 150%, etc.)\nDans Paramètres Windows > Affichage > Mise à l'échelle.")
        T(self.sens_entry,       "🎯 PRÉCISION IA\nSeuil minimum de ressemblance (%) pour\nqu'une image soit considérée comme détectée.\n• Trop bas (< 60%) → faux positifs\n• Trop haut (> 85%) → rate des détections\nValeur recommandée : 70-77%")
        T(self.slider,           "🎯 SLIDER PRÉCISION\nFais glisser pour ajuster la précision IA.\nLa valeur s'affiche dans le champ à droite.")
        T(self.entry_map_delay,  "⏰ DÉLAI CARTE\nTemps d'attente (secondes) entre deux tentatives\nde clic sur un monstre sur la carte.\nAugmente si le bot clique trop vite.")
        T(self.entry_launch_timeout, "⏱ ATTENTE LANCEMENT\nDurée max (s) pour qu'un combat se lance\naprès un clic. Sert aussi d'anti-vol : si le\nbot croit être en combat sans jamais jouer,\nil revient à la Carte après ce délai.")
        T(self.entry_monster_cooldown, "🛡 COOLDOWN MONSTRE\nDurée minimale (secondes) entre deux clics\nsur un monstre — empêche le double-clic.\nBaisse si tu veux que le bot réattaque plus vite.\nValeur recommandée : 2.0 - 4.0s")
        T(self.chk_close_menu,   "❌ FERMER MENU\nAppuie automatiquement sur Echap si le\nmenu principal de Dofus s'ouvre.")
        T(self.btn_clear,        "🗑 EFFACER MONSTRES\nSupprime toutes les images capturées\nde monstres. À faire avant de recapturer\npour un autre type de monstre.")
        T(self.btn_clear_menu,   "🗑 EFFACER MENU\nSupprime les images du menu principal.")
        T(self.btn_define_zone,  "🎯 ZONE DE CLIC\nClique ici puis fais un clic droit + glisser\nsur la vidéo pour définir où le bot va cliquer\npendant les combats (case cible du sort).")
        T(self.zone_mode_selector, "📏 MODE ZONE\n• Ligne : clic aléatoire sur une droite\n• Rectangle : clic aléatoire dans un rectangle\nLigne = plus précis pour une seule case cible.")
        T(self.entry_spell_key,  "⌨ TOUCHE SORT\nTouche du sort à utiliser en combat.\nExemples : 1, 2, 3, q, w, e...")
        T(self.entry_chain_count, "🔢 NB LANCERS\nNombre de fois que le sort est lancé par tour.\nDépend du nombre de PA et de la portée du sort.")
        T(self.entry_delay,      "⏳ DÉLAI ENTRE SORTS\nTemps d'attente (s) entre chaque lancer.\nAugmente si le jeu ne suit pas le rythme.")
        T(self.chk_pass_turn,    "⏭ PASSER LE TOUR\nAppuie automatiquement sur la touche de\npassage de tour après avoir lancé tous les sorts.")
        T(self.entry_pass_key,   "⌨ TOUCHE PASSAGE\nTouche pour passer le tour.\nGénéralement F1 dans Dofus.")
        T(self.entry_start_delay, "⏰ ATTENTE DÉBUT\nDélai (s) avant de commencer à jouer\nle tour — laisse le temps aux animations.")
        T(self.entry_end_delay,  "⏰ DÉLAI FIN TOUR\nAttente (s) après les sorts et avant\nde passer le tour.")
        T(self.entry_ready_delay, "⏰ ATTENTE APRÈS PRÊT\nPause après le clic sur 'Prêt' au début\ndu combat, avant de jouer le tour.")
        T(self.chk_victory_esc,  "🏆 FERMER PAR ECHAP\nFerme l'écran de fin de combat avec Echap.\nPlus rapide que de cliquer sur un bouton.")
        T(self.entry_victory_delay_min, "⏱ DÉLAI MIN VICTOIRE\nTemps minimum (s) d'attente avant de\nfermer l'écran de fin de combat.")
        T(self.entry_victory_delay_max, "⏱ DÉLAI MAX VICTOIRE\nTemps maximum (s) d'attente avant de\nfermer l'écran de fin de combat.\nValeur aléatoire entre Min et Max.")
        T(self.entry_victory_cooldown, "⏳ COOLDOWN POST-COMBAT\nDurée (s) à attendre après un combat\navant de chercher un nouveau monstre.")
        T(self.btn_clear_victoire, "🗑 EFFACER VICTOIRE\nSupprime les images du bouton de victoire.")
        T(self.btn_bot,          "⚔ LANCER / ARRÊTER\nDémarre ou stoppe le bot (aussi sur F4).\nF2 = arrêt d'urgence instantané.")
        T(self.chk_modo_enabled, "🛡 ANTI-MODO\nDétecte la présence d'un modérateur\net répond automatiquement dans le chat.")
        T(self.modo_mode_selector, "🔍 MODE DÉTECTION\n• Présence : réagit si le modèle est vu\n• Changement : réagit si la zone change")
        T(self.entry_modo_text,  "💬 MESSAGE AUTO\nTexte envoyé automatiquement dans le chat\nquand un modérateur est détecté.")
        T(self.btn_define_modo_chat, "💬 POSITION CHAT\nClique ici puis fais un clic gauche\nsur la zone de chat pour la définir.")
        T(self.btn_clear_modo,   "🗑 EFFACER MODO\nSupprime les images de détection modo.")
        T(self.chk_pods_enabled, "🎒 VIDAGE BANQUE\nVide automatiquement en banque quand\nl'alerte de pods pleins est détectée.")
        T(self.entry_pods_sens,  "🎯 PRÉCISION PODS\nSeuil de détection pour l'alerte pods.")
        T(self.pods_capture_selector, "📸 ÉTAPE À CAPTURER\nSélectionne l'étape avant de faire\nun clic droit sur la vidéo pour capturer.")
        T(self.btn_clear_pods,   "🗑 EFFACER PODS\nSupprime les images d'alerte pods.")

    def add_tooltip(self, widget, text):
        ToolTip(widget, text)

    def update_ghost_options_state(self, choice):
        if choice == "Écran Complet":
            self.var_background_mode.set(False)
            self.var_hidden_capture.set(False)
            self.chk_background_mode.configure(state="disabled")
            self.chk_hidden_capture.configure(state="disabled")
        else:
            self.chk_background_mode.configure(state="normal")
            self.chk_hidden_capture.configure(state="normal")

    # --- Callbacks de synchronisation slider <-> champ de saisie ---
    def update_sens(self, value):
        self.sens_entry.delete(0, tk.END)
        self.sens_entry.insert(0, str(int(value * 100)))

    def _on_sens_entry(self, event=None):
        try:
            raw = self.sens_entry.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(30, min(95, v))
            self.slider.set(v / 100.0)
            self.sens_entry.delete(0, tk.END)
            self.sens_entry.insert(0, str(v))
        except ValueError:
            pass

    def _on_sens_keyrelease(self, event=None):
        try:
            raw = self.sens_entry.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(30, min(95, v))
            self.slider.set(v / 100.0)
        except ValueError:
            pass

    def _on_chain_count_entry(self, event=None):
        try:
            raw = self.entry_chain_count.get().strip()
            if not raw:
                return
            v = int(float(raw))
            v = max(1, min(10, v))
            self.entry_chain_count.delete(0, tk.END)
            self.entry_chain_count.insert(0, str(v))
        except ValueError:
            pass

    @staticmethod
    def _delay_seconds_from_config(raw, lo, hi, default):
        """Normalise un delai charge : ancien format ms (>5) -> secondes, puis borne."""
        try:
            v = float(str(raw).replace(",", "."))
        except Exception:
            return default
        if v > 5:  # ancienne valeur stockee en millisecondes
            v = v / 1000.0
        return round(max(lo, min(hi, v)), 2)

    def update_delay_lbl(self, value):
        self.entry_delay.delete(0, tk.END)
        self.entry_delay.insert(0, f"{float(value):.2f}")

    def _on_delay_entry(self, event=None):
        try:
            raw = self.entry_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(3.0, float(raw))), 2)
            self.slider_delay.set(v)
            self.entry_delay.delete(0, tk.END)
            self.entry_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(3.0, float(raw))), 2)
            self.slider_delay.set(v)
        except ValueError:
            pass

    def update_start_delay_lbl(self, value):
        self.entry_start_delay.delete(0, tk.END)
        self.entry_start_delay.insert(0, f"{float(value):.2f}")

    def _on_start_delay_entry(self, event=None):
        try:
            raw = self.entry_start_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_start_delay.set(v)
            self.entry_start_delay.delete(0, tk.END)
            self.entry_start_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_start_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_start_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_start_delay.set(v)
        except ValueError:
            pass

    def update_end_delay_lbl(self, value):
        self.entry_end_delay.delete(0, tk.END)
        self.entry_end_delay.insert(0, f"{float(value):.2f}")

    def _on_end_delay_entry(self, event=None):
        try:
            raw = self.entry_end_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_end_delay.set(v)
            self.entry_end_delay.delete(0, tk.END)
            self.entry_end_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_end_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_end_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_end_delay.set(v)
        except ValueError:
            pass

    def update_ready_delay_lbl(self, value):
        self.entry_ready_delay.delete(0, tk.END)
        self.entry_ready_delay.insert(0, f"{float(value):.2f}")

    def _on_ready_delay_entry(self, event=None):
        try:
            raw = self.entry_ready_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_ready_delay.set(v)
            self.entry_ready_delay.delete(0, tk.END)
            self.entry_ready_delay.insert(0, f"{v:.2f}")
        except ValueError:
            pass

    def _on_ready_delay_keyrelease(self, event=None):
        try:
            raw = self.entry_ready_delay.get().strip().replace(",", ".")
            if not raw:
                return
            v = round(max(0.01, min(2.0, float(raw))), 2)
            self.slider_ready_delay.set(v)
        except ValueError:
            pass

    def _on_modo_sens_entry(self, event=None):
        try:
            raw = self.entry_modo_sens.get().strip()
            if not raw: return
            v = int(raw)
            v = max(30, min(95, v))
            self.slider_modo.set(v / 100.0)
            self.entry_modo_sens.delete(0, tk.END)
            self.entry_modo_sens.insert(0, str(v))
            self.save_config()
        except ValueError:
            pass

    def _on_modo_sens_keyrelease(self, event=None):
        try:
            raw = self.entry_modo_sens.get().strip()
            if not raw: return
            v = int(raw)
            if 30 <= v <= 95:
                self.slider_modo.set(v / 100.0)
                self.save_config()
        except ValueError:
            pass

    def update_modo_sens(self, value):
        self.entry_modo_sens.delete(0, tk.END)
        self.entry_modo_sens.insert(0, str(int(value * 100)))
        self.save_config()

    def toggle_define_modo_chat(self):
        self.is_defining_modo_chat = not self.is_defining_modo_chat
        if self.is_defining_modo_chat:
            self.is_defining_zone = False # Désactiver l'autre dessin
            self.btn_define_modo_chat.configure(text="[Cliquez sur l'image]", fg_color=GREEN_COLOR)
        else:
            self.btn_define_modo_chat.configure(text="💬 Définir Clic Chat", fg_color=ACCENT_COLOR)

    def clear_modo(self):
        for f in os.listdir(self.templates_modo):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_modo, f))
        self.load_templates_to_cache()
        original = self.btn_clear_modo.cget("text")
        self.btn_clear_modo.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_modo.configure(text=original))
        self.log_status("Modèles Modo effacés")

    def clear_menu(self):
        for f in os.listdir(self.templates_menu):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_menu, f))
        self.load_templates_to_cache()
        original = self.btn_clear_menu.cget("text")
        self.btn_clear_menu.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_menu.configure(text=original))
        self.log_status("Modèles Menu Principal effacés")

    def _on_pods_sens_entry(self, event=None):
        try:
            raw = self.entry_pods_sens.get().strip()
            if not raw: return
            v = int(raw)
            v = max(30, min(95, v))
            self.slider_pods.set(v / 100.0)
            self.entry_pods_sens.delete(0, tk.END)
            self.entry_pods_sens.insert(0, str(v))
            self.save_config()
        except ValueError:
            pass

    def _on_pods_sens_keyrelease(self, event=None):
        try:
            raw = self.entry_pods_sens.get().strip()
            if not raw: return
            v = int(raw)
            if 30 <= v <= 95:
                self.slider_pods.set(v / 100.0)
                self.save_config()
        except ValueError:
            pass

    def update_pods_sens(self, value):
        self.entry_pods_sens.delete(0, tk.END)
        self.entry_pods_sens.insert(0, str(int(value * 100)))
        self.save_config()



    def clear_pods(self):
        for d in [self.templates_pods, self.templates_pods_bank, self.templates_pods_transfers, self.templates_pods_transfer_all]:
            if os.path.exists(d):
                for f in os.listdir(d):
                    if f.endswith(".png"):
                        os.remove(os.path.join(d, f))
        self.load_templates_to_cache()
        original = self.btn_clear_pods.cget("text")
        self.btn_clear_pods.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_pods.configure(text=original))
        self.log_status("Modèles Pods effacés")

    def update_map_delay_lbl(self, value):
        pass

    def _on_map_delay_entry(self, event=None):
        try:
            raw = self.entry_map_delay.get().strip()
            if not raw:
                return
            v = float(raw)
            v = max(0.1, min(8.0, v))
            self.entry_map_delay.delete(0, tk.END)
            self.entry_map_delay.insert(0, f"{v:.1f}")
            self.current_map_delay = v * np.random.uniform(0.85, 1.15)
        except ValueError:
            pass

    def _on_launch_timeout_entry(self, event=None):
        try:
            raw = self.entry_launch_timeout.get().strip()
            if not raw:
                return
            v = float(raw)
            v = max(1.0, min(30.0, v))
            self.entry_launch_timeout.delete(0, tk.END)
            self.entry_launch_timeout.insert(0, f"{v:.1f}")
        except ValueError:
            pass

    def update_victory_delay_min_lbl(self, value):
        pass

    def _on_victory_delay_min_entry(self, event=None):
        try:
            raw = self.entry_victory_delay_min.get().strip()
            if not raw:
                return
            v = float(raw)
            v = max(0.1, min(10.0, v))
            self.entry_victory_delay_min.delete(0, tk.END)
            self.entry_victory_delay_min.insert(0, f"{v:.1f}")
        except ValueError:
            pass

    def update_victory_delay_max_lbl(self, value):
        pass

    def _on_victory_delay_max_entry(self, event=None):
        try:
            raw = self.entry_victory_delay_max.get().strip()
            if not raw:
                return
            v = float(raw)
            v = max(0.1, min(10.0, v))
            self.entry_victory_delay_max.delete(0, tk.END)
            self.entry_victory_delay_max.insert(0, f"{v:.1f}")
        except ValueError:
            pass

    def update_victory_cooldown_lbl(self, value):
        pass

    def _on_victory_cooldown_entry(self, event=None):
        try:
            raw = self.entry_victory_cooldown.get().strip()
            if not raw:
                return
            v = float(raw)
            v = max(0.0, min(10.0, v))
            self.entry_victory_cooldown.delete(0, tk.END)
            self.entry_victory_cooldown.insert(0, f"{v:.1f}")
        except ValueError:
            pass

    def save_config(self):
        try:
            config = {
                "window_target": self.window_selector.get(),
                "background_mode": self.var_background_mode.get(),
                "hidden_capture": self.var_hidden_capture.get(),
                "dpi_scaling": self.var_dpi_scaling.get(),
                "precision": self.slider.get(),
                "map_delay": self.entry_map_delay.get(),
                "launch_timeout": self.entry_launch_timeout.get(),
                "zone_x": self.entry_zone_x.get(),
                "zone_y": self.entry_zone_y.get(),
                "zone_w": self.entry_zone_w.get(),
                "zone_h": self.entry_zone_h.get(),
                "spell_key": self.entry_spell_key.get(),
                "chain_count": self.entry_chain_count.get(),
                "delay": self.entry_delay.get(),
                "pass_turn": self.var_pass_turn.get(),
                "pass_key": self.entry_pass_key.get(),
                "start_delay": self.entry_start_delay.get(),
                "end_delay": self.entry_end_delay.get(),
                "ready_delay": self.entry_ready_delay.get(),
                "victory_esc": self.var_victory_esc.get(),
                "victory_delay_min": self.entry_victory_delay_min.get(),
                "victory_delay_max": self.entry_victory_delay_max.get(),
                "victory_cooldown": self.entry_victory_cooldown.get(),
                "zone_mode": self.zone_mode_var.get(),
                "modo_enabled": self.var_modo_enabled.get(),
                "modo_trigger_mode": self.var_modo_trigger_mode.get(),
                "modo_precision": self.slider_modo.get(),
                "modo_chat_x": self.modo_chat_x if self.modo_chat_x is not None else "",
                "modo_chat_y": self.modo_chat_y if self.modo_chat_y is not None else "",
                "modo_crop_x": self.modo_crop_x if self.modo_crop_x is not None else "",
                "modo_crop_y": self.modo_crop_y if self.modo_crop_y is not None else "",
                "modo_crop_w": self.modo_crop_w if self.modo_crop_w is not None else "",
                "modo_crop_h": self.modo_crop_h if self.modo_crop_h is not None else "",
                "modo_text": self.entry_modo_text.get(),
                "close_menu": self.var_close_menu.get(),
                "pods_enabled": self.var_pods_enabled.get(),
                "pods_precision": self.slider_pods.get(),
                "pods_bank_x": self.pods_bank_x if self.pods_bank_x is not None else "",
                "pods_bank_y": self.pods_bank_y if self.pods_bank_y is not None else "",
                "pods_transfers_x": self.pods_transfers_x if self.pods_transfers_x is not None else "",
                "pods_transfers_y": self.pods_transfers_y if self.pods_transfers_y is not None else "",
                "pods_transfer_all_x": self.pods_transfer_all_x if self.pods_transfer_all_x is not None else "",
                "pods_transfer_all_y": self.pods_transfer_all_y if self.pods_transfer_all_y is not None else "",
                "monster_cooldown": self.entry_monster_cooldown.get()
            }
            import json
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
            print(f"[CONFIG] Sauvegardée dans {self.config_file}")
        except Exception as e:
            print(f"[CONFIG] Erreur sauvegarde: {e}")

    def load_config(self):
        try:
            if not os.path.exists(self.config_file):
                return
            import json
            with open(self.config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
                
            # Restauration des valeurs
            if "window_target" in config:
                val = config["window_target"]
                self.window_selector.set(val)
                self.vision.set_target_window(val)
                self.update_ghost_options_state(val)
                
            if "background_mode" in config:
                self.var_background_mode.set(config["background_mode"])
            if "hidden_capture" in config:
                self.var_hidden_capture.set(config["hidden_capture"])
            if "dpi_scaling" in config:
                self.var_dpi_scaling.set(config["dpi_scaling"])
                
            if "precision" in config:
                val = float(config["precision"])
                self.slider.set(val)
                self.sens_entry.delete(0, tk.END)
                self.sens_entry.insert(0, str(int(val * 100)))
                
            if "map_delay" in config:
                self.entry_map_delay.delete(0, tk.END)
                self.entry_map_delay.insert(0, config["map_delay"])
                try:
                    self.current_map_delay = float(config["map_delay"])
                except:
                    pass
                    
            if "launch_timeout" in config:
                self.entry_launch_timeout.delete(0, tk.END)
                self.entry_launch_timeout.insert(0, config["launch_timeout"])
                
            if "zone_x" in config:
                self.entry_zone_x.delete(0, tk.END)
                self.entry_zone_x.insert(0, config["zone_x"])
            if "zone_y" in config:
                self.entry_zone_y.delete(0, tk.END)
                self.entry_zone_y.insert(0, config["zone_y"])
            if "zone_w" in config:
                self.entry_zone_w.delete(0, tk.END)
                self.entry_zone_w.insert(0, config["zone_w"])
            if "zone_h" in config:
                self.entry_zone_h.delete(0, tk.END)
                self.entry_zone_h.insert(0, config["zone_h"])
                try:
                    x1 = int(float(config["zone_x"]))
                    y1 = int(float(config["zone_y"]))
                    x2 = int(float(config["zone_w"]))
                    y2 = int(float(config["zone_h"]))
                    self.combat_zone = ((x1, y1), (x2, y2))
                except:
                    pass
                    
            if "spell_key" in config:
                self.entry_spell_key.delete(0, tk.END)
                self.entry_spell_key.insert(0, config["spell_key"])
            if "chain_count" in config:
                self.entry_chain_count.delete(0, tk.END)
                self.entry_chain_count.insert(0, config["chain_count"])
                
            if "delay" in config:
                v = self._delay_seconds_from_config(config["delay"], 0.01, 3.0, 0.08)
                self.entry_delay.delete(0, tk.END)
                self.entry_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_delay.set(v)
                except:
                    pass
                    
            if "pass_turn" in config:
                self.var_pass_turn.set(config["pass_turn"])
            if "pass_key" in config:
                self.entry_pass_key.delete(0, tk.END)
                self.entry_pass_key.insert(0, config["pass_key"])
                
            if "start_delay" in config:
                v = self._delay_seconds_from_config(config["start_delay"], 0.01, 2.0, 0.30)
                self.entry_start_delay.delete(0, tk.END)
                self.entry_start_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_start_delay.set(v)
                except:
                    pass
            if "end_delay" in config:
                v = self._delay_seconds_from_config(config["end_delay"], 0.01, 2.0, 0.15)
                self.entry_end_delay.delete(0, tk.END)
                self.entry_end_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_end_delay.set(v)
                except:
                    pass
            if "ready_delay" in config:
                v = self._delay_seconds_from_config(config["ready_delay"], 0.01, 2.0, 0.50)
                self.entry_ready_delay.delete(0, tk.END)
                self.entry_ready_delay.insert(0, f"{v:.2f}")
                try:
                    self.slider_ready_delay.set(v)
                except:
                    pass
                    
            if "victory_esc" in config:
                self.var_victory_esc.set(config["victory_esc"])
            if "victory_delay_min" in config:
                self.entry_victory_delay_min.delete(0, tk.END)
                self.entry_victory_delay_min.insert(0, config["victory_delay_min"])
            if "victory_delay_max" in config:
                self.entry_victory_delay_max.delete(0, tk.END)
                self.entry_victory_delay_max.insert(0, config["victory_delay_max"])
            if "victory_cooldown" in config:
                self.entry_victory_cooldown.delete(0, tk.END)
                self.entry_victory_cooldown.insert(0, config["victory_cooldown"])
                
            if "zone_mode" in config:
                self.zone_mode_var.set(config["zone_mode"])
                self.click_zone_mode = config["zone_mode"]
                
            if "modo_enabled" in config:
                self.var_modo_enabled.set(config["modo_enabled"])
            if "modo_trigger_mode" in config:
                self.var_modo_trigger_mode.set(config["modo_trigger_mode"])
            if "modo_precision" in config:
                val = float(config["modo_precision"])
                self.slider_modo.set(val)
                self.entry_modo_sens.delete(0, tk.END)
                self.entry_modo_sens.insert(0, str(int(val * 100)))
            if "modo_chat_x" in config and config["modo_chat_x"] != "":
                self.modo_chat_x = int(config["modo_chat_x"])
            if "modo_chat_y" in config and config["modo_chat_y"] != "":
                self.modo_chat_y = int(config["modo_chat_y"])
                self.lbl_modo_chat_coords.configure(text=f"Clic Chat : X={self.modo_chat_x}, Y={self.modo_chat_y}", text_color=GREEN_COLOR)
            if "modo_crop_x" in config and config["modo_crop_x"] != "":
                self.modo_crop_x = int(config["modo_crop_x"])
            if "modo_crop_y" in config and config["modo_crop_y"] != "":
                self.modo_crop_y = int(config["modo_crop_y"])
            if "modo_crop_w" in config and config["modo_crop_w"] != "":
                self.modo_crop_w = int(config["modo_crop_w"])
            if "modo_crop_h" in config and config["modo_crop_h"] != "":
                self.modo_crop_h = int(config["modo_crop_h"])
            if "modo_text" in config:
                self.entry_modo_text.delete(0, tk.END)
                self.entry_modo_text.insert(0, config["modo_text"])
            if "close_menu" in config:
                self.var_close_menu.set(config["close_menu"])
            if "pods_enabled" in config:
                self.var_pods_enabled.set(config["pods_enabled"])
            if "pods_precision" in config:
                val = float(config["pods_precision"])
                self.slider_pods.set(val)
                self.entry_pods_sens.delete(0, tk.END)
                self.entry_pods_sens.insert(0, str(int(val * 100)))
            if "pods_bank_x" in config and config["pods_bank_x"] != "":
                self.pods_bank_x = int(config["pods_bank_x"])
            if "pods_bank_y" in config and config["pods_bank_y"] != "":
                self.pods_bank_y = int(config["pods_bank_y"])
                self.lbl_pods_bank_coords.configure(text=f"Banque : X={self.pods_bank_x}, Y={self.pods_bank_y}", text_color=GREEN_COLOR)
            if "pods_transfers_x" in config and config["pods_transfers_x"] != "":
                self.pods_transfers_x = int(config["pods_transfers_x"])
            if "pods_transfers_y" in config and config["pods_transfers_y"] != "":
                self.pods_transfers_y = int(config["pods_transfers_y"])
                self.lbl_pods_transfers_coords.configure(text=f"Transferts : X={self.pods_transfers_x}, Y={self.pods_transfers_y}", text_color=GREEN_COLOR)
            if "pods_transfer_all_x" in config and config["pods_transfer_all_x"] != "":
                self.pods_transfer_all_x = int(config["pods_transfer_all_x"])
            if "pods_transfer_all_y" in config and config["pods_transfer_all_y"] != "":
                self.pods_transfer_all_y = int(config["pods_transfer_all_y"])
                self.lbl_pods_transfer_all_coords.configure(text=f"Transférer : X={self.pods_transfer_all_x}, Y={self.pods_transfer_all_y}", text_color=GREEN_COLOR)
                
            if "monster_cooldown" in config:
                self.entry_monster_cooldown.delete(0, tk.END)
                self.entry_monster_cooldown.insert(0, str(config["monster_cooldown"]))
                
            print("[CONFIG] Restaurée avec succès.")
        except Exception as e:
            print(f"[CONFIG] Erreur chargement: {e}")


    def _show_mobile_popup(self):
        """Popup d'accès mobile avec QR code et tunnel 4G."""
        pop = ctk.CTkToplevel(self)
        pop.title("📱 Accès Mobile")
        pop.geometry("380x560")
        pop.resizable(False, False)
        pop.configure(fg_color=BG_COLOR)
        pop.grab_set()  # Focus forcé

        # En-tête
        ctk.CTkLabel(pop, text="RETRO", font=ctk.CTkFont(family="Arial Black", size=18, weight="bold"),
            text_color=WHITE if 'WHITE' in dir() else "#FFFFFF").pack(side="left", padx=(20,0), pady=(20,0))

        ctk.CTkLabel(pop, text="📱 Accès Mobile", font=ctk.CTkFont(size=16, weight="bold"),
            text_color=TEXT_COLOR).pack(pady=(20,6))
        ctk.CTkLabel(pop, text="Ouvre cette URL sur ton téléphone",
            font=ctk.CTkFont(size=11), text_color=TEXT_DIM).pack()

        # Zone URL WiFi
        url_frame = ctk.CTkFrame(pop, fg_color=CARD_COLOR, corner_radius=10,
            border_width=1, border_color=BORDER_COLOR)
        url_frame.pack(fill="x", padx=20, pady=12)

        ctk.CTkLabel(url_frame, text="📶 WiFi (même réseau)",
            font=ctk.CTkFont(size=10, weight="bold"), text_color=ACCENT_LIGHT).pack(pady=(10,2), padx=12, anchor="w")

        ip = getattr(self, '_web_ip', '...')
        wifi_url = f"http://{ip}:5000"
        self._wifi_url_var = ctk.StringVar(value=wifi_url)
        url_entry = ctk.CTkEntry(url_frame, textvariable=self._wifi_url_var,
            font=ctk.CTkFont(size=13), fg_color=CARD2_COLOR,
            border_width=0, text_color=TEXT_COLOR, state="readonly")
        url_entry.pack(fill="x", padx=12, pady=(0,4))

        pin_lbl = ctk.CTkLabel(url_frame, text=f"🔑 Code PIN : {self._web_server.pin}",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#F5C842")
        pin_lbl.pack(pady=(4,10))

        # QR Code
        qr_frame = ctk.CTkFrame(pop, fg_color=CARD_COLOR, corner_radius=10,
            border_width=1, border_color=BORDER_COLOR)
        qr_frame.pack(fill="x", padx=20, pady=(0,12))
        ctk.CTkLabel(qr_frame, text="📷 Scanner avec le téléphone",
            font=ctk.CTkFont(size=10, weight="bold"), text_color=ACCENT_LIGHT).pack(pady=(10,6), padx=12, anchor="w")

        try:
            import qrcode as _qr
            from PIL import Image as _PIL_Image
            qr = _qr.QRCode(version=1, box_size=5, border=2)
            qr.add_data(wifi_url)
            qr.make(fit=True)
            qr_img = qr.make_image(fill_color="#E0D8FF", back_color="#1A1A3E")
            qr_ctk = ctk.CTkImage(light_image=qr_img.convert("RGB"),
                                   dark_image=qr_img.convert("RGB"), size=(160, 160))
            ctk.CTkLabel(qr_frame, image=qr_ctk, text="").pack(pady=(0,10))
        except ImportError:
            # Installer qrcode si absent, sinon afficher l'URL
            ctk.CTkLabel(qr_frame,
                text=f"{wifi_url}",
                font=ctk.CTkFont(size=12), text_color=TEXT_COLOR,
                wraplength=300).pack(pady=(0,10), padx=12)
            def install_qr():
                import subprocess
                subprocess.run([__import__('sys').executable, "-m", "pip", "install",
                               "qrcode[pil]", "--quiet"], capture_output=True)
                pop.destroy()
                self.after(100, self._show_mobile_popup)
            ctk.CTkButton(qr_frame, text="Générer QR code", command=install_qr,
                fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
                height=28, corner_radius=6).pack(pady=(0,10), padx=12)

        # Zone 4G
        g4_frame = ctk.CTkFrame(pop, fg_color=CARD_COLOR, corner_radius=10,
            border_width=1, border_color=BORDER_COLOR)
        g4_frame.pack(fill="x", padx=20, pady=(0,12))
        ctk.CTkLabel(g4_frame, text="📡 4G / Hors domicile",
            font=ctk.CTkFont(size=10, weight="bold"), text_color=ACCENT_LIGHT).pack(pady=(10,4), padx=12, anchor="w")

        self._g4_url_var = ctk.StringVar(value=getattr(self._web_server, '_ngrok_url', '') or "")
        g4_url_entry = ctk.CTkEntry(g4_frame, textvariable=self._g4_url_var,
            placeholder_text="Clique pour activer →",
            font=ctk.CTkFont(size=12), fg_color=CARD2_COLOR,
            border_width=0, text_color=TEXT_COLOR, state="readonly")
        g4_url_entry.pack(fill="x", padx=12, pady=(0,8))

        btn_4g = ctk.CTkButton(g4_frame, text="🌐 Activer accès 4G",
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, text_color="#FFFFFF",
            height=30, corner_radius=6)

        def start_4g():
            btn_4g.configure(text="⏳ Connexion...", state="disabled")
            def on_url(url):
                if url:
                    self._g4_url_var.set(url)
                    btn_4g.configure(text="✅ Actif — " + url[:30] + "...", state="normal")
                    g4_url_entry.configure(state="normal")
                    try:
                        import qrcode as _qr
                        qr2 = _qr.QRCode(version=1, box_size=4, border=2)
                        qr2.add_data(url)
                        qr2.make(fit=True)
                        qr2_img = qr2.make_image(fill_color="#E0D8FF", back_color="#1A1A3E")
                        qr2_ctk = ctk.CTkImage(light_image=qr2_img.convert("RGB"),
                                               dark_image=qr2_img.convert("RGB"), size=(130, 130))
                        self.after(0, lambda: qr_frame.winfo_children()[-1].configure(image=qr2_ctk))
                    except Exception:
                        pass
                else:
                    btn_4g.configure(text="❌ SSH non disponible (Win10+ requis)", state="normal")
            self._web_server.start_tunnel_4g(callback=lambda url: self.after(0, lambda: on_url(url)))

        btn_4g.configure(command=start_4g)
        btn_4g.pack(fill="x", padx=12, pady=(0,10))

        ctk.CTkLabel(pop, text="Fonctionne sans compte, sans installation.",
            font=ctk.CTkFont(size=10), text_color=TEXT_DIM).pack(pady=(0,10))

    def on_close(self):
        self.is_bot_active = False
        self._bot_stop_event.set()
        try: self._web_server.stop()
        except Exception: pass
        try: ctypes.windll.winmm.timeEndPeriod(1)
        except Exception: pass
        self.save_config()
        self.destroy()

    def load_templates_to_cache(self):
        """Charge tous les templates depuis le disque dans le cache mémoire."""
        self.templates_cache = {
            self.templates_monstres: [],
            self.templates_combat: [],
            self.templates_victoire: [],
            self.templates_modo: [],
            self.templates_menu: [],
            self.templates_pods: [],
            self.templates_pods_bank: [],
            self.templates_pods_transfers: [],
            self.templates_pods_transfer_all: []
        }
        for t_dir in self.templates_cache.keys():
            if not os.path.exists(t_dir):
                continue
            for f in os.listdir(t_dir):
                if f.endswith(".png"):
                    t_path = os.path.join(t_dir, f)
                    try:
                        t_img = cv2.imread(t_path, cv2.IMREAD_GRAYSCALE)
                        if t_img is not None:
                            self.templates_cache[t_dir].append((f, t_img))
                    except Exception as e:
                        print(f"Erreur chargement template {f}: {e}")
        
        # Mettre à jour l'étiquette des comptes de modèles pods si elle existe
        if hasattr(self, "lbl_pods_counts"):
            self.lbl_pods_counts.configure(
                text=f"Modèles : A:{len(self.templates_cache[self.templates_pods])} | B:{len(self.templates_cache[self.templates_pods_bank])} | T:{len(self.templates_cache[self.templates_pods_transfers])} | TT:{len(self.templates_cache[self.templates_pods_transfer_all])}"
            )
            
        print(f"Templates chargés en mémoire : M:{len(self.templates_cache[self.templates_monstres])} | C:{len(self.templates_cache[self.templates_combat])} | V:{len(self.templates_cache[self.templates_victoire])} | Modo:{len(self.templates_cache[self.templates_modo])} | Menu:{len(self.templates_cache[self.templates_menu])} | Pods:{len(self.templates_cache[self.templates_pods])} | PodsBank:{len(self.templates_cache[self.templates_pods_bank])} | PodsTrans:{len(self.templates_cache[self.templates_pods_transfers])} | PodsAll:{len(self.templates_cache[self.templates_pods_transfer_all])}")

    def refresh_window_list(self):
        windows = ["Écran Complet"] + self.vision.get_available_windows()
        current = self.window_selector.get()
        self.window_selector.configure(values=windows)
        if current in windows:
            self.window_selector.set(current)
            self.update_ghost_options_state(current)
        else:
            self.window_selector.set("Écran Complet")
            self.vision.set_target_window("Écran Complet")
            self.update_ghost_options_state("Écran Complet")

    def on_window_selected(self, choice):
        self.vision.set_target_window(choice)
        self.update_ghost_options_state(choice)

    def on_zone_mode_changed(self, choice):
        self.click_zone_mode = choice
        self.log_status(f"Format zone : {choice}")

    def capture_loop(self):
        while self.is_capturing or self.is_bot_active:
            bg_capture = getattr(self, 'hidden_capture_active', False)
            try:
                frame = self.vision.get_latest_frame(background_mode=bg_capture)
                if frame is not None:
                    self.latest_captured_frame = frame
            except Exception as e:
                print("Erreur thread capture:", e)
            
            # 200ms de sommeil si capture masquée (PrintWindow) pour ne pas lagger, 15ms sinon (mss, ultra-fluide)
            sleep_time = 0.20 if bg_capture else 0.015
            time.sleep(sleep_time)

    def toggle_capture(self):
        if not self.is_capturing:
            self.is_capturing = True
            self.latest_captured_frame = None
            self.processed_frame = None
            self.btn_capture.configure(text="Arrêter Aperçu", fg_color="red", hover_color="darkred")
            
            if not hasattr(self, "cap_thread") or not self.cap_thread.is_alive():
                self.cap_thread = threading.Thread(target=self.capture_loop)
                self.cap_thread.daemon = True
                self.cap_thread.start()
            
            self.update_video_feed()
        else:
            self.is_capturing = False
            self.btn_capture.configure(text="Démarrer Aperçu", fg_color=["#3a7ebf", "#1f538d"])
            self.canvas.delete("all")
            self.canvas.create_text(400, 225, text="Aperçu arrêté.", fill="white", font=("Arial", 16))

    def open_templates_folder(self):
        try:
            os.startfile(self.templates_dir)
        except Exception as e:
            print(f"Erreur lors de l'ouverture du dossier: {e}")

    def open_last_match(self):
        path = getattr(self, 'last_matched_template_path', None)
        if path and os.path.exists(path):
            import subprocess
            win_path = os.path.normpath(path)
            # Sous Windows, /select permet d'ouvrir le dossier et sélectionner le fichier
            subprocess.run(f'explorer /select,"{win_path}"')
        else:
            self.log_status("⚠️ Aucun modèle n'a encore été matché.")
            try:
                os.startfile(self.templates_dir)
            except Exception as e:
                print(f"Erreur: {e}")

    def on_press(self, event):
        if not self.is_capturing or self.current_cv_img is None: return
        self.start_x = event.x
        self.start_y = event.y
        active_tab = self.tabview.get()
        if active_tab == "🛡️ Modo" and self.is_defining_modo_chat:
            self.rect = None
            return

        if active_tab == "Combat" and self.is_defining_zone:
            if self.click_zone_mode == "Ligne":
                self.rect = self.canvas.create_line(self.start_x, self.start_y, self.start_x, self.start_y, fill="#00ff00", width=2, tags="annot")
            else:
                self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline="#00ff00", width=2, tags="annot")
        else:
            self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline="#00ff00", width=2, tags="annot")

    def on_drag(self, event):
        if self.rect:
            self.canvas.coords(self.rect, self.start_x, self.start_y, event.x, event.y)
        self.update_magnifier(event.x, event.y)

    def on_mouse_move(self, event):
        self.update_magnifier(event.x, event.y)

    def update_magnifier(self, event_x, event_y):
        if not self.is_capturing or self.current_cv_img is None:
            return
        
        show_mag = self.is_defining_zone or self.rect is not None
        
        if not show_mag:
            self.canvas.delete("magnifier")
            return
            
        real_x = int((event_x - self.x_offset) / self.scale_ratio)
        real_y = int((event_y - self.y_offset) / self.scale_ratio)
        
        img_h, img_w = self.current_cv_img.shape[:2]
        if not (0 <= real_x < img_w and 0 <= real_y < img_h):
            self.canvas.delete("magnifier")
            return
            
        r = 15
        x_min = max(0, real_x - r)
        x_max = min(img_w, real_x + r + 1)
        y_min = max(0, real_y - r)
        y_max = min(img_h, real_y + r + 1)
        
        crop = self.current_cv_img[y_min:y_max, x_min:x_max].copy()
        
        pad_top = max(0, r - (real_y - y_min))
        pad_bottom = max(0, r - (y_max - 1 - real_y))
        pad_left = max(0, r - (real_x - x_min))
        pad_right = max(0, r - (x_max - 1 - real_x))
        
        if pad_top > 0 or pad_bottom > 0 or pad_left > 0 or pad_right > 0:
            crop = cv2.copyMakeBorder(crop, pad_top, pad_bottom, pad_left, pad_right, cv2.BORDER_CONSTANT, value=[0, 0, 0])
            
        mag_size = 155
        zoom_img = cv2.resize(crop, (mag_size, mag_size), interpolation=cv2.INTER_NEAREST)
        
        center = mag_size // 2
        cv2.line(zoom_img, (center - 10, center), (center + 10, center), (0, 0, 255), 1)
        cv2.line(zoom_img, (center, center - 10), (center, center + 10), (0, 0, 255), 1)
        cv2.rectangle(zoom_img, (0, 0), (mag_size - 1, mag_size - 1), (255, 255, 255), 2)
        
        zoom_rgb = cv2.cvtColor(zoom_img, cv2.COLOR_BGR2RGB)
        pil_mag = Image.fromarray(zoom_rgb)
        self.tk_mag = ImageTk.PhotoImage(image=pil_mag)
        
        canvas_w = self.canvas.winfo_width()
        mag_x = canvas_w - mag_size - 10
        mag_y = 10
        
        if event_x > canvas_w - 200 and event_y < 200:
            mag_x = 10
            
        self.canvas.delete("magnifier")
        self.canvas.create_image(mag_x, mag_y, image=self.tk_mag, anchor="nw", tags="magnifier")
        
        coord_text = f"X: {real_x}, Y: {real_y}"
        self.canvas.create_rectangle(mag_x, mag_y + mag_size, mag_x + mag_size, mag_y + mag_size + 20, fill="black", outline="white", tags="magnifier")
        self.canvas.create_text(mag_x + mag_size // 2, mag_y + mag_size + 10, text=coord_text, fill="white", font=("Arial", 10, "bold"), tags="magnifier")

    def on_release(self, event):
        active_tab = self.tabview.get()
        if active_tab == "🛡️ Modo" and self.is_defining_modo_chat:
            real_x = int((event.x - self.x_offset) / self.scale_ratio)
            real_y = int((event.y - self.y_offset) / self.scale_ratio)
            img_h, img_w = self.current_cv_img.shape[:2]
            real_x = max(0, min(real_x, img_w - 1))
            real_y = max(0, min(real_y, img_h - 1))
            
            self.modo_chat_x = real_x
            self.modo_chat_y = real_y
            self.is_defining_modo_chat = False
            self.btn_define_modo_chat.configure(text="💬 Définir Clic Chat", fg_color=ACCENT_COLOR)
            self.lbl_modo_chat_coords.configure(text=f"Clic Chat : X={real_x}, Y={real_y}", text_color=GREEN_COLOR)
            
            msg = self.canvas.create_text(event.x, event.y, text="🎯 Position Chat définie !", fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
            self.save_config()
            return
            

            
        if not self.rect: return
        left = min(self.start_x, event.x)
        top = min(self.start_y, event.y)
        width = abs(self.start_x - event.x)
        height = abs(self.start_y - event.y)
        self.canvas.delete(self.rect)
        self.rect = None
        self.canvas.delete("magnifier")
        
        if self.current_cv_img is not None:
            real_left = int((left - self.x_offset) / self.scale_ratio)
            real_top = int((top - self.y_offset) / self.scale_ratio)
            real_width = int(width / self.scale_ratio)
            real_height = int(height / self.scale_ratio)
            
            img_h, img_w = self.current_cv_img.shape[:2]
            real_left = max(0, min(real_left, img_w - 1))
            real_top = max(0, min(real_top, img_h - 1))
            
            active_tab = self.tabview.get()
            
            if active_tab == "⚔️ Combat" and self.is_defining_zone:
                real_x1 = int((self.start_x - self.x_offset) / self.scale_ratio)
                real_y1 = int((self.start_y - self.y_offset) / self.scale_ratio)
                real_x2 = int((event.x - self.x_offset) / self.scale_ratio)
                real_y2 = int((event.y - self.y_offset) / self.scale_ratio)
                
                img_h, img_w = self.current_cv_img.shape[:2]
                real_x1 = max(0, min(real_x1, img_w - 1))
                real_y1 = max(0, min(real_y1, img_h - 1))
                real_x2 = max(0, min(real_x2, img_w - 1))
                real_y2 = max(0, min(real_y2, img_h - 1))
                
                self.combat_zone = ((real_x1, real_y1), (real_x2, real_y2))
                self.is_defining_zone = False
                self.btn_define_zone.configure(text="Définir zone de clic", fg_color=["#3a7ebf", "#1f538d"])
                
                # Mettre à jour les champs de texte
                self.entry_zone_x.delete(0, tk.END)
                self.entry_zone_x.insert(0, str(real_x1))
                self.entry_zone_y.delete(0, tk.END)
                self.entry_zone_y.insert(0, str(real_y1))
                self.entry_zone_w.delete(0, tk.END)
                self.entry_zone_w.insert(0, str(real_x2))
                self.entry_zone_h.delete(0, tk.END)
                self.entry_zone_h.insert(0, str(real_y2))
                
                msg_txt = "🎯 Ligne définie !" if self.click_zone_mode == "Ligne" else "🎯 Zone définie !"
                msg = self.canvas.create_text(event.x, event.y, text=msg_txt, fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
                self.after(1500, lambda: self.canvas.delete(msg))
                return
                
            if real_width > 5 and real_height > 5:
                real_width = max(1, min(real_width, img_w - real_left))
                real_height = max(1, min(real_height, img_h - real_top))
                
                if active_tab == "🗺️ Carte":
                    if self.var_carte_capture_type.get() == "Menu Principal":
                        target_dir = self.templates_menu
                        name_prefix = "menu"
                    else:
                        target_dir = self.templates_monstres
                        name_prefix = "monstre"
                elif active_tab == "⚔️ Combat":
                    target_dir = self.templates_combat
                    name_prefix = "combat"
                elif active_tab == "🏆 Victoire":
                    target_dir = self.templates_victoire
                    name_prefix = "victoire"
                elif active_tab == "🛡️ Modo":
                    target_dir = self.templates_modo
                    name_prefix = "modo"
                    self.modo_crop_x = real_left
                    self.modo_crop_y = real_top
                    self.modo_crop_w = real_width
                    self.modo_crop_h = real_height
                    self.save_config()
                elif active_tab == "🎒 Pods":
                    cap_type = self.var_pods_capture_type.get()
                    if cap_type == "Alerte":
                        target_dir = self.templates_pods
                        name_prefix = "pods"
                    elif cap_type == "Banque":
                        target_dir = self.templates_pods_bank
                        name_prefix = "pods_bank"
                    elif cap_type == "Transferts":
                        target_dir = self.templates_pods_transfers
                        name_prefix = "pods_transfers"
                    elif cap_type == "Tout Transférer":
                        target_dir = self.templates_pods_transfer_all
                        name_prefix = "pods_transfer_all"
                    else:
                        target_dir = self.templates_pods
                        name_prefix = "pods"
                else:
                    return
                    
                try:
                    crop = self.current_cv_img[real_top:real_top+real_height, real_left:real_left+real_width]
                    # Ouvrir la fenêtre de prévisualisation avant de sauvegarder
                    self.show_template_preview(crop, target_dir, name_prefix, event.x, event.y)
                except Exception as e:
                    print("Erreur crop:", e)

    def show_template_preview(self, crop_img, target_dir, name_prefix, canvas_x, canvas_y):
        """Affiche une popup de prévisualisation du template capturé avant sauvegarde."""
        preview_win = ctk.CTkToplevel(self)
        preview_win.title("Aperçu du modèle")
        preview_win.attributes("-topmost", True)
        preview_win.resizable(False, False)
        
        # Calculer la taille d'affichage (zoom x4 minimum pour bien voir, max 400px)
        h, w = crop_img.shape[:2]
        zoom = max(4, min(400 // max(w, h, 1), 10))
        display_w = w * zoom
        display_h = h * zoom
        
        # Convertir BGR -> RGB pour l'affichage
        crop_rgb = cv2.cvtColor(crop_img, cv2.COLOR_BGR2RGB)
        pil_preview = Image.fromarray(crop_rgb).resize((display_w, display_h), Image.Resampling.NEAREST)
        tk_preview = ImageTk.PhotoImage(image=pil_preview)
        
        # Centrer la fenêtre
        win_w = max(display_w + 40, 280)
        win_h = display_h + 120
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        pos_x = (screen_w - win_w) // 2
        pos_y = (screen_h - win_h) // 2
        preview_win.geometry(f"{win_w}x{win_h}+{pos_x}+{pos_y}")
        
        # Titre
        type_names = {"monstre": "🐉 Monstre", "combat": "⚔️ Combat", "victoire": "🏆 Victoire"}
        title_text = type_names.get(name_prefix, name_prefix)
        ctk.CTkLabel(preview_win, text=f"Template capturé : {title_text}", font=ctk.CTkFont(size=14, weight="bold")).pack(pady=(10, 5))
        
        # Taille en pixels
        ctk.CTkLabel(preview_win, text=f"Taille : {w} × {h} px", font=ctk.CTkFont(size=11), text_color="gray").pack()
        
        # Image prévisualisée
        img_label = ctk.CTkLabel(preview_win, text="", image=ctk.CTkImage(light_image=pil_preview, dark_image=pil_preview, size=(display_w, display_h)))
        img_label.pack(pady=10)
        # Garder une référence pour éviter le garbage collection
        img_label._tk_img = tk_preview
        
        # Boutons
        btn_frame = ctk.CTkFrame(preview_win, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        def save_template():
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(target_dir, f"{name_prefix}_{ts}.png")
            cv2.imwrite(filepath, crop_img)
            self.load_templates_to_cache()
            preview_win.destroy()
            msg = self.canvas.create_text(canvas_x, canvas_y, text="✅ Modèle sauvé !", fill="#00ff00", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
        
        def cancel_template():
            preview_win.destroy()
            msg = self.canvas.create_text(canvas_x, canvas_y, text="❌ Annulé", fill="#ff5555", font=("Arial", 14, "bold"), tags="annot")
            self.after(1500, lambda: self.canvas.delete(msg))
        
        ctk.CTkButton(btn_frame, text="✅ Sauvegarder", command=save_template, fg_color="#2d8f4e", hover_color="#1e6b38", font=ctk.CTkFont(size=13, weight="bold")).pack(side="left", expand=True, fill="x", padx=(0, 5))
        ctk.CTkButton(btn_frame, text="❌ Annuler", command=cancel_template, fg_color="#b53535", hover_color="#872323", font=ctk.CTkFont(size=13, weight="bold")).pack(side="right", expand=True, fill="x", padx=(5, 0))

    def toggle_define_zone(self):
        self.is_defining_zone = not self.is_defining_zone
        if self.is_defining_zone:
            self.btn_define_zone.configure(text="[Dessine sur l'image]", fg_color=GREEN_COLOR)
        else:
            self.btn_define_zone.configure(text="🎯 Dessiner Zone (Clic Droit)", fg_color=ACCENT_COLOR)
            self.canvas.delete("magnifier")

    def apply_manual_zone(self):
        try:
            x1 = int(self.entry_zone_x.get().strip())
            y1 = int(self.entry_zone_y.get().strip())
            x2 = int(self.entry_zone_w.get().strip())
            y2 = int(self.entry_zone_h.get().strip())
            
            if self.current_cv_img is not None:
                img_h, img_w = self.current_cv_img.shape[:2]
                x1 = max(0, min(x1, img_w - 1))
                y1 = max(0, min(y1, img_h - 1))
                x2 = max(0, min(x2, img_w - 1))
                y2 = max(0, min(y2, img_h - 1))
            else:
                x1 = max(0, x1)
                y1 = max(0, y1)
                x2 = max(0, x2)
                y2 = max(0, y2)
                
            self.entry_zone_x.delete(0, tk.END)
            self.entry_zone_x.insert(0, str(x1))
            self.entry_zone_y.delete(0, tk.END)
            self.entry_zone_y.insert(0, str(y1))
            self.entry_zone_w.delete(0, tk.END)
            self.entry_zone_w.insert(0, str(x2))
            self.entry_zone_h.delete(0, tk.END)
            self.entry_zone_h.insert(0, str(y2))
            
            self.combat_zone = ((x1, y1), (x2, y2))
            self.log_status(f"Ligne de clic manuelle appliquée : {self.combat_zone}")
        except ValueError:
            self.log_status("⚠️ Coordonnées invalides !")

    def clear_monstres(self):
        for f in os.listdir(self.templates_monstres):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_monstres, f))
        self.load_templates_to_cache()
        original = self.btn_clear.cget("text")
        self.btn_clear.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear.configure(text=original))
        self.log_status("Modèles monstres effacés")

    def clear_combat(self):
        for f in os.listdir(self.templates_combat):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_combat, f))
        self.load_templates_to_cache()
        original = self.btn_clear_combat.cget("text")
        self.btn_clear_combat.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_combat.configure(text=original))
        self.log_status("Modèles combat effacés")

    def clear_victoire(self):
        for f in os.listdir(self.templates_victoire):
            if f.endswith(".png"):
                os.remove(os.path.join(self.templates_victoire, f))
        self.load_templates_to_cache()
        original = self.btn_clear_victoire.cget("text")
        self.btn_clear_victoire.configure(text="✅ Effacé")
        self.after(1500, lambda: self.btn_clear_victoire.configure(text=original))
        self.log_status("Modèles victoire effacés")

    def log_status(self, text):
        self.lbl_status.configure(text=f"Statut : {text}")
        print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {text}")

    def set_gui_state(self, state):
        self.entry_spell_key.configure(state=state)
        self.entry_chain_count.configure(state=state)
        self.entry_pass_key.configure(state=state)
        self.entry_zone_x.configure(state=state)
        self.entry_zone_y.configure(state=state)
        self.entry_zone_w.configure(state=state)
        self.entry_zone_h.configure(state=state)
        
        self.btn_apply_zone.configure(state=state)
        self.btn_define_zone.configure(state=state)
        self.zone_mode_selector.configure(state=state)
        self.btn_clear.configure(state=state)
        self.btn_clear_combat.configure(state=state)
        self.btn_clear_victoire.configure(state=state)
        self.btn_refresh.configure(state=state)
        
        self.chk_pass_turn.configure(state=state)
        self.chk_victory_esc.configure(state=state)
        self.chk_background_mode.configure(state=state)
        self.chk_hidden_capture.configure(state=state)
        self.chk_dpi_scaling.configure(state=state)
        self.window_selector.configure(state=state)
        self.entry_victory_delay_min.configure(state=state)
        self.entry_victory_delay_max.configure(state=state)
        self.entry_victory_cooldown.configure(state=state)
        self.entry_map_delay.configure(state=state)
        self.entry_launch_timeout.configure(state=state)
        
        self.chk_modo_enabled.configure(state=state)
        self.modo_mode_selector.configure(state=state)
        self.entry_modo_text.configure(state=state)
        self.entry_modo_sens.configure(state=state)
        self.slider_modo.configure(state=state)
        self.btn_define_modo_chat.configure(state=state)
        self.btn_clear_modo.configure(state=state)
        
        self.chk_close_menu.configure(state=state)
        self.carte_capture_selector.configure(state=state)
        self.btn_clear_menu.configure(state=state)
        
        self.chk_pods_enabled.configure(state=state)
        self.entry_pods_sens.configure(state=state)
        self.slider_pods.configure(state=state)
        self.pods_capture_selector.configure(state=state)
        self.btn_clear_pods.configure(state=state)

    def toggle_bot(self):
        self.is_bot_active = not self.is_bot_active
        if self.is_bot_active:
            self.focus()
            self.set_gui_state("disabled")
            self.save_config()
            self.bot_state = "MAP"
            self.my_turn = False
            self.last_click_time = 0
            self.last_combat_time = 0
            self.combat_launching = False
            self.combat_launch_time = 0
            self.combat_button_seen = False
            self.last_victory_time = 0
            self._last_monster_click_time = 0
            self.combat_count = 0
            try:
                v_min = float(self.entry_victory_delay_min.get().strip())
                v_max = float(self.entry_victory_delay_max.get().strip())
                self.current_victory_delay = np.random.uniform(min(v_min, v_max), max(v_min, v_max))
                self.current_map_delay = float(self.entry_map_delay.get().strip())
            except:
                self.current_victory_delay = np.random.uniform(2.0, 4.0)
                self.current_map_delay = 3.0
            self.btn_bot.configure(text="🛑 Arrêter le Bot (F4)", fg_color=RED_COLOR, hover_color=RED_HOVER)
            self.log_status("Bot Démarré - État: CARTE")
            self._update_state_badge("MAP")
            print(f"[BOT] === DÉMARRAGE === État={self.bot_state}")

            # FIX FLUIDITÉ 1 : timers Windows haute résolution (1ms au lieu de 15ms)
            try:
                ctypes.windll.winmm.timeBeginPeriod(1)
            except Exception:
                pass

            # FIX FLUIDITÉ 2 : mettre Dofus en haute priorité CPU
            try:
                title = self.vision.target_window_title
                if title and title not in ["Écran Complet", "", None]:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        _, pid = win32process.GetWindowThreadProcessId(hwnd)
                        h = win32api.OpenProcess(0x0200 | 0x0400, False, pid)
                        if h:
                            win32process.SetPriorityClass(h, win32process.HIGH_PRIORITY_CLASS)
                            win32api.CloseHandle(h)
                            self._dofus_pid = pid
                            print(f"[BOOST] Dofus PID {pid} → HAUTE PRIORITÉ")
            except Exception as e:
                print(f"[BOOST] {e}")

            if not hasattr(self, "cap_thread") or not self.cap_thread.is_alive():
                self.cap_thread = threading.Thread(target=self.capture_loop)
                self.cap_thread.daemon = True
                self.cap_thread.start()

            # FIX DOUBLE-CLIC : bot dans un thread dédié (pas de double instance via self.after)
            self._bot_stop_event.clear()
            self._bot_thread = threading.Thread(target=self._bot_thread_func, daemon=True)
            self._bot_thread.start()
        else:
            self._bot_stop_event.set()
            self.set_gui_state("normal")
            self.save_config()
            self.btn_bot.configure(text="▶ Lancer le Bot (F4)", fg_color=GREEN_COLOR, hover_color=GREEN_HOVER)
            self.log_status("Bot Arrêté")
            self._update_state_badge("INACTIF")
            try:
                ctypes.windll.winmm.timeEndPeriod(1)
            except Exception:
                pass
            try:
                pid = getattr(self, '_dofus_pid', None)
                if pid:
                    h = win32api.OpenProcess(0x0200 | 0x0400, False, pid)
                    if h:
                        win32process.SetPriorityClass(h, win32process.NORMAL_PRIORITY_CLASS)
                        win32api.CloseHandle(h)
            except Exception:
                pass

    def _update_state_badge(self, state):
        """Met à jour le badge état + compteur combats (thread-safe)."""
        badges = {
            "MAP":     ("🗺️  CARTE",    "#34D058"),
            "COMBAT":  ("⚔️  COMBAT",   "#EF4444"),
            "VICTORY": ("🏆  VICTOIRE", "#C084FC"),
            "INACTIF": ("⬛  INACTIF",  "#6B6B9A"),
        }
        text, color = badges.get(state, ("⬛  INACTIF", "#6B6B9A"))
        def _do():
            if hasattr(self, 'lbl_state_badge'):
                self.lbl_state_badge.configure(text=text, text_color=color)
            if hasattr(self, 'lbl_combat_count'):
                self.lbl_combat_count.configure(text=f"Combats : {self.combat_count}")
        self.after(0, _do)

    def instant_stop(self):
        if self.is_bot_active:
            self.is_bot_active = False
            self.set_gui_state("normal")
            self.save_config()
            self.btn_bot.configure(text="🚀 Lancer le Bot (F4)", fg_color=GREEN_COLOR, hover_color=GREEN_HOVER)
            self.log_status("🚨 BOT ARRÊTÉ D'URGENCE !")
            self._update_state_badge("INACTIF")

    def focus_target_window(self):
        if hasattr(self, 'var_background_mode') and self.var_background_mode.get():
            return True
            
        title = self.vision.target_window_title
        if not title or title == "Écran Complet":
            return True
        try:
            hwnd = win32gui.FindWindow(None, title)
            if hwnd:
                if win32gui.IsIconic(hwnd):
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                curr_foreground = win32gui.GetForegroundWindow()
                if curr_foreground != hwnd:
                    # Assurer le focus clavier/souris Windows
                    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                    win32gui.SetForegroundWindow(hwnd)
                    time.sleep(0.1)
                return True
        except Exception as e:
            print("Erreur focus_target_window:", e)
        return False

    def win32_move_to(self, x, y, duration=0.15):
        try:
            start_x, start_y = win32gui.GetCursorPos()
            steps = int(duration * 60)
            if steps < 1:
                win32api.SetCursorPos((x, y))
                return
            for i in range(steps + 1):
                t = i / steps
                curr_x = int(start_x + (x - start_x) * t)
                curr_y = int(start_y + (y - start_y) * t)
                win32api.SetCursorPos((curr_x, curr_y))
                time.sleep(duration / steps)
        except Exception as e:
            print(f"Erreur win32_move_to: {e}")
            win32api.SetCursorPos((x, y))

    def send_key(self, vk_code, background_mode=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        scancode = ctypes.windll.user32.MapVirtualKeyW(vk_code, 0)
                        lParam_down = 1 | (scancode << 16)
                        lParam_up = 1 | (scancode << 16) | (1 << 30) | (1 << 31)
                        win32gui.PostMessage(target_hwnd, win32con.WM_KEYDOWN, vk_code, lParam_down)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_KEYUP, vk_code, lParam_up)
                        time.sleep(0.005)
                        return
                    else:
                        print("[KEY] Window handle not found for background key.")
                        return
                except Exception as e:
                    print(f"Erreur touche fantôme: {e}")
                    return
            else:
                print("[KEY] Cannot send background key on full screen.")
                return
                    
        # Repli sur l'envoi matériel classique
        hardware_key(vk_code)

    def send_text(self, text, background_mode=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        for char in text:
                            win32gui.PostMessage(target_hwnd, 0x0102, ord(char), 0) # 0x0102 is WM_CHAR
                            time.sleep(0.01)
                        return
                except Exception as e:
                    print(f"Erreur texte fantôme: {e}")
                    return
        try:
            keyboard.write(text)
            time.sleep(0.05)
        except Exception as e:
            print(f"Erreur keyboard.write: {e}")

    def get_dpi_ratios(self, hwnd):
        try:
            # 1. Obtenir les dimensions physiques (notre thread est DPI aware par défaut)
            _, _, phys_w, phys_h = win32gui.GetClientRect(hwnd)
            if phys_w <= 0 or phys_h <= 0:
                return 1.0, 1.0
                
            # 2. Obtenir les dimensions logiques en passant temporairement en DPI Unaware
            import ctypes
            try:
                SetThreadDpiAwarenessContext = ctypes.windll.user32.SetThreadDpiAwarenessContext
                SetThreadDpiAwarenessContext.restype = ctypes.c_void_p
                SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
                
                old_ctx = SetThreadDpiAwarenessContext(ctypes.c_void_p(-1))
                _, _, log_w, log_h = win32gui.GetClientRect(hwnd)
                if old_ctx:
                    SetThreadDpiAwarenessContext(old_ctx)
                    
                if log_w > 0 and log_h > 0:
                    return log_w / phys_w, log_h / phys_h
            except Exception as e:
                print("Erreur GetThreadDpiAwarenessContext:", e)
        except Exception as e:
            print("Erreur get_dpi_ratios:", e)
        return 1.0, 1.0

    def click_on_game(self, rel_x, rel_y, background_mode=None, dpi_scaling=None):
        if background_mode is None:
            background_mode = hasattr(self, 'var_background_mode') and self.var_background_mode.get()
        if dpi_scaling is None:
            dpi_scaling = hasattr(self, 'var_dpi_scaling') and self.var_dpi_scaling.get()
            
        if background_mode:
            title = self.vision.target_window_title
            if title and title != "Écran Complet":
                try:
                    hwnd = win32gui.FindWindow(None, title)
                    if hwnd:
                        target_hwnd = get_game_rendering_hwnd(hwnd)
                        # Par défaut, Dofus Unity (DPI-aware) attend des coordonnées physiques directes.
                        # On n'applique le ratio de mise à l'échelle que si l'utilisateur l'active explicitement.
                        if dpi_scaling:
                            ratio_x, ratio_y = self.get_dpi_ratios(target_hwnd)
                            lx = int(rel_x * ratio_x)
                            ly = int(rel_y * ratio_y)
                        else:
                            lx = rel_x
                            ly = rel_y
                            
                        lParam = win32api.MAKELONG(lx, ly)
                        # Envoyer un déplacement de souris pour mettre à jour la case ciblée dans Dofus
                        win32gui.PostMessage(target_hwnd, win32con.WM_MOUSEMOVE, 0, lParam)
                        time.sleep(0.015) # Attendre que le jeu gère le survol de la case
                        
                        win32gui.PostMessage(target_hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lParam)
                        time.sleep(0.015)
                        win32gui.PostMessage(target_hwnd, win32con.WM_LBUTTONUP, 0, lParam)
                        time.sleep(0.005)
                        return
                    else:
                        print("[CLICK] Window handle not found for background click.")
                        return
                except Exception as e:
                    print(f"Erreur clic fantôme: {e}")
                    return
            else:
                print("[CLICK] Cannot perform background click on full screen.")
                return

        if not self.focus_target_window():
            return

        screen_x = int(self.vision.monitor['left'] + rel_x)
        screen_y = int(self.vision.monitor['top'] + rel_y)

        try:
            # FIX : vérifier que Dofus est TOUJOURS au premier plan juste avant de cliquer
            # Evite d'envoyer des clics involontaires quand l'utilisateur est sur une autre fenêtre
            title = self.vision.target_window_title
            if title and title not in ["Écran Complet", ""]:
                hwnd_check = win32gui.FindWindow(None, title)
                if hwnd_check and win32gui.GetForegroundWindow() != hwnd_check:
                    print(f"[CLICK] Dofus n'est pas au premier plan — clic ignoré pour ne pas perturber l'utilisateur")
                    return

            win32api.SetCursorPos((screen_x, screen_y))
            time.sleep(0.005)
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, screen_x, screen_y, 0, 0)
            time.sleep(0.010)
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, screen_x, screen_y, 0, 0)

        except Exception as e:
            print(f"Erreur clic matériel: {e}")

    def detect_template(self, gray_img, templates_dir, custom_threshold=None):
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
            
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
            
        if custom_threshold is not None:
            threshold = custom_threshold
        else:
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6

        # Ignorer le haut de la fenêtre (barre de titre / bordure de 45 pixels)
        # pour éviter les faux positifs (comme la croix de fermeture Windows ou les menus)
        h_offset = 0
        search_img = gray_img
        if templates_dir in [self.templates_combat, self.templates_victoire]:
            if gray_img.shape[0] > 100:
                search_img = gray_img[45:, :]
                h_offset = 45
                
        # --- Crop-First cache optimization for static buttons ---
        last_loc_attr = None
        if templates_dir == self.templates_combat:
            last_loc_attr = 'last_combat_button_loc'
        elif templates_dir == self.templates_victoire:
            last_loc_attr = 'last_victory_button_loc'
            
        if last_loc_attr:
            last_loc = getattr(self, last_loc_attr, None)
            if last_loc is not None:
                (x, y), (h, w) = last_loc
                # Adjust y since search_img starts at h_offset
                y_in_search = y - h_offset
                img_h, img_w = search_img.shape[:2]
                pad = 15
                y1 = max(0, y_in_search - pad)
                y2 = min(img_h, y_in_search + h + pad)
                x1 = max(0, x - pad)
                x2 = min(img_w, x + w + pad)
                if (y2 - y1) >= h and (x2 - x1) >= w:
                    crop = search_img[y1:y2, x1:x2]
                    val, loc, shape, name = self.detect_template_in_crop(crop, templates_dir)
                    if val >= threshold:
                        exact_x = x1 + loc[0]
                        exact_y = y1 + loc[1] + h_offset
                        setattr(self, last_loc_attr, ((exact_x, exact_y), shape))
                        if name:
                            self.last_matched_template_path = os.path.join(templates_dir, name)
                        return val, (exact_x, exact_y), shape, name

        best_val = 0
        best_loc = None
        best_shape = None
        best_name = None
        best_idx = -1
        
        for idx, (t_name, t_img) in enumerate(cached_list):
            # S'assurer que le template n'est pas plus grand que l'image de recherche
            if t_img.shape[0] > search_img.shape[0] or t_img.shape[1] > search_img.shape[1]:
                continue
                
            res = cv2.matchTemplate(search_img, t_img, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            
            if max_val > best_val:
                best_val = max_val
                best_loc = max_loc
                best_shape = t_img.shape
                best_name = t_name
                best_idx = idx
                
            # Arrêt précoce : si on a un match parfait/excellent (> 85%), c'est forcément la bonne cible
            if max_val >= 0.85:
                break
                
        # Move-To-Front (MTF) cache optimization
        if best_val >= threshold and best_idx > 0:
            cached_list.insert(0, cached_list.pop(best_idx))
            
        if best_loc is not None:
            best_loc = (best_loc[0], best_loc[1] + h_offset)
            if last_loc_attr:
                setattr(self, last_loc_attr, (best_loc, best_shape))
            
        return best_val, best_loc, best_shape, best_name

    def detect_template_nearest(self, gray_img, templates_dir, center_xy, custom_threshold=None):
        """Comme detect_template mais renvoie la cible (au-dessus du seuil) dont le
        centre est le PLUS PROCHE de center_xy (le perso, ~ centre de l'ecran).
        Chaque zone de match distincte = 1 candidat (regroupement par composantes
        connexes), donc un monstre n'est pas compte plusieurs fois."""
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
        if custom_threshold is not None:
            threshold = custom_threshold
        else:
            try:
                threshold = self.slider.get()
            except Exception:
                threshold = 0.6

        search_img = gray_img
        candidates = []  # (val, (x, y), (h, w), name)
        for t_name, t_img in cached_list:
            if t_img.shape[0] > search_img.shape[0] or t_img.shape[1] > search_img.shape[1]:
                continue
            res = cv2.matchTemplate(search_img, t_img, cv2.TM_CCOEFF_NORMED)
            mask = (res >= threshold).astype('uint8')
            if not mask.any():
                continue
            num, labels = cv2.connectedComponents(mask)
            for lbl in range(1, num):
                comp = (labels == lbl)
                ys, xs = np.where(comp)
                k = int(np.argmax(res[comp]))
                py, px = int(ys[k]), int(xs[k])
                candidates.append((float(res[py, px]), (px, py), t_img.shape, t_name))

        if not candidates:
            return 0, None, None, None

        tx, ty = center_xy
        def _d2(c):
            (x, y), (h, w) = c[1], c[2]
            mx, my = x + w / 2.0, y + h / 2.0
            return (mx - tx) ** 2 + (my - ty) ** 2
        best = min(candidates, key=_d2)
        if best[3]:
            self.last_matched_template_path = os.path.join(templates_dir, best[3])
        return best[0], best[1], best[2], best[3]

    def detect_template_in_crop(self, gray_crop, templates_dir):
        if templates_dir not in self.templates_cache:
            return 0, None, None, None
            
        cached_list = self.templates_cache[templates_dir]
        if not cached_list:
            return 0, None, None, None
            
        best_val = 0
        best_loc = None
        best_shape = None
        best_name = None
        best_idx = -1
        
        for idx, (t_name, t_img) in enumerate(cached_list):
            if t_img.shape[0] > gray_crop.shape[0] or t_img.shape[1] > gray_crop.shape[1]:
                continue
                
            res = cv2.matchTemplate(gray_crop, t_img, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            
            if max_val > best_val:
                best_val = max_val
                best_loc = max_loc
                best_shape = t_img.shape
                best_name = t_name
                best_idx = idx
                
            # Arrêt précoce
            if max_val >= 0.85:
                break
                
        try:
            threshold = self.slider.get()
        except:
            threshold = 0.6
            
        if best_val >= threshold and best_idx > 0:
            cached_list.insert(0, cached_list.pop(best_idx))
            
        return best_val, best_loc, best_shape, best_name

    def is_combat_button_visible(self, threshold=None, background_mode=None):
        if threshold is None:
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
        if background_mode is None:
            background_mode = getattr(self, 'hidden_capture_active', False)
            
        # 1. Première vérification ultra-rapide en mémoire (0ms)
        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
            try:
                frame = self.latest_captured_frame.copy()
                gray_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                check_threshold = max(0.40, threshold - 0.15)
                
                last_loc = getattr(self, 'last_combat_button_loc', None)
                if last_loc is not None:
                    (x, y), (h, w) = last_loc
                    img_h, img_w = gray_img.shape[:2]
                    pad = 10
                    y1 = max(0, y - pad)
                    y2 = min(img_h, y + h + pad)
                    x1 = max(0, x - pad)
                    x2 = min(img_w, x + w + pad)
                    if (y2 - y1) >= h and (x2 - x1) >= w:
                        crop = gray_img[y1:y2, x1:x2]
                        val, loc, shape, name = self.detect_template_in_crop(crop, self.templates_combat)
                        if val >= check_threshold:
                            exact_x = x1 + loc[0]
                            exact_y = y1 + loc[1]
                            self.last_combat_button_loc = ((exact_x, exact_y), shape)
                            if name:
                                self.last_matched_template_path = os.path.join(self.templates_combat, name)
                            return True
                
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= check_threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    return True
            except Exception as e:
                print(f"Erreur première vérification mémoire: {e}")

        # 2. Si non trouvé en mémoire (ex: bouton caché par animation), on fait jusqu'à 2 tentatives supplémentaires en capturant une NOUVELLE image à chaque fois
        for attempt in range(1, 3):
            try:
                time.sleep(0.04) # Laisser le temps au jeu d'avancer
                
                # Forcer une nouvelle capture d'écran fraîche en direct
                frame = self.vision.get_latest_frame(background_mode=background_mode)
                if frame is None:
                    continue
                
                gray_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                check_threshold = max(0.40, threshold - 0.15)
                
                last_loc = getattr(self, 'last_combat_button_loc', None)
                if last_loc is not None:
                    (x, y), (h, w) = last_loc
                    img_h, img_w = gray_img.shape[:2]
                    pad = 10
                    y1 = max(0, y - pad)
                    y2 = min(img_h, y + h + pad)
                    x1 = max(0, x - pad)
                    x2 = min(img_w, x + w + pad)
                    if (y2 - y1) >= h and (x2 - x1) >= w:
                        crop = gray_img[y1:y2, x1:x2]
                        val, loc, shape, name = self.detect_template_in_crop(crop, self.templates_combat)
                        if val >= check_threshold:
                            exact_x = x1 + loc[0]
                            exact_y = y1 + loc[1]
                            self.last_combat_button_loc = ((exact_x, exact_y), shape)
                            if name:
                                self.last_matched_template_path = os.path.join(self.templates_combat, name)
                            return True
                
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= check_threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    return True
            except Exception as e:
                print(f"Erreur tentative {attempt} is_combat_button_visible: {e}")
                
        # Si après ces tentatives le bouton reste introuvable, on confirme sa disparition
        return False

    def execute_combat_turn(self):
        try:
            spell_key_str = self.entry_spell_key.get().strip()
            spell_key_vk = get_vk_code(spell_key_str)
            if spell_key_vk is None:
                spell_key_vk = 0x31
        except Exception:
            spell_key_vk = 0x31

        try:
            chain_count = int(self.entry_chain_count.get().strip())
        except Exception:
            chain_count = 2

        try:
            delay_s = self.slider_delay.get()
        except Exception:
            delay_s = 1.0

        pass_turn_checked = self.var_pass_turn.get()
        try:
            pass_turn_key_str = self.entry_pass_key.get().strip()
            pass_turn_key_vk = get_vk_code(pass_turn_key_str)
            if pass_turn_key_vk is None:
                pass_turn_key_vk = 0x70
        except Exception:
            pass_turn_key_vk = 0x70

        try:
            base_start_delay = self.slider_start_delay.get()
        except Exception:
            base_start_delay = 0.3

        try:
            base_end_delay = self.slider_end_delay.get()
        except Exception:
            base_end_delay = 0.15

        background_mode = self.var_background_mode.get()
        dpi_scaling = self.var_dpi_scaling.get()

        combat_zone = None
        try:
            ex1 = int(float(self.entry_zone_x.get().strip()))
            ey1 = int(float(self.entry_zone_y.get().strip()))
            ex2 = int(float(self.entry_zone_w.get().strip()))
            ey2 = int(float(self.entry_zone_h.get().strip()))
            combat_zone = ((ex1, ey1), (ex2, ey2))
        except Exception:
            combat_zone = getattr(self, 'combat_zone', None)

        click_zone_mode = self.zone_mode_var.get()
        
        try:
            threshold = self.slider.get()
        except:
            threshold = 0.6

        # Lancer les actions en arrière-plan avec la configuration figée thread-safe
        t = threading.Thread(target=self.run_combat_actions, args=(
            spell_key_vk, chain_count, delay_s, pass_turn_checked, pass_turn_key_vk,
            base_start_delay, base_end_delay, background_mode, dpi_scaling, combat_zone,
            click_zone_mode, threshold
        ))
        t.daemon = True
        t.start()

    def sleep_check(self, seconds):
        start = time.time()
        while time.time() - start < seconds:
            if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                return False
            time.sleep(0.05)
        return True

    def sleep_check_pods(self, seconds):
        start = time.time()
        while time.time() - start < seconds:
            if not self.is_bot_active:
                return False
            time.sleep(0.05)
        return True

    def run_combat_actions(self, spell_key_vk, chain_count, delay_s, pass_turn_checked, pass_turn_key_vk,
                           base_start_delay, base_end_delay, background_mode, dpi_scaling, combat_zone,
                           click_zone_mode, threshold):
        try:
            # Attendre le délai début de tour configuré (avec jitter aléatoire de +-15%)
            start_delay = base_start_delay * np.random.uniform(0.85, 1.15)
            if not self.sleep_check(start_delay):
                return
            
            # S'assurer que le jeu est au premier plan (si non fantôme)
            if not background_mode:
                self.focus_target_window()
            
            if not combat_zone:
                self.log_status("⚠️ Zone de clic indéfinie !")
                if pass_turn_checked and pass_turn_key_vk:
                    self.log_status("Passage du tour...")
                    self.send_key(pass_turn_key_vk, background_mode=background_mode)
                return

            (x1, y1), (x2, y2) = combat_zone
            
            # Choisir la cible UNE SEULE FOIS pour éviter de "sautiller" (moins robotique)
            if click_zone_mode == "Ligne":
                t = np.random.random()
                target_x = int(x1 + (x2 - x1) * t)
                target_y = int(y1 + (y2 - y1) * t)
            else:
                target_x = int(min(x1, x2) + abs(x2 - x1) * np.random.random())
                target_y = int(min(y1, y2) + abs(y2 - y1) * np.random.random())
            
            for i in range(chain_count):
                if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                    return
                
                # Vérification en temps réel avant chaque sort
                if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                    self.log_status("⚠️ Bouton 'Terminer' invisible. Fin de combat/tour détecté !")
                    self.my_turn = False
                    return
                
                # S'assurer que le jeu est toujours actif (si non fantôme)
                if not background_mode:
                    self.focus_target_window()
                    time.sleep(0.15)
                
                self.log_status(f"Sort {i+1}/{chain_count}...")
                
                # 1. Touche Sort
                self.send_key(spell_key_vk, background_mode=background_mode)
                delay_after_key = 0.015 if background_mode else 0.005
                if not self.sleep_check(delay_after_key):
                    return

                # 2. Clic sur la même cible
                self.click_on_game(target_x, target_y, background_mode=background_mode, dpi_scaling=dpi_scaling)
                
                # 3. Attente délai entre les sorts
                if not self.sleep_check(delay_s):
                    return
                
            # 4. Passer le tour
            if pass_turn_checked and pass_turn_key_vk:
                if not self.is_bot_active or self.bot_state != "COMBAT" or not self.my_turn:
                    return
                
                # Attente délai de fin
                if base_end_delay > 0:
                    if not self.sleep_check(base_end_delay):
                        return
                
                # Vérification en temps réel avant de passer le tour
                if not self.is_combat_button_visible(threshold=threshold, background_mode=background_mode):
                    self.log_status("⚠️ Bouton 'Terminer' invisible avant de passer le tour. Annulé.")
                    self.my_turn = False
                    return

                if not background_mode:
                    self.focus_target_window()
                self.log_status("Fin de mon tour (Pass)")
                self.send_key(pass_turn_key_vk, background_mode=background_mode)
                self.sleep_check(1.0)
        except Exception as e:
            print(f"Erreur actions combat: {e}")

    def _bot_thread_func(self):
        """Thread dédié — évite le throttling de tkinter en arrière-plan."""
        while not self._bot_stop_event.is_set() and self.is_bot_active:
            try:
                if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                    self.bot_logic_loop()
            except Exception as e:
                import traceback
                print("[BOT THREAD]", e, traceback.format_exc())
            interval = 0.05 if self.bot_state == "COMBAT" else 0.12
            self._bot_stop_event.wait(timeout=interval)

    def bot_logic_loop(self):
        try:
            if not self.is_bot_active:
                return
                
            if not hasattr(self, 'latest_captured_frame') or self.latest_captured_frame is None:
                return
                
            cv_img = self.latest_captured_frame.copy()
            gray_img = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
            
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
                
            # --- DETECTION DU MENU PRINCIPAL ---
            if self.var_close_menu.get():
                has_menu_templates = len(self.templates_cache.get(self.templates_menu, [])) > 0
                if has_menu_templates:
                    menu_val, menu_loc, menu_shape, menu_name = self.detect_template(gray_img, self.templates_menu)
                    if menu_val >= threshold and menu_loc is not None:
                        self.log_status(f"📋 Menu Principal détecté (Score: {int(menu_val*100)}%). Fermeture avec Echap...")
                        self.focus_target_window()
                        time.sleep(0.1)
                        self.send_key(0x1B) # VK_ESCAPE is 0x1B
                        time.sleep(0.3)
                        
                        return
            
                    # --- VERIFICATION DES PODS (BANQUE AUTOMATIQUE) ---
            if self.var_pods_enabled.get():
                has_pods_templates = len(self.templates_cache.get(self.templates_pods, [])) > 0
                if has_pods_templates:
                    pods_threshold = self.slider_pods.get()
                    pods_val, pods_loc, _ , _ = self.detect_template(gray_img, self.templates_pods, custom_threshold=pods_threshold)
                    if pods_val >= pods_threshold and pods_loc is not None:
                        self.log_status(f"🎒 [PODS] Alerte Pods détectée ! (Score: {int(pods_val*100)}%). Lancement de la séquence Banque...")
                        
                        self.focus_target_window()
                        time.sleep(0.2)
                        
                        # 1. Clic Ouvrir Banque
                        self.log_status("1/3 Recherche du bouton Banque par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            b_val, b_loc, b_shape, _ = self.detect_template(curr_gray, self.templates_pods_bank, custom_threshold=pods_threshold)
                            if b_loc is not None and b_val >= pods_threshold:
                                cx = b_loc[0] + b_shape[1] // 2
                                cy = b_loc[1] + b_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("1/3 Banque ouverte (clic effectué).")
                            else:
                                self.log_status("⚠️ Étape 1/3 échouée : Bouton Banque non détecté à l'écran.")
                                return
                                
                        # Attente ouverture banque
                        if not self.sleep_check_pods(2.0): return
                        
                        # 2. Clic Transferts Avancés
                        self.log_status("2/3 Recherche du bouton Transferts par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            t_val, t_loc, t_shape, _ = self.detect_template(curr_gray, self.templates_pods_transfers, custom_threshold=pods_threshold)
                            if t_loc is not None and t_val >= pods_threshold:
                                cx = t_loc[0] + t_shape[1] // 2
                                cy = t_loc[1] + t_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("2/3 Clic Transferts effectué.")
                            else:
                                self.log_status("⚠️ Étape 2/3 échouée : Bouton Transferts non détecté.")
                                self.send_key(0x1B) # Tenter de fermer par sécurité
                                return
                                
                        # Attente ouverture menu transfert
                        if not self.sleep_check_pods(2.0): return
                        
                        # 3. Clic Transférer tout
                        self.log_status("3/3 Recherche du bouton Tout Transférer par image...")
                        if hasattr(self, 'latest_captured_frame') and self.latest_captured_frame is not None:
                            curr_img = self.latest_captured_frame.copy()
                            curr_gray = cv2.cvtColor(curr_img, cv2.COLOR_BGR2GRAY)
                            a_val, a_loc, a_shape, _ = self.detect_template(curr_gray, self.templates_pods_transfer_all, custom_threshold=pods_threshold)
                            if a_loc is not None and a_val >= pods_threshold:
                                cx = a_loc[0] + a_shape[1] // 2
                                cy = a_loc[1] + a_shape[0] // 2
                                self.click_on_game(cx, cy)
                                self.log_status("3/3 Clic Tout Transférer effectué.")
                            else:
                                self.log_status("⚠️ Étape 3/3 échouée : Bouton Tout Transférer non détecté.")
                                self.send_key(0x1B)
                                return
                                
                        # Attente fin de transfert
                        if not self.sleep_check_pods(2.0): return
                        
                        # 4. Appuyer sur Echap
                        self.log_status("Fermeture de la banque par Echap...")
                        self.send_key(0x1B) # Escape
                        if not self.sleep_check_pods(1.0): return
                        
                        self.log_status("🎒 [PODS] Banque complétée. Reprise du bot.")
                        
                        return

            
            # --- VERIFICATION ANTI-MODO ---
            if self.var_modo_enabled.get():
                has_modo_templates = len(self.templates_cache.get(self.templates_modo, [])) > 0
                if has_modo_templates:
                    if (self.modo_crop_x is not None and self.modo_crop_y is not None and 
                        self.modo_crop_w is not None and self.modo_crop_h is not None):
                        img_h, img_w = gray_img.shape[:2]
                        x1 = max(0, min(self.modo_crop_x, img_w - 1))
                        y1 = max(0, min(self.modo_crop_y, img_h - 1))
                        x2 = max(0, min(self.modo_crop_x + self.modo_crop_w, img_w))
                        y2 = max(0, min(self.modo_crop_y + self.modo_crop_h, img_h))
                        
                        if (x2 - x1) > 5 and (y2 - y1) > 5:
                            gray_crop = gray_img[y1:y2, x1:x2]
                            modo_val, modo_loc, modo_shape, modo_name = self.detect_template_in_crop(gray_crop, self.templates_modo)
                        else:
                            modo_val, modo_loc, modo_shape, modo_name = self.detect_template(gray_img, self.templates_modo)
                    else:
                        modo_val, modo_loc, modo_shape, modo_name = self.detect_template(gray_img, self.templates_modo)
                        
                    trigger_mode = self.var_modo_trigger_mode.get()
                    modo_threshold = self.slider_modo.get()
                    
                    trigger_fired = False
                    reason = ""
                    
                    if trigger_mode == "Présence":
                        if modo_val >= modo_threshold:
                            trigger_fired = True
                            reason = f"Modèle Modo '{modo_name}' détecté avec une ressemblance de {int(modo_val*100)}% (seuil: {int(modo_threshold*100)}%)"
                    elif trigger_mode == "Changement":
                        if modo_val < modo_threshold:
                            trigger_fired = True
                            reason = f"Changement détecté dans la zone Modo! La ressemblance a chuté à {int(modo_val*100)}% (seuil: {int(modo_threshold*100)}%)"
                            
                    if trigger_fired:
                        self.log_status(f"🚨 [ANTI-MODO] DECLENCHE ! Raison: {reason}")
                        # 1. Arrêter immédiatement le bot
                        self.is_bot_active = False
                        self.btn_bot.configure(text="🚀 Lancer le Bot (F4)", fg_color=GREEN_COLOR)
                        self.set_gui_state("normal")
                        
                        # Déclencher le popup d'alerte dans un thread séparé (topmost)
                        def show_warning_popup():
                            try:
                                import ctypes
                                ctypes.windll.user32.MessageBoxW(0, "Attention modo !", "Alerte Securité", 0x10 | 0x40000)
                            except Exception as e:
                                print(f"Erreur popup: {e}")
                        threading.Thread(target=show_warning_popup, daemon=True).start()
                        
                        # 2. Amener de force Dofus en avant-plan pour réaction rapide
                        title = self.vision.target_window_title
                        if title and title != "Écran Complet":
                            try:
                                hwnd = win32gui.FindWindow(None, title)
                                if hwnd:
                                    if win32gui.IsIconic(hwnd):
                                        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                                    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
                                    win32gui.SetForegroundWindow(hwnd)
                                    time.sleep(0.2)
                            except Exception as e:
                                print(f"Erreur force focus: {e}")
                        
                        custom_text = self.entry_modo_text.get().strip() or "oui ?"
                        
                        # 3. Aller sur la zone de clic sélectionnée pour le chat (si définie) et cliquer
                        if self.modo_chat_x is not None and self.modo_chat_y is not None:
                            self.log_status(f"Clic sur le chat de réponse à ({self.modo_chat_x}, {self.modo_chat_y})...")
                            self.click_on_game(self.modo_chat_x, self.modo_chat_y)
                            time.sleep(0.2)
                            
                            # 4. Écrire le texte personnalisé
                            self.log_status(f"Envoi du message '{custom_text}'...")
                            self.send_text(custom_text)
                            time.sleep(0.2)
                            
                            # 5. Appuyer sur Entrée pour envoyer le message
                            self.log_status("Validation du message par Entrée...")
                            self.send_key(0x0D) # VK_RETURN is 0x0D
                            time.sleep(0.2)
                        else:
                            self.log_status("⚠️ Zone clic chat non configurée, envoi direct sans clic...")
                            self.send_text(custom_text)
                            time.sleep(0.2)
                            self.send_key(0x0D)
                            time.sleep(0.2)
                            
                        # 6. Eteindre le bot et stopper la boucle
                        self.log_status("🚨 [ANTI-MODO] Bot éteint pour sécurité !")
                        return
            
            try:
                threshold = self.slider.get()
            except:
                threshold = 0.6
            current_time = time.time()
            
            # Détection sélective pour économiser du CPU et accélérer la boucle de vision
            combat_val, combat_loc, combat_shape, combat_name = 0.0, None, None, None
            victoire_val, victoire_loc, victoire_shape, victoire_name = 0.0, None, None, None
            monstre_val, monstre_loc, monstre_shape, monstre_name = 0.0, None, None, None
            
            # La détection de victoire est toujours exécutée pour sortir du combat le plus vite possible
            victoire_val, victoire_loc, victoire_shape, victoire_name = self.detect_template(gray_img, self.templates_victoire)
            
            if self.bot_state == "MAP":
                # Sur la carte, on cherche les monstres et le bouton de combat (au cas où le combat se lance)
                _pcx, _pcy = gray_img.shape[1] // 2, gray_img.shape[0] // 2
                monstre_val, monstre_loc, monstre_shape, monstre_name = self.detect_template_nearest(gray_img, self.templates_monstres, (_pcx, _pcy))
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
            elif self.bot_state == "COMBAT":
                # En combat, on ne cherche que le bouton de combat ("Terminer")
                combat_val, combat_loc, combat_shape, combat_name = self.detect_template(gray_img, self.templates_combat)
                if combat_val >= threshold and combat_loc is not None:
                    self.last_combat_button_loc = (combat_loc, combat_shape)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
            
            self.after(0, lambda m=f"M:{int(monstre_val*100)}%  C:{int(combat_val*100)}%  V:{int(victoire_val*100)}%": self.lbl_debug.configure(text=m))
            
            try:
                victory_cooldown = float(self.entry_victory_cooldown.get().strip())
            except Exception:
                victory_cooldown = 2.0
                
            if victoire_val >= threshold and victoire_loc is not None and (current_time - self.last_victory_time > victory_cooldown):
                self.bot_state = "MAP"
                self.my_turn = False
                self.combat_launching = False
                self.farm_commands_sent = False
                if victoire_name:
                    self.last_matched_template_path = os.path.join(self.templates_victoire, victoire_name)
                
                h, w = victoire_shape
                cv2.rectangle(cv_img, victoire_loc, (victoire_loc[0]+w, victoire_loc[1]+h), (0, 255, 255), 3)
                
                if self.var_victory_esc.get():
                    self.log_status(f"Victoire Détectée ! (Score: {int(victoire_val*100)}%) - Modèle: {victoire_name or 'Inconnu'}. Fermeture par Echap...")
                    self.focus_target_window()
                    time.sleep(0.1)
                    self.send_key(0x1B)
                else:
                    self.log_status(f"Victoire Détectée ! (Score: {int(victoire_val*100)}%) - Modèle: {victoire_name or 'Inconnu'}. Fermeture par Clic...")
                    rel_x = victoire_loc[0] + w // 2
                    rel_y = victoire_loc[1] + h // 2
                    self.click_on_game(rel_x, rel_y)
                    
                self.last_click_time = 0
                self.combat_launch_time = 0
                self.last_victory_time = current_time
                
                try:
                    v_min = float(self.entry_victory_delay_min.get().strip())
                    v_max = float(self.entry_victory_delay_max.get().strip())
                    self.current_victory_delay = np.random.uniform(min(v_min, v_max), max(v_min, v_max))
                except:
                    self.current_victory_delay = np.random.uniform(2.0, 4.0)
                self.log_status(f"Retour Carte (Cooldown : {self.current_victory_delay:.2f} s)")
                
            elif self.bot_state == "MAP":
                if current_time - self.last_victory_time < self.current_victory_delay:
                    pass
                else:
                    active_threshold = max(0.45, threshold - 0.15) if self.combat_launching else threshold
                    if combat_val >= active_threshold and combat_loc is not None:
                        self.bot_state = "COMBAT"
                        self.my_turn = False
                        self.last_combat_time = current_time
                        self.combat_button_seen = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.combat_count += 1
                        if combat_name:
                            self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                        self.log_status(f"Combat Détecté ! (Score: {int(combat_val*100)}%) - Modèle: {combat_name or 'Inconnu'}")
                        self._update_state_badge("COMBAT")

                    else:
                        if self.combat_launching:
                            elapsed = current_time - self.combat_launch_time
                            try:
                                timeout = float(self.entry_launch_timeout.get().strip())
                            except Exception:
                                timeout = 8.0
                            if elapsed > timeout:
                                self.combat_launching = False
                                self.log_status("Délai de lancement combat dépassé, nouvel essai...")
                        else:
                            if current_time - self.last_click_time > self.current_map_delay:
                                if monstre_val >= threshold and monstre_loc is not None:
                                    # FIX double-clic : cooldown minimum absolu
                                    try:
                                        _cd = float(self.entry_monster_cooldown.get().strip())
                                    except Exception:
                                        _cd = self.MONSTER_CLICK_MIN_COOLDOWN
                                    if current_time - self._last_monster_click_time < _cd:
                                        self.log_status(f"⏳ Cooldown ({current_time - self._last_monster_click_time:.1f}s / {_cd:.1f}s)...")
                                    else:
                                        h, w = monstre_shape
                                        cv2.rectangle(cv_img, monstre_loc, (monstre_loc[0]+w, monstre_loc[1]+h), (0, 0, 255), 3)
                                        rel_x = monstre_loc[0] + w // 2
                                        rel_y = monstre_loc[1] + h // 2
                                        if monstre_name:
                                            self.last_matched_template_path = os.path.join(self.templates_monstres, monstre_name)
                                        self.log_status(f"Lancement combat... (Monstre: {int(monstre_val*100)}%) - Modèle: {monstre_name or 'Inconnu'}")
                                        self.click_on_game(rel_x, rel_y)
                                        self.last_click_time = current_time
                                        self._last_monster_click_time = current_time
                                        self.combat_launching = True
                                        self.combat_launch_time = current_time
                                        try:
                                            base_map_delay = float(self.entry_map_delay.get().strip())
                                        except:
                                            base_map_delay = 3.0
                                        self.current_map_delay = base_map_delay * np.random.uniform(0.85, 1.15)
                                    
            elif self.bot_state == "COMBAT":
                if combat_val >= threshold and combat_loc is not None:
                    self.last_combat_time = current_time
                    self.combat_button_seen = True
                    h, w = combat_shape
                    cv2.rectangle(cv_img, combat_loc, (combat_loc[0]+w, combat_loc[1]+h), (255, 0, 0), 3)
                    if combat_name:
                        self.last_matched_template_path = os.path.join(self.templates_combat, combat_name)
                    
                    is_ready_btn = "pret" in combat_name.lower() or "prêt" in combat_name.lower()
                    if is_ready_btn:
                        if not self.my_turn:
                            self.log_status(f"Bouton PRÊT détecté (Score: {int(combat_val*100)}%). Clic automatique...")
                            rel_x = combat_loc[0] + w // 2
                            rel_y = combat_loc[1] + h // 2
                            bg_mode = self.var_background_mode.get()
                            self.focus_target_window()
                            self.click_on_game(rel_x, rel_y, background_mode=bg_mode)
                            try:
                                ready_wait = float(self.slider_ready_delay.get())
                            except Exception:
                                ready_wait = 0.5
                            time.sleep(ready_wait)
                            self.my_turn = False
                    else:
                        if not self.my_turn:
                            self.my_turn = True
                            self.log_status(f"Mon Tour ! (Bouton: {int(combat_val*100)}%) - Modèle: {combat_name or 'Inconnu'}")
                            self.execute_combat_turn()
                else:
                    if self.my_turn:
                        self.my_turn = False
                        self.log_status("Attente Tour...")
                        
                    try:
                        _bail = float(self.entry_launch_timeout.get().strip())
                    except Exception:
                        _bail = 8.0
                    if (not self.combat_button_seen) and (current_time - self.last_combat_time > _bail):
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        self.log_status("🔄 Combat volé ou non démarré — retour Carte")
                    elif monstre_val >= threshold and monstre_loc is not None and (current_time - self.last_combat_time > 45.0):
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        if monstre_name:
                            self.last_matched_template_path = os.path.join(self.templates_monstres, monstre_name)
                        self.log_status(f"🔄 Auto-recovery : Retour Carte (Monstre détecté: {monstre_name or 'Inconnu'})")
                    elif current_time - self.last_combat_time > 90.0:
                        self.bot_state = "MAP"
                        self.my_turn = False
                        self.combat_launching = False
                        self.combat_launch_time = 0
                        self.last_click_time = 0
                        self.log_status(f"🔄 Auto-recovery : Timeout combat (90s)")
    
            self.processed_frame = cv_img
        except Exception as e:
            import traceback
            print("ERREUR FATALE bot_logic_loop:", e)
            print(traceback.format_exc())
            
        # Scheduling géré par _bot_thread_func

    def update_video_feed(self):
        if self.is_capturing:
            if hasattr(self, "processed_frame") and self.processed_frame is not None and self.is_bot_active:
                cv_img = self.processed_frame.copy()
            elif hasattr(self, "latest_captured_frame") and self.latest_captured_frame is not None:
                cv_img = self.latest_captured_frame.copy()
            else:
                self.after(20, self.update_video_feed)
                return
                
            self.current_cv_img = cv_img.copy()
            
            if self.tabview.get() == "Combat" and self.combat_zone is not None:
                (x1, y1), (x2, y2) = self.combat_zone
                if self.click_zone_mode == "Ligne":
                    cv2.line(cv_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.circle(cv_img, (x1, y1), 4, (0, 0, 255), -1)
                    cv2.circle(cv_img, (x2, y2), 4, (0, 0, 255), -1)
                    cv2.putText(cv_img, "Ligne de Clic", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
                else:
                    cv2.rectangle(cv_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(cv_img, "Zone de Clic", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
            
            elif self.tabview.get() == "🛡️ Modo":
                if self.modo_crop_x is not None and self.modo_crop_y is not None and self.modo_crop_w is not None and self.modo_crop_h is not None:
                    x1, y1 = self.modo_crop_x, self.modo_crop_y
                    x2, y2 = self.modo_crop_x + self.modo_crop_w, self.modo_crop_y + self.modo_crop_h
                    cv2.rectangle(cv_img, (x1, y1), (x2, y2), (0, 165, 255), 2) # Orange border
                    cv2.putText(cv_img, "Zone Alerte Modo", (min(x1, x2) + 5, min(y1, y2) - 5 if min(y1, y2) > 20 else min(y1, y2) + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 1, cv2.LINE_AA)
                if self.modo_chat_x is not None and self.modo_chat_y is not None:
                    cx, cy = self.modo_chat_x, self.modo_chat_y
                    cv2.circle(cv_img, (cx, cy), 6, (0, 255, 255), -1) # Yellow dot
                    cv2.putText(cv_img, "Clic Chat", (cx + 8, cy + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
            
            elif self.tabview.get() == "🎒 Pods":
                pass
            
            cv_img_rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(cv_img_rgb)
            
            orig_w, orig_h = pil_image.size
            self.update_idletasks()
            max_w = self.canvas.winfo_width()
            max_h = self.canvas.winfo_height()
            if max_w <= 10: max_w = 800
            if max_h <= 10: max_h = 450
            
            self.scale_ratio = min(max_w / max(1, orig_w), max_h / max(1, orig_h))
            new_w, new_h = max(1, int(orig_w * self.scale_ratio)), max(1, int(orig_h * self.scale_ratio))
            self.x_offset = max(0, (max_w - new_w) // 2)
            self.y_offset = max(0, (max_h - new_h) // 2)
            
            resized_pil = pil_image.resize((new_w, new_h), Image.Resampling.NEAREST)
            self.tk_image = ImageTk.PhotoImage(image=resized_pil)
            
            self.canvas.delete("video")
            self.canvas.create_image(self.x_offset, self.y_offset, image=self.tk_image, anchor="nw", tags="video")
            self.canvas.tag_lower("video")
            
            self.after(20, self.update_video_feed)

if __name__ == "__main__":
    app = BotGUI()
    app.mainloop()

